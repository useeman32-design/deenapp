(function () {
    const form = document.getElementById('resetForm');
    const resetBtn = document.getElementById('resetBtn');
    const resetBtnText = document.getElementById('resetBtnText');
  
    const newPassword = document.getElementById('newPassword');
    const confirmPassword = document.getElementById('confirmPassword');
  
    const newPasswordError = document.getElementById('newPasswordError');
    const confirmPasswordError = document.getElementById('confirmPasswordError');
    const generalError = document.getElementById('generalError');
  
    // Hide token notice completely (don’t show "token detected")
    const tokenNotice = document.getElementById('tokenNotice');
    if (tokenNotice) tokenNotice.style.display = 'none';
  
    function showFieldError(el, msg) {
      if (!el) return;
      el.textContent = msg;
      el.style.display = msg ? 'block' : 'none';
    }
  
    function clearErrors() {
      showFieldError(newPasswordError, '');
      showFieldError(confirmPasswordError, '');
      showFieldError(generalError, '');
    }
  
    function showNotification(message, type = 'success') {
      // Remove existing notifications
      document.querySelectorAll('.notification').forEach(n => n.remove());
  
      const notification = document.createElement('div');
      notification.className = `notification ${type === 'error' ? 'error' : ''}`;
  
      notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background-color: ${type === 'success' ? 'var(--primary-green, #0f9d58)' : '#e74c3c'};
        color: white;
        padding: 15px 18px;
        border-radius: 10px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        z-index: 9999;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 10px;
        max-width: 420px;
        animation: slideIn 0.25s ease, slideOut 0.25s ease 3s forwards;
      `;
  
      const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
      notification.innerHTML = `<i class="fas ${icon}" style="font-size: 18px;"></i><span></span>`;
      notification.querySelector('span').textContent = message; // prevent XSS
  
      document.body.appendChild(notification);
  
      if (!document.getElementById('notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
          @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
          @keyframes slideOut { from { transform: translateX(0); opacity: 1; } to { transform: translateX(100%); opacity: 0; } }
        `;
        document.head.appendChild(style);
      }
  
      setTimeout(() => notification.remove(), 3500);
    }
  
    function getToken() {
      const params = new URLSearchParams(window.location.search);
      return params.get('token') || '';
    }
  
    const token = getToken();
    if (!token) {
      showFieldError(generalError, 'Missing reset token. Please use the reset link from your email.');
      resetBtn.disabled = true;
      return;
    }
  
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      clearErrors();
  
      const p1 = newPassword.value;
      const p2 = confirmPassword.value;
  
      if (p1.length < 8) {
        showFieldError(newPasswordError, 'Password must be at least 8 characters.');
        return;
      }
      if (p1 !== p2) {
        showFieldError(confirmPasswordError, 'Passwords do not match.');
        return;
      }
  
      resetBtn.disabled = true;
      resetBtnText.textContent = 'Resetting...';
  
      try {
        const res = await fetch('../api/auth/reset_password.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            token: token,
            password: p1,
            confirm_password: p2
          })
        });
  
        const data = await res.json().catch(() => null);
  
        if (data && data.status === 'success') {
          showNotification(data.message || 'Password reset successful. Please login.');
  
          // Redirect to main index (where login modal exists)
          setTimeout(() => {
            window.location.href = '../index.html';
          }, 1200);
          return;
        }
  
        const msg = (data && data.message) ? data.message : 'Reset failed. Please try again.';
        showFieldError(generalError, msg);
        showNotification(msg, 'error');
  
      } catch (err) {
        showNotification('Network error. Please try again.', 'error');
      } finally {
        resetBtn.disabled = false;
        resetBtnText.textContent = 'Reset Password';
      }
    });
  })();