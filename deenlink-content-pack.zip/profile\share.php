<?php
declare(strict_types=1);

require_once __DIR__ . '/../api/config/db.php';

header('Content-Type: text/html; charset=utf-8');

$username = trim((string)($_GET['u'] ?? $_GET['username'] ?? ''));
$userId = (int)($_GET['user_id'] ?? 0);

try {
    $pdo = DB::conn();
    if ($username !== '') {
        $st = $pdo->prepare("SELECT id, username, full_name, bio, profile_image FROM users WHERE username = ? LIMIT 1");
        $st->execute([$username]);
        $row = $st->fetch(PDO::FETCH_ASSOC) ?: [];
    } elseif ($userId > 0) {
        $st = $pdo->prepare("SELECT id, username, full_name, bio, profile_image FROM users WHERE id = ? LIMIT 1");
        $st->execute([$userId]);
        $row = $st->fetch(PDO::FETCH_ASSOC) ?: [];
    } else {
        $row = [];
    }

    $name = trim((string)($row['full_name'] ?? '')) ?: trim((string)($row['username'] ?? 'DeenLink'));
    $uname = trim((string)($row['username'] ?? ''));
    $bio = trim((string)($row['bio'] ?? ''));
    $image = trim((string)($row['profile_image'] ?? ''));

    if ($image !== '' && !preg_match('/^https?:\/\//i', $image) && $image[0] !== '/') {
        $image = '/' . ltrim($image, '/');
    }

    $base = 'https://deenlink.org';
    $profileUrl = $uname !== ''
        ? $base . '/profile/public.html?u=' . rawurlencode($uname)
        : ($userId > 0 ? $base . '/profile/public.html?user_id=' . rawurlencode((string)$userId) : $base . '/profile/public.html');
    $ogUrl = $uname !== ''
        ? $base . '/' . rawurlencode($uname)
        : ($userId > 0 ? $base . '/profile/share.php?user_id=' . rawurlencode((string)$userId) : $profileUrl);
    $shareTitle = $name !== '' ? $name . ' on DeenLink' : 'DeenLink Profile';
    $shareDesc = $bio !== '' ? $bio : 'View this DeenLink profile.';
    $ogImage = $image !== '' ? $base . $image : $base . '/img/default_profile.jpg';
} catch (Throwable $e) {
    $profileUrl = 'https://deenlink.org/profile/public.html';
    $shareTitle = 'DeenLink Profile';
    $shareDesc = 'View this DeenLink profile.';
    $ogImage = 'https://deenlink.org/img/default_profile.jpg';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo htmlspecialchars($shareTitle, ENT_QUOTES, 'UTF-8'); ?></title>
  <meta property="og:type" content="profile">
  <meta property="og:title" content="<?php echo htmlspecialchars($shareTitle, ENT_QUOTES, 'UTF-8'); ?>">
  <meta property="og:description" content="<?php echo htmlspecialchars($shareDesc, ENT_QUOTES, 'UTF-8'); ?>">
  <meta property="og:image" content="<?php echo htmlspecialchars($ogImage, ENT_QUOTES, 'UTF-8'); ?>">
  <meta property="og:url" content="<?php echo htmlspecialchars($ogUrl, ENT_QUOTES, 'UTF-8'); ?>">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?php echo htmlspecialchars($shareTitle, ENT_QUOTES, 'UTF-8'); ?>">
  <meta name="twitter:description" content="<?php echo htmlspecialchars($shareDesc, ENT_QUOTES, 'UTF-8'); ?>">
  <meta name="twitter:image" content="<?php echo htmlspecialchars($ogImage, ENT_QUOTES, 'UTF-8'); ?>">
  <meta http-equiv="refresh" content="0; url=<?php echo htmlspecialchars($profileUrl, ENT_QUOTES, 'UTF-8'); ?>">
</head>
<body>
  <p>Redirecting to profile...</p>
  <a href="<?php echo htmlspecialchars($profileUrl, ENT_QUOTES, 'UTF-8'); ?>">Continue</a>
</body>
</html>
