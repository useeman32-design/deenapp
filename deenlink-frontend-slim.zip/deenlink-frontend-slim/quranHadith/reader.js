// Enforce admin maintenance toggles for Qur'an pages.
        if (window.DeenLinkMaintenance && window.DeenLinkMaintenance.enforce) {
            window.DeenLinkMaintenance.enforce({
                module: 'quran',
                apiPath: '../api/settings/public.php',
                homeUrl: '../index.html',
                message: "Qur'an is temporarily under maintenance. Please check back soon."
            });
        }

        // ============================================
        // PAGE TRANSITION LOADER IMPLEMENTATION
        // ============================================

        // DOM Elements
        const pageLoader = document.getElementById('pageLoader');
        const pageContent = document.getElementById('pageContent');
        const pageTransitionOverlay = document.getElementById('pageTransitionOverlay');
        const backBtn = document.getElementById('backBtn');

        // Function to show page loader
        function showPageLoader() {
            pageLoader.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        // Function to hide page loader
        function hidePageLoader() {
            pageLoader.classList.remove('active');
            document.body.style.overflow = 'auto';
        }

        // Function to show page transition overlay
        function showPageTransition() {
            pageTransitionOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        // Function to hide page transition overlay
        function hidePageTransition() {
            pageTransitionOverlay.classList.remove('active');
            document.body.style.overflow = 'auto';
        }

        function dlSafeBack(fallbackUrl) {
            window.location.href = fallbackUrl;
        }

        // Handle back button click with loader
        function setupBackButtonLoader() {
            backBtn.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Stop any audio playing
                if (audioElement && !audioElement.paused) {
                    audioElement.pause();
                }
                
                // Show page loader
                showPageLoader();
                
                // Fade out current content
                if (pageContent) {
                    pageContent.style.opacity = '0';
                    pageContent.style.transition = 'opacity 0.3s ease';
                }
                
                // Navigate back after 500ms delay
                setTimeout(() => {
                    dlSafeBack('surah.html');
                }, 500);
            });
        }

        // Hide loader when page is fully loaded
        window.addEventListener('load', function() {
            setTimeout(hidePageLoader, 100);
            if (pageContent) {
                pageContent.style.opacity = '1';
            }
        });

        window.addEventListener('pageshow', function(event) {
            if (event.persisted) {
                hidePageLoader();
                hidePageTransition();
                if (pageContent) {
                    pageContent.style.opacity = '1';
                }
            }
        });

        // Initial hide of loader
        setTimeout(() => {
            if (document.readyState === 'complete') {
                hidePageLoader();
            }
        }, 100);

        // ============================================
        // QURAN READER APPLICATION CODE
        // ============================================

        // Application State
        const state = {
            currentSurah: 1,
            currentMode: 'text',
            currentReciter: 'shuraim',
            currentSpeed: 1,
            currentAyah: 1,
            isPlaying: false,
            isLoadingAudio: false,
            // Bookmarks are handled in the selection pages (surah list). Keep reader focused on reading.
            bookmarkedAyahs: new Set(),
            isLoading: false,
            ayahs: [],
            surahInfo: null,
            playMode: 'surah',
            audioQueue: [],
            preloadedAudios: new Map(),
            preloadingAyahs: new Set(),
            currentLanguage: 'en',
            isDarkMode: localStorage.getItem('isDarkMode') === 'true',
            targetAyah: 0,
            mushafLoadToken: 0,
            isMushafPageLoading: false,
            pendingMushafPage: 0,
            pendingAudioSeekFraction: null,
            lastTrackedAyah: 0,
            lastTrackedScrollAt: 0,
            lastTrackedMushafPage: 0,
            nextSurahTimer: null,
            nextSurahCountdownValue: 0,
            nextSurahTarget: 0,
            isTransitioningSurah: false,

            // Reciters/unlocks are controlled by admin via DB. Reader fetches from backend.
            reciters: [],
            reciterByKey: {},
            userLoggedIn: false,
            userDeenpoints: null,
            // Mushaf page tracking
            currentPage: 1,
            totalPages: 604,
            // Zoom state - Default zoom set to 100% (original image size)
            zoomLevel: localStorage.getItem('savedZoomLevel') ? parseFloat(localStorage.getItem('savedZoomLevel')) : 1,
            savedZoomLevel: localStorage.getItem('savedZoomLevel') ? parseFloat(localStorage.getItem('savedZoomLevel')) : 1,
            maxZoom: 3,
            minZoom: 0.35,
            zoomStep: 0.15,
            isDragging: false,
            dragStartX: 0,
            dragStartY: 0,
            translateX: 0,
            translateY: 0,
            hasZoomChanged: false,
            // Surah metadata with page ranges
            surahMetadata: {
                1: { arabic: "", english: "Al-Fatiha", revelation: "mecca", verses: 7, startPage: 1, endPage: 1 },
                2: { arabic: "", english: "Al-Baqarah", revelation: "medina", verses: 286, startPage: 2, endPage: 49 },
                3: { arabic: "", english: "Ali 'Imran", revelation: "medina", verses: 200, startPage: 50, endPage: 77 },
                4: { arabic: "", english: "An-Nisa", revelation: "medina", verses: 176, startPage: 77, endPage: 106 },
                5: { arabic: "", english: "Al-Ma'idah", revelation: "medina", verses: 120, startPage: 106, endPage: 128 },
                6: { arabic: "", english: "Al-An'am", revelation: "mecca", verses: 165, startPage: 128, endPage: 151 },
                7: { arabic: "", english: "Al-A'raf", revelation: "mecca", verses: 206, startPage: 151, endPage: 177 },
                8: { arabic: "", english: "Al-Anfal", revelation: "medina", verses: 75, startPage: 177, endPage: 187 },
                9: { arabic: "", english: "At-Tawbah", revelation: "medina", verses: 129, startPage: 187, endPage: 208 },
                10: { arabic: "", english: "Yunus", revelation: "mecca", verses: 109, startPage: 208, endPage: 221 },
                11: { arabic: "", english: "Hud", revelation: "mecca", verses: 123, startPage: 221, endPage: 235 },
                12: { arabic: "", english: "Yusuf", revelation: "mecca", verses: 111, startPage: 235, endPage: 249 },
                13: { arabic: "", english: "Ar-Ra'd", revelation: "medina", verses: 43, startPage: 249, endPage: 255 },
                14: { arabic: "", english: "Ibrahim", revelation: "mecca", verses: 52, startPage: 255, endPage: 262 },
                15: { arabic: "", english: "Al-Hijr", revelation: "mecca", verses: 99, startPage: 262, endPage: 267 },
                16: { arabic: "", english: "An-Nahl", revelation: "mecca", verses: 128, startPage: 267, endPage: 281 },
                17: { arabic: "", english: "Al-Isra", revelation: "mecca", verses: 111, startPage: 282, endPage: 293 },
                18: { arabic: "", english: "Al-Kahf", revelation: "mecca", verses: 110, startPage: 293, endPage: 305 },
                19: { arabic: "", english: "Maryam", revelation: "mecca", verses: 98, startPage: 305, endPage: 312 },
                20: { arabic: "", english: "Taha", revelation: "mecca", verses: 135, startPage: 312, endPage: 322 },
                21: { arabic: "", english: "Al-Anbiya", revelation: "mecca", verses: 112, startPage: 322, endPage: 332 },
                22: { arabic: "", english: "Al-Hajj", revelation: "medina", verses: 78, startPage: 332, endPage: 342 },
                23: { arabic: "", english: "Al-Mu'minun", revelation: "mecca", verses: 118, startPage: 342, endPage: 350 },
                24: { arabic: "", english: "An-Nur", revelation: "medina", verses: 64, startPage: 350, endPage: 359 },
                25: { arabic: "", english: "Al-Furqan", revelation: "mecca", verses: 77, startPage: 359, endPage: 367 },
                26: { arabic: "", english: "Ash-Shu'ara", revelation: "mecca", verses: 227, startPage: 367, endPage: 377 },
                27: { arabic: "", english: "An-Naml", revelation: "mecca", verses: 93, startPage: 377, endPage: 385 },
                28: { arabic: "", english: "Al-Qasas", revelation: "mecca", verses: 88, startPage: 385, endPage: 396 },
                29: { arabic: "", english: "Al-'Ankabut", revelation: "mecca", verses: 69, startPage: 396, endPage: 404 },
                30: { arabic: "", english: "Ar-Rum", revelation: "mecca", verses: 60, startPage: 404, endPage: 411 },
                31: { arabic: "", english: "Luqman", revelation: "mecca", verses: 34, startPage: 411, endPage: 415 },
                32: { arabic: "", english: "As-Sajdah", revelation: "mecca", verses: 30, startPage: 415, endPage: 418 },
                33: { arabic: "", english: "Al-Ahzab", revelation: "medina", verses: 73, startPage: 418, endPage: 428 },
                34: { arabic: "", english: "Saba", revelation: "mecca", verses: 54, startPage: 428, endPage: 434 },
                35: { arabic: "", english: "Fatir", revelation: "mecca", verses: 45, startPage: 434, endPage: 440 },
                36: { arabic: "", english: "Ya-Sin", revelation: "mecca", verses: 83, startPage: 440, endPage: 446 },
                37: { arabic: "", english: "As-Saffat", revelation: "mecca", verses: 182, startPage: 446, endPage: 453 },
                38: { arabic: "", english: "Sad", revelation: "mecca", verses: 88, startPage: 453, endPage: 459 },
                39: { arabic: "", english: "Az-Zumar", revelation: "mecca", verses: 75, startPage: 459, endPage: 468 },
                40: { arabic: "", english: "Ghafir", revelation: "mecca", verses: 85, startPage: 468, endPage: 477 },
                41: { arabic: "", english: "Fussilat", revelation: "mecca", verses: 54, startPage: 477, endPage: 483 },
                42: { arabic: "", english: "Ash-Shura", revelation: "mecca", verses: 53, startPage: 483, endPage: 489 },
                43: { arabic: "", english: "Az-Zukhruf", revelation: "mecca", verses: 89, startPage: 489, endPage: 496 },
                44: { arabic: "", english: "Ad-Dukhan", revelation: "mecca", verses: 59, startPage: 496, endPage: 499 },
                45: { arabic: "", english: "Al-Jathiyah", revelation: "mecca", verses: 37, startPage: 499, endPage: 502 },
                46: { arabic: "", english: "Al-Ahqaf", revelation: "mecca", verses: 35, startPage: 502, endPage: 507 },
                47: { arabic: "", english: "Muhammad", revelation: "medina", verses: 38, startPage: 507, endPage: 511 },
                48: { arabic: "", english: "Al-Fath", revelation: "medina", verses: 29, startPage: 511, endPage: 515 },
                49: { arabic: "", english: "Al-Hujurat", revelation: "medina", verses: 18, startPage: 515, endPage: 518 },
                50: { arabic: "", english: "Qaf", revelation: "mecca", verses: 45, startPage: 518, endPage: 521 },
                51: { arabic: "", english: "Adh-Dhariyat", revelation: "mecca", verses: 60, startPage: 521, endPage: 524 },
                52: { arabic: "", english: "At-Tur", revelation: "mecca", verses: 49, startPage: 524, endPage: 527 },
                53: { arabic: "", english: "An-Najm", revelation: "mecca", verses: 62, startPage: 527, endPage: 531 },
                54: { arabic: "", english: "Al-Qamar", revelation: "mecca", verses: 55, startPage: 531, endPage: 535 },
                55: { arabic: "", english: "Ar-Rahman", revelation: "medina", verses: 78, startPage: 535, endPage: 540 },
                56: { arabic: "", english: "Al-Waqi'ah", revelation: "mecca", verses: 96, startPage: 540, endPage: 546 },
                57: { arabic: "", english: "Al-Hadid", revelation: "medina", verses: 29, startPage: 546, endPage: 550 },
                58: { arabic: "", english: "Al-Mujadila", revelation: "medina", verses: 22, startPage: 550, endPage: 553 },
                59: { arabic: "", english: "Al-Hashr", revelation: "medina", verses: 24, startPage: 553, endPage: 554 },
                60: { arabic: "", english: "Al-Mumtahanah", revelation: "medina", verses: 13, startPage: 554, endPage: 556 },
                61: { arabic: "", english: "As-Saff", revelation: "medina", verses: 14, startPage: 556, endPage: 557 },
                62: { arabic: "", english: "Al-Jumu'ah", revelation: "medina", verses: 11, startPage: 557, endPage: 558 },
                63: { arabic: "", english: "Al-Munafiqun", revelation: "medina", verses: 11, startPage: 558, endPage: 560 },
                64: { arabic: "", english: "At-Taghabun", revelation: "medina", verses: 18, startPage: 560, endPage: 562 },
                65: { arabic: "", english: "At-Talaq", revelation: "medina", verses: 12, startPage: 562, endPage: 564 },
                66: { arabic: "", english: "At-Tahrim", revelation: "medina", verses: 12, startPage: 564, endPage: 566 },
                67: { arabic: "", english: "Al-Mulk", revelation: "mecca", verses: 30, startPage: 566, endPage: 568 },
                68: { arabic: "", english: "Al-Qalam", revelation: "mecca", verses: 52, startPage: 568, endPage: 570 },
                69: { arabic: "", english: "Al-Haqqah", revelation: "mecca", verses: 52, startPage: 570, endPage: 572 },
                70: { arabic: "", english: "Al-Ma'arij", revelation: "mecca", verses: 44, startPage: 572, endPage: 574 },
                71: { arabic: "", english: "Nuh", revelation: "mecca", verses: 28, startPage: 574, endPage: 576 },
                72: { arabic: "", english: "Al-Jinn", revelation: "mecca", verses: 28, startPage: 576, endPage: 578 },
                73: { arabic: "", english: "Al-Muzzammil", revelation: "mecca", verses: 20, startPage: 578, endPage: 580 },
                74: { arabic: "", english: "Al-Muddaththir", revelation: "mecca", verses: 56, startPage: 580, endPage: 582 },
                75: { arabic: "", english: "Al-Qiyamah", revelation: "mecca", verses: 40, startPage: 582, endPage: 583 },
                76: { arabic: "", english: "Al-Insan", revelation: "medina", verses: 31, startPage: 583, endPage: 585 },
                77: { arabic: "", english: "Al-Mursalat", revelation: "mecca", verses: 50, startPage: 585, endPage: 587 },
                78: { arabic: "", english: "An-Naba", revelation: "mecca", verses: 40, startPage: 587, endPage: 589 },
                79: { arabic: "", english: "An-Nazi'at", revelation: "mecca", verses: 46, startPage: 589, endPage: 591 },
                80: { arabic: "", english: "Abasa", revelation: "mecca", verses: 42, startPage: 591, endPage: 591 },
                81: { arabic: "", english: "At-Takwir", revelation: "mecca", verses: 29, startPage: 591, endPage: 593 },
                82: { arabic: "", english: "Al-Infitar", revelation: "mecca", verses: 19, startPage: 593, endPage: 594 },
                83: { arabic: "", english: "Al-Mutaffifin", revelation: "mecca", verses: 36, startPage: 594, endPage: 596 },
                84: { arabic: "", english: "Al-Inshiqaq", revelation: "mecca", verses: 25, startPage: 596, endPage: 597 },
                85: { arabic: "", english: "Al-Buruj", revelation: "mecca", verses: 22, startPage: 597, endPage: 599 },
                86: { arabic: "", english: "At-Tariq", revelation: "mecca", verses: 17, startPage: 599, endPage: 600 },
                87: { arabic: "", english: "Al-A'la", revelation: "mecca", verses: 19, startPage: 600, endPage: 600 },
                88: { arabic: "", english: "Al-Ghashiyah", revelation: "mecca", verses: 26, startPage: 600, endPage: 602 },
                89: { arabic: "", english: "Al-Fajr", revelation: "mecca", verses: 30, startPage: 602, endPage: 603 },
                90: { arabic: "", english: "Al-Balad", revelation: "mecca", verses: 20, startPage: 603, endPage: 604 },
                91: { arabic: "", english: "Ash-Shams", revelation: "mecca", verses: 15, startPage: 604, endPage: 604 },
                92: { arabic: "", english: "Al-Layl", revelation: "mecca", verses: 21, startPage: 604, endPage: 605 },
                93: { arabic: "", english: "Ad-Duhaa", revelation: "mecca", verses: 11, startPage: 605, endPage: 605 },
                94: { arabic: "", english: "Ash-Sharh", revelation: "mecca", verses: 8, startPage: 605, endPage: 605 },
                95: { arabic: "", english: "At-Tin", revelation: "mecca", verses: 8, startPage: 605, endPage: 605 },
                96: { arabic: "", english: "Al-'Alaq", revelation: "mecca", verses: 19, startPage: 605, endPage: 605 },
                97: { arabic: "", english: "Al-Qadr", revelation: "mecca", verses: 5, startPage: 605, endPage: 605 },
                98: { arabic: "", english: "Al-Bayyinah", revelation: "medina", verses: 8, startPage: 605, endPage: 605 },
                99: { arabic: "", english: "Az-Zalzalah", revelation: "medina", verses: 8, startPage: 605, endPage: 605 },
                100: { arabic: "", english: "Al-'Adiyat", revelation: "mecca", verses: 11, startPage: 605, endPage: 605 },
                101: { arabic: "", english: "Al-Qari'ah", revelation: "mecca", verses: 11, startPage: 605, endPage: 605 },
                102: { arabic: "", english: "At-Takathur", revelation: "mecca", verses: 8, startPage: 605, endPage: 605 },
                103: { arabic: "", english: "Al-'Asr", revelation: "mecca", verses: 3, startPage: 605, endPage: 605 },
                104: { arabic: "", english: "Al-Humazah", revelation: "mecca", verses: 9, startPage: 605, endPage: 605 },
                105: { arabic: "", english: "Al-Fil", revelation: "mecca", verses: 5, startPage: 605, endPage: 605 },
                106: { arabic: "", english: "Quraysh", revelation: "mecca", verses: 4, startPage: 605, endPage: 605 },
                107: { arabic: "", english: "Al-Ma'un", revelation: "mecca", verses: 7, startPage: 605, endPage: 605 },
                108: { arabic: "", english: "Al-Kawthar", revelation: "mecca", verses: 3, startPage: 605, endPage: 605 },
                109: { arabic: "", english: "Al-Kafirun", revelation: "mecca", verses: 6, startPage: 605, endPage: 605 },
                110: { arabic: "", english: "An-Nasr", revelation: "medina", verses: 3, startPage: 605, endPage: 605 },
                111: { arabic: "", english: "Al-Masad", revelation: "mecca", verses: 5, startPage: 605, endPage: 605 },
                112: { arabic: "", english: "Al-Ikhlas", revelation: "mecca", verses: 4, startPage: 605, endPage: 605 },
                113: { arabic: "", english: "Al-Falaq", revelation: "mecca", verses: 5, startPage: 605, endPage: 605 },
                114: { arabic: "", english: "An-Nas", revelation: "mecca", verses: 6, startPage: 605, endPage: 605 }
            },
            // Page metadata - which surahs are on which pages
            pageMetadata: {}
        };
        
        // Audio sources are fetched from /api/quran/reciters.php (DB controlled).
        // Fallback to built-in defaults if API is unavailable.
        let audioUrls = {
            mishary: {
                baseUrl: "https://cdn.islamic.network/quran/audio/64/ar.alafasy",
                format: "mp3",
                working: true,
                urlMode: "absolute_ayah"
            },
            abdulbasit: {
                baseUrl: "https://cdn.islamic.network/quran/audio/64/ar.abdulsamad",
                format: "mp3",
                working: true,
                urlMode: "absolute_ayah"
            },
            saad: {
                baseUrl: "https://cdn.islamic.network/quran/audio/64/ar.saoodshuraym",
                format: "mp3",
                working: true,
                urlMode: "absolute_ayah"
            },
            maher: {
                baseUrl: "https://cdn.islamic.network/quran/audio/64/ar.mahermuaiqly",
                format: "mp3",
                working: true,
                urlMode: "absolute_ayah"
            },
            sudais: {
                baseUrl: "https://cdn.islamic.network/quran/audio/64/ar.abdurrahmaansudais",
                format: "mp3",
                working: true,
                urlMode: "absolute_ayah"
            },
            shuraim: {
                baseUrl: "https://cdn.islamic.network/quran/audio/64/ar.saoodshuraym",
                format: "mp3",
                working: true,
                urlMode: "absolute_ayah"
            },
            ayyub: {
                // Using everyayah.com for Muhammad Ayyub
                baseUrl: "https://everyayah.com/data/Muhammad_Ayyoub_64kbps",
                format: "mp3",
                working: true,
                urlMode: "surah_ayah"
            },
            yasser_aldosari: {
                baseUrl: "https://everyayah.com/data/Yasser_Ad-Dussary_128kbps",
                format: "mp3",
                working: true,
                urlMode: "surah_ayah"
            }
        };

        // Defensive: if any UI reads metadata before SURAH_AR mapping applies, don't ever show "????".
        try {
            Object.keys(state.surahMetadata || {}).forEach((k) => {
                const m = state.surahMetadata[k];
                if (!m) return;
                if (String(m.arabic || '').includes('?')) m.arabic = '';
            });
        } catch (_e) {}
        
        // Speed options
        const speedOptions = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];
        
        // DOM Elements
        const modeToggle = document.getElementById('modeToggle');
        const arabicTitle = document.getElementById('arabicTitle');
        const englishTitle = document.getElementById('englishTitle');
        const languageIndicator = document.getElementById('languageIndicator');
        const basmallahBanner = document.getElementById('basmallahBanner');
        const basmallahTranslation = document.getElementById('basmallahTranslation');
        const ayahList = document.getElementById('ayahList');
        const loader = document.getElementById('loader');
        const audioPlayer = document.getElementById('audioPlayer');
        const playBtn = document.getElementById('playBtn');
        const audioElement = document.getElementById('audioElement');
        const progressBar = document.getElementById('progressBar');
        const progress = document.getElementById('progress');
        const currentAyahNumber = document.getElementById('currentAyahNumber');
        const currentSurahName = document.getElementById('currentSurahName');
        const settingsBtn = document.getElementById('settingsBtn');
        const settingsDropdown = document.getElementById('settingsDropdown');
        const speedBtn = document.getElementById('speedBtn');
        const playModeIndicator = document.getElementById('playModeIndicator');
        const languageButton = document.getElementById('languageButton');
        const languageDropdown = document.getElementById('languageDropdown');
        const body = document.body;

        // =====================================================
        // RECITER UNLOCKS (DEENPOINTS) - DB CONTROLLED
        // =====================================================
        // We fetch reciters (and lock state) from backend so:
        // - Admin can set DeenPoints price per reciter in DB
        // - Users can unlock once and it works across devices
        // - Reader never "guesses" pricing client-side

        function appRoot() {
            // Derive base path so the app can run either at:
            // - http://host/deenLink/... (XAMPP subfolder)
            // - http://host/... (root hosting)
            // We avoid hardcoding "/deenLink/".
            const p = String(window.location.pathname || '').replace(/\\/g, '/');
            const parts = p.split('/').filter(Boolean);
            // If path ends with ".../quranHadith/reader.html", root is everything before "quranHadith".
            const idx = parts.findIndex(seg => seg.toLowerCase() === 'quranhadith');
            if (idx >= 0) {
                return '/' + parts.slice(0, idx).join('/') + '/';
            }
            return '/';
        }
        const APP_ROOT = appRoot();
        const API_ROOT = APP_ROOT + 'api';
        let _csrf = '';

        // Arabic surah names (ASCII-only source; avoids "????" corruption).
        const SURAH_AR = {
            1: "\u0627\u0644\u0641\u0627\u062A\u062D\u0629",
            2: "\u0627\u0644\u0628\u0642\u0631\u0629",
            3: "\u0622\u0644 \u0639\u0645\u0631\u0627\u0646",
            4: "\u0627\u0644\u0646\u0633\u0627\u0621",
            5: "\u0627\u0644\u0645\u0627\u0626\u062F\u0629",
            6: "\u0627\u0644\u0623\u0646\u0639\u0627\u0645",
            7: "\u0627\u0644\u0623\u0639\u0631\u0627\u0641",
            8: "\u0627\u0644\u0623\u0646\u0641\u0627\u0644",
            9: "\u0627\u0644\u062A\u0648\u0628\u0629",
            10: "\u064A\u0648\u0646\u0633",
            11: "\u0647\u0648\u062F",
            12: "\u064A\u0648\u0633\u0641",
            13: "\u0627\u0644\u0631\u0639\u062F",
            14: "\u0625\u0628\u0631\u0627\u0647\u064A\u0645",
            15: "\u0627\u0644\u062D\u062C\u0631",
            16: "\u0627\u0644\u0646\u062D\u0644",
            17: "\u0627\u0644\u0625\u0633\u0631\u0627\u0621",
            18: "\u0627\u0644\u0643\u0647\u0641",
            19: "\u0645\u0631\u064A\u0645",
            20: "\u0637\u0647",
            21: "\u0627\u0644\u0623\u0646\u0628\u064A\u0627\u0621",
            22: "\u0627\u0644\u062D\u062C",
            23: "\u0627\u0644\u0645\u0624\u0645\u0646\u0648\u0646",
            24: "\u0627\u0644\u0646\u0648\u0631",
            25: "\u0627\u0644\u0641\u0631\u0642\u0627\u0646",
            26: "\u0627\u0644\u0634\u0639\u0631\u0627\u0621",
            27: "\u0627\u0644\u0646\u0645\u0644",
            28: "\u0627\u0644\u0642\u0635\u0635",
            29: "\u0627\u0644\u0639\u0646\u0643\u0628\u0648\u062A",
            30: "\u0627\u0644\u0631\u0648\u0645",
            31: "\u0644\u0642\u0645\u0627\u0646",
            32: "\u0627\u0644\u0633\u062C\u062F\u0629",
            33: "\u0627\u0644\u0623\u062D\u0632\u0627\u0628",
            34: "\u0633\u0628\u0623",
            35: "\u0641\u0627\u0637\u0631",
            36: "\u064A\u0633",
            37: "\u0627\u0644\u0635\u0627\u0641\u0627\u062A",
            38: "\u0635",
            39: "\u0627\u0644\u0632\u0645\u0631",
            40: "\u063A\u0627\u0641\u0631",
            41: "\u0641\u0635\u0644\u062A",
            42: "\u0627\u0644\u0634\u0648\u0631\u0649",
            43: "\u0627\u0644\u0632\u062E\u0631\u0641",
            44: "\u0627\u0644\u062F\u062E\u0627\u0646",
            45: "\u0627\u0644\u062C\u0627\u062B\u064A\u0629",
            46: "\u0627\u0644\u0623\u062D\u0642\u0627\u0641",
            47: "\u0645\u062D\u0645\u062F",
            48: "\u0627\u0644\u0641\u062A\u062D",
            49: "\u0627\u0644\u062D\u062C\u0631\u0627\u062A",
            50: "\u0642",
            51: "\u0627\u0644\u0630\u0627\u0631\u064A\u0627\u062A",
            52: "\u0627\u0644\u0637\u0648\u0631",
            53: "\u0627\u0644\u0646\u062C\u0645",
            54: "\u0627\u0644\u0642\u0645\u0631",
            55: "\u0627\u0644\u0631\u062D\u0645\u0646",
            56: "\u0627\u0644\u0648\u0627\u0642\u0639\u0629",
            57: "\u0627\u0644\u062D\u062F\u064A\u062F",
            58: "\u0627\u0644\u0645\u062C\u0627\u062F\u0644\u0629",
            59: "\u0627\u0644\u062D\u0634\u0631",
            60: "\u0627\u0644\u0645\u0645\u062A\u062D\u0646\u0629",
            61: "\u0627\u0644\u0635\u0641",
            62: "\u0627\u0644\u062C\u0645\u0639\u0629",
            63: "\u0627\u0644\u0645\u0646\u0627\u0641\u0642\u0648\u0646",
            64: "\u0627\u0644\u062A\u063A\u0627\u0628\u0646",
            65: "\u0627\u0644\u0637\u0644\u0627\u0642",
            66: "\u0627\u0644\u062A\u062D\u0631\u064A\u0645",
            67: "\u0627\u0644\u0645\u0644\u0643",
            68: "\u0627\u0644\u0642\u0644\u0645",
            69: "\u0627\u0644\u062D\u0627\u0642\u0629",
            70: "\u0627\u0644\u0645\u0639\u0627\u0631\u062C",
            71: "\u0646\u0648\u062D",
            72: "\u0627\u0644\u062C\u0646",
            73: "\u0627\u0644\u0645\u0632\u0645\u0644",
            74: "\u0627\u0644\u0645\u062F\u062B\u0631",
            75: "\u0627\u0644\u0642\u064A\u0627\u0645\u0629",
            76: "\u0627\u0644\u0625\u0646\u0633\u0627\u0621",
            77: "\u0627\u0644\u0645\u0631\u0633\u0644\u0627\u062A",
            78: "\u0627\u0644\u0646\u0628\u0623",
            79: "\u0627\u0644\u0646\u0627\u0632\u0639\u0627\u062A",
            80: "\u0639\u0628\u0633",
            81: "\u0627\u0644\u062A\u0643\u0648\u064A\u0631",
            82: "\u0627\u0644\u0627\u0646\u0641\u0637\u0627\u0631",
            83: "\u0627\u0644\u0645\u0637\u0641\u0641\u064A\u0646",
            84: "\u0627\u0644\u0627\u0646\u0634\u0642\u0627\u0642",
            85: "\u0627\u0644\u0628\u0631\u0648\u062C",
            86: "\u0627\u0644\u0637\u0627\u0631\u0642",
            87: "\u0627\u0644\u0623\u0639\u0644\u0649",
            88: "\u0627\u0644\u063A\u0627\u0634\u064A\u0629",
            89: "\u0627\u0644\u0641\u062C\u0631",
            90: "\u0627\u0644\u0628\u0644\u062F",
            91: "\u0627\u0644\u0634\u0645\u0633",
            92: "\u0627\u0644\u0644\u064A\u0644",
            93: "\u0627\u0644\u0636\u062D\u0649",
            94: "\u0627\u0644\u0634\u0631\u062D",
            95: "\u0627\u0644\u062A\u064A\u0646",
            96: "\u0627\u0644\u0639\u0644\u0642",
            97: "\u0627\u0644\u0642\u062F\u0631",
            98: "\u0627\u0644\u0628\u064A\u0646\u0629",
            99: "\u0627\u0644\u0632\u0644\u0632\u0644\u0629",
            100: "\u0627\u0644\u0639\u0627\u062F\u064A\u0627\u062A",
            101: "\u0627\u0644\u0642\u0627\u0631\u0639\u0629",
            102: "\u0627\u0644\u062A\u0643\u0627\u062B\u0631",
            103: "\u0627\u0644\u0639\u0635\u0631",
            104: "\u0627\u0644\u0647\u0645\u0632\u0629",
            105: "\u0627\u0644\u0641\u064A\u0644",
            106: "\u0642\u0631\u064A\u0634",
            107: "\u0627\u0644\u0645\u0627\u0639\u0648\u0646",
            108: "\u0627\u0644\u0643\u0648\u062B\u0631",
            109: "\u0627\u0644\u0643\u0627\u0641\u0631\u0648\u0646",
            110: "\u0627\u0644\u0646\u0635\u0631",
            111: "\u0627\u0644\u0645\u0633\u062F",
            112: "\u0627\u0644\u0625\u062E\u0644\u0627\u0635",
            113: "\u0627\u0644\u0641\u0644\u0642",
            114: "\u0627\u0644\u0646\u0627\u0633"
        };
        const DEFAULT_BASMALLAH_AR = "\u0628\u0633\u0645 \u0627\u0644\u0644\u0647 \u0627\u0644\u0631\u062D\u0645\u0646 \u0627\u0644\u0631\u062D\u064A\u0645";

        // Apply Arabic names to metadata once (ensures UI never shows "????").
        try {
            Object.keys(SURAH_AR).forEach((k) => {
                const n = Number(k);
                if (state && state.surahMetadata && state.surahMetadata[n]) {
                    state.surahMetadata[n].arabic = SURAH_AR[n];
                }
            });
        } catch (_e) {}

        async function apiJson(url, opts) {
            const res = await fetch(url, Object.assign({ credentials: 'include' }, opts || {}));
            const txt = await res.text();
            let data = null;
            try { data = JSON.parse(txt); } catch (_) { /* ignore */ }
            if (!res.ok) {
                const msg = (data && data.message) ? data.message : ('Server error (' + res.status + ')');
                const err = new Error(msg);
                err.status = res.status;
                err.data = data;
                throw err;
            }
            if (!data || typeof data !== 'object') {
                const err = new Error('Invalid server response');
                err.status = res.status;
                err.raw = txt;
                throw err;
            }
            return data;
        }

        async function getCsrf() {
            if (_csrf) return _csrf;
            const d = await apiJson(API_ROOT + '/auth/csrf.php', { headers: { Accept: 'application/json' } });
            _csrf = String(d.csrf_token || '');
            return _csrf;
        }

        async function apiPostJson(url, bodyObj) {
            const token = await getCsrf();
            return apiJson(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': token, Accept: 'application/json' },
                body: JSON.stringify(bodyObj || {})
            });
        }

        function ensureReciterUnlockModal() {
            if (document.getElementById('reciterUnlockModal')) return;
            const modal = document.createElement('div');
            modal.id = 'reciterUnlockModal';
            modal.style.cssText = 'position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.55);z-index:99999;padding:16px;';
            modal.innerHTML = `
                <div style="width:min(420px,100%);background:#fff;border-radius:14px;padding:18px 16px;box-shadow:0 18px 40px rgba(0,0,0,.25);font-family:inherit;">
                    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
                        <div style="font-weight:800;color:#1D6F42;font-size:16px;">Unlock Reciter</div>
                        <button type="button" id="reciterUnlockClose" style="border:0;background:transparent;font-size:18px;cursor:pointer;color:#555;">&times;</button>
                    </div>
                    <div id="reciterUnlockBody" style="margin-top:10px;color:#333;font-size:13px;line-height:1.45;"></div>
                    <div style="display:flex;gap:10px;margin-top:14px;">
                        <button type="button" id="reciterUnlockCancel" style="flex:1;border:1px solid #ddd;background:#fff;border-radius:10px;padding:10px 12px;cursor:pointer;">Cancel</button>
                        <button type="button" id="reciterUnlockConfirm" style="flex:1;border:0;background:#1D6F42;color:#fff;border-radius:10px;padding:10px 12px;cursor:pointer;font-weight:700;">Unlock</button>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
            const close = () => { modal.style.display = 'none'; modal.dataset.reciterKey = ''; };
            modal.addEventListener('click', (e) => { if (e.target === modal) close(); });
            modal.querySelector('#reciterUnlockClose')?.addEventListener('click', close);
            modal.querySelector('#reciterUnlockCancel')?.addEventListener('click', close);
        }

        function openUnlockReciterModal(reciterKey) {
            ensureReciterUnlockModal();
            const modal = document.getElementById('reciterUnlockModal');
            const bodyEl = document.getElementById('reciterUnlockBody');
            const r = state.reciterByKey[reciterKey];
            if (!modal || !bodyEl || !r) return;
            modal.dataset.reciterKey = reciterKey;

            const price = Number(r.price || 0);
            const bal = (state.userDeenpoints == null) ? null : Number(state.userDeenpoints || 0);
            const balTxt = (bal == null) ? 'Login required' : ('Your balance: ' + bal.toLocaleString() + ' DeenPoints');

            bodyEl.innerHTML = `
                <div style="font-weight:800;margin-bottom:6px;">${String(r.name || reciterKey)}</div>
                <div style="color:#444;">Cost: <span style="font-weight:800;">${price.toLocaleString()} DeenPoints</span></div>
                <div style="color:#666;margin-top:6px;">${balTxt}</div>
                <div style="color:#777;margin-top:10px;">This unlock is stored on your account and will work on all your devices.</div>
            `;

            const confirmBtn = document.getElementById('reciterUnlockConfirm');
            if (confirmBtn) {
                confirmBtn.onclick = async () => {
                    try {
                        if (!state.userLoggedIn) {
                            showNotification('Please login to unlock reciters');
                            return;
                        }
                        confirmBtn.disabled = true;
                        confirmBtn.textContent = 'Unlocking...';
                        const resp = await apiPostJson(API_ROOT + '/quran/unlock_reciter.php', { reciter_key: reciterKey });
                        if (resp && resp.status === 'success') {
                            await loadRecitersAndRender(true);
                            showNotification(resp.message || 'Unlocked');
                            modal.style.display = 'none';
                            changeReciter(reciterKey);
                        } else {
                            showNotification((resp && resp.message) ? resp.message : 'Failed to unlock');
                        }
                    } catch (e) {
                        showNotification(e?.message || 'Failed to unlock');
                    } finally {
                        confirmBtn.disabled = false;
                        confirmBtn.textContent = 'Unlock';
                    }
                };
            }

            modal.style.display = 'flex';
        }

        function renderReciterDropdown(reciters) {
            if (!settingsDropdown) return;
            const items = (Array.isArray(reciters) ? reciters : []).slice().sort((a, b) => (Number(a.sort_order || 0) - Number(b.sort_order || 0)));
            if (!items.length) {
                settingsDropdown.innerHTML = `
                    <div class="dropdown-item" data-reciter="">
                        <span class="dropdown-label">No reciters available</span>
                    </div>
                `;
                return;
            }

            settingsDropdown.innerHTML = items.map(r => {
                const key = String(r.key || '');
                const name = String(r.name || key);
                const locked = !!r.is_locked;
                const price = Number(r.price || 0);

                // UI requirement:
                // - Locked reciters show DeenPoints icon + amount only (no "DP")
                // - Locked reciters should not show a lock icon
                const badge = locked
                    ? `<span style="margin-left:auto;font-size:11px;font-weight:900;color:#b71c1c;display:inline-flex;align-items:center;gap:6px;">
                        <img src="../img/deenPoints.png" alt="DeenPoints" style="width:15px;height:15px;display:block;">
                        <span>${price}</span>
                      </span>`
                    : '';
                return `
                    <div class="dropdown-item ${(!locked && key === state.currentReciter) ? 'active' : ''}" data-reciter="${key}" data-locked="${locked ? '1' : '0'}">
                        <span class="dropdown-label">${name}</span>
                        ${badge}
                    </div>
                `;
            }).join('');
        }

        async function loadRecitersAndRender(silent) {
            try {
                const d = await apiJson(API_ROOT + '/quran/reciters.php', { headers: { Accept: 'application/json' } });
                if (!d || d.status !== 'success') throw new Error('Failed to load reciters');

                state.reciters = Array.isArray(d.reciters) ? d.reciters : [];
                state.reciterByKey = {};

                const map = {};
                state.reciters.forEach(r => {
                    if (!r || !r.key) return;
                    const key = String(r.key);
                    state.reciterByKey[key] = r;
                    map[key] = {
                        baseUrl: String(r.base_url || ''),
                        format: String(r.audio_format || 'mp3'),
                        working: true,
                        urlMode: String(r.url_mode || 'absolute_ayah')
                    };
                });
                audioUrls = Object.assign({}, audioUrls, map);

                state.userLoggedIn = !!(d.user && d.user.logged_in);
                state.userDeenpoints = (d.user && typeof d.user.deenpoints_balance === 'number') ? d.user.deenpoints_balance : (d.user ? d.user.deenpoints_balance : null);

                // Choose a usable reciter if current is locked.
                const saved = String(localStorage.getItem('deenlink.quran.reciter') || '').trim();
                const savedObj = saved ? state.reciterByKey[saved] : null;
                const cur = state.reciterByKey[state.currentReciter];

                if (savedObj && !savedObj.is_locked) {
                    state.currentReciter = saved;
                } else if (cur && cur.is_locked) {
                    const firstUnlocked = state.reciters.find(r => r && !r.is_locked);
                    if (firstUnlocked && firstUnlocked.key) state.currentReciter = String(firstUnlocked.key);
                }

                renderReciterDropdown(state.reciters);
            } catch (e) {
                if (!silent) showNotification('Failed to load reciters');
                // Keep fallback list but render it (best-effort).
                const fallback = Object.keys(audioUrls).map((k, i) => ({
                    key: k,
                    name: getReciterDisplayName(k),
                    is_locked: false,
                    price: 0,
                    sort_order: (i + 1) * 10
                }));
                state.reciters = fallback;
                state.reciterByKey = {};
                fallback.forEach(r => { state.reciterByKey[r.key] = r; });
                renderReciterDropdown(fallback);
            }
        }
        
        // Mushaf DOM Elements
        const textModeContent = document.getElementById('textModeContent');
        const mushafModeContent = document.getElementById('mushafModeContent');
        const mushafPageImage = document.getElementById('mushafPageImage');
        const mushafLoader = document.getElementById('mushafLoader');
        const currentPageElement = document.getElementById('currentPage');
        const totalPagesElement = document.getElementById('totalPages');
        const prevPageBtn = document.getElementById('prevPageBtn');
        const nextPageBtn = document.getElementById('nextPageBtn');
        const desktopPrevBtn = document.getElementById('desktopPrevBtn');
        const desktopNextBtn = document.getElementById('desktopNextBtn');
        const pageInput = document.getElementById('pageInput');
        const jumpPageBtn = document.getElementById('jumpPageBtn');
        const pageRangeInfo = document.getElementById('pageRangeInfo');
        const surahRangeElement = document.getElementById('surahRange');
        
        // Zoom DOM Elements
        const pinchHint = document.getElementById('pinchHint');
        const pinchHintClose = document.getElementById('pinchHintClose');
        const saveZoomBtn = document.getElementById('saveZoomBtn');
        const resetZoomBtn = document.getElementById('resetZoomBtn');
        const mushafViewer = document.getElementById('mushafViewer');
        const zoomInBtn = document.getElementById('zoomInBtn');
        const zoomOutBtn = document.getElementById('zoomOutBtn');
        
        // ============================================
        // ZOOM FUNCTIONS
        // ============================================

        function updateZoomControls() {
            // Apply transform to the mushaf image with perfect centering
            mushafPageImage.classList.add('zoom-transition');
            mushafPageImage.style.transform = `scale(${state.zoomLevel}) translate(${state.translateX}px, ${state.translateY}px)`;
            
            // Show/hide save button based on whether zoom has changed from saved value
            const zoomChanged = Math.abs(state.zoomLevel - state.savedZoomLevel) > 0.01;
            if (zoomChanged && !state.hasZoomChanged) {
                state.hasZoomChanged = true;
                saveZoomBtn.classList.add('show');
            } else if (!zoomChanged && state.hasZoomChanged) {
                state.hasZoomChanged = false;
                saveZoomBtn.classList.remove('show');
            }
            
            // Always show reset button
            resetZoomBtn.classList.add('show');
            
            // Enable/disable zoom buttons based on limits
            zoomInBtn.disabled = state.zoomLevel >= state.maxZoom;
            zoomOutBtn.disabled = state.zoomLevel <= state.minZoom;
            
            // Remove transition class after animation completes
            setTimeout(() => {
                mushafPageImage.classList.remove('zoom-transition');
            }, 300);
        }

        function saveZoom() {
            // Save the current zoom level to localStorage
            localStorage.setItem('savedZoomLevel', state.zoomLevel.toString());
            state.savedZoomLevel = state.zoomLevel;
            state.hasZoomChanged = false;
            saveZoomBtn.classList.remove('show');
            showNotification(`Zoom saved at ${Math.round(state.zoomLevel * 100)}%`);
        }

        function resetZoom() {
            // Reset to saved zoom level (or default 100%)
            state.zoomLevel = state.savedZoomLevel;
            state.translateX = 0;
            state.translateY = 0;
            state.hasZoomChanged = false;
            saveZoomBtn.classList.remove('show');
            updateZoomControls();
            showNotification(`Zoom reset to ${Math.round(state.zoomLevel * 100)}%`);
        }

        function setupZoomControls() {
            // Zoom in button
            zoomInBtn.addEventListener('click', () => {
                if (state.currentMode !== 'mushaf') return;
                
                state.zoomLevel = Math.min(state.zoomLevel + state.zoomStep, state.maxZoom);
                updateZoomControls();
                showNotification(`Zoom: ${Math.round(state.zoomLevel * 100)}%`);
            });
            
            // Zoom out button
            zoomOutBtn.addEventListener('click', () => {
                if (state.currentMode !== 'mushaf') return;
                
                state.zoomLevel = Math.max(state.zoomLevel - state.zoomStep, state.minZoom);
                updateZoomControls();
                showNotification(`Zoom: ${Math.round(state.zoomLevel * 100)}%`);
            });
            
            // Button events
            saveZoomBtn.addEventListener('click', saveZoom);
            resetZoomBtn.addEventListener('click', resetZoom);
            
            // Pinch hint close button
            pinchHintClose.addEventListener('click', () => {
                pinchHint.classList.remove('show');
                localStorage.setItem('pinchHintSeen', 'true');
            });
            
            // Keyboard shortcuts
            document.addEventListener('keydown', (e) => {
                if (state.currentMode !== 'mushaf') return;
                
                // Plus/Minus keys for zoom
                if (e.key === '+' || e.key === '=') {
                    e.preventDefault();
                    state.zoomLevel = Math.min(state.zoomLevel + state.zoomStep, state.maxZoom);
                    updateZoomControls();
                    showNotification(`Zoom: ${Math.round(state.zoomLevel * 100)}%`);
                } else if (e.key === '-' || e.key === '_') {
                    e.preventDefault();
                    state.zoomLevel = Math.max(state.zoomLevel - state.zoomStep, state.minZoom);
                    updateZoomControls();
                    showNotification(`Zoom: ${Math.round(state.zoomLevel * 100)}%`);
                }
                // Ctrl/Cmd + S to save zoom
                else if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                    e.preventDefault();
                    if (state.hasZoomChanged) {
                        saveZoom();
                    }
                }
                // Ctrl/Cmd + R to reset zoom
                else if ((e.ctrlKey || e.metaKey) && e.key === 'r') {
                    e.preventDefault();
                    resetZoom();
                }
            });
            
            // Mouse wheel zoom (only for desktop)
            mushafViewer.addEventListener('wheel', (e) => {
                if (state.currentMode !== 'mushaf' || isMobile()) return;
                
                e.preventDefault();
                
                // Determine zoom direction
                if (e.deltaY < 0) {
                    // Scroll up = zoom in
                    state.zoomLevel = Math.min(state.zoomLevel + state.zoomStep, state.maxZoom);
                } else {
                    // Scroll down = zoom out
                    state.zoomLevel = Math.max(state.zoomLevel - state.zoomStep, state.minZoom);
                }
                
                updateZoomControls();
            }, { passive: false });
            
            // Mouse drag for panning (only when zoomed in)
            mushafViewer.addEventListener('mousedown', startDrag);
            mushafViewer.addEventListener('mousemove', drag);
            mushafViewer.addEventListener('mouseup', endDrag);
            mushafViewer.addEventListener('mouseleave', endDrag);
            
            // Touch events for mobile pinch zoom and pan
            // iOS Safari requires passive:false for preventDefault() to work.
            mushafViewer.addEventListener('touchstart', handleTouchStart, { passive: false });
            mushafViewer.addEventListener('touchmove', handleTouchMove, { passive: false });
            mushafViewer.addEventListener('touchend', handleTouchEnd, { passive: true });
            
            // Double-click to zoom in/out (works on both desktop and mobile)
            mushafPageImage.addEventListener('dblclick', (e) => {
                if (state.currentMode !== 'mushaf') return;
                
                if (state.zoomLevel === state.savedZoomLevel) {
                    // Double-click when at saved zoom zooms to 200%
                    state.zoomLevel = 2;
                } else {
                    // Double-click when zoomed resets to saved zoom
                    resetZoom();
                }
                updateZoomControls();
            });
            
            // Show pinch hint on first visit if on mobile
            if (localStorage.getItem('pinchHintSeen') !== 'true' && isMobile()) {
                setTimeout(() => {
                    pinchHint.classList.add('show');
                }, 1000);
            }

            // Ensure buttons state is initialized (especially on iOS where users rely on +/-).
            try { updateZoomControls(); } catch (e) {}
        }

        function isMobile() {
            return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
        }

        // Drag functionality
        function startDrag(e) {
            if (state.zoomLevel <= state.savedZoomLevel || isMobile()) return;
            
            state.isDragging = true;
            mushafViewer.classList.add('zoomed');
            mushafPageImage.classList.add('dragging');
            state.dragStartX = e.clientX - state.translateX;
            state.dragStartY = e.clientY - state.translateY;
        }

        function drag(e) {
            if (!state.isDragging || isMobile()) return;
            
            e.preventDefault();
            state.translateX = e.clientX - state.dragStartX;
            state.translateY = e.clientY - state.dragStartY;
            
            // Apply limits to prevent dragging too far
            const maxDrag = 100 * state.zoomLevel;
            state.translateX = Math.max(Math.min(state.translateX, maxDrag), -maxDrag);
            state.translateY = Math.max(Math.min(state.translateY, maxDrag), -maxDrag);
            
            mushafPageImage.style.transform = `scale(${state.zoomLevel}) translate(${state.translateX}px, ${state.translateY}px)`;
        }

        function endDrag() {
            if (state.isDragging) {
                state.isDragging = false;
                mushafViewer.classList.remove('zoomed');
                mushafPageImage.classList.remove('dragging');
            }
        }

        // Touch events for pinch zoom and pan (mobile only)
        let initialTouchDistance = 0;
        let initialZoom = state.savedZoomLevel;
        let isPinching = false;

        function handleTouchStart(e) {
            if (!isMobile()) return;
            
            if (e.touches.length === 2) {
                // Two fingers = pinch zoom
                e.preventDefault();
                isPinching = true;
                initialZoom = state.zoomLevel;
                const touch1 = e.touches[0];
                const touch2 = e.touches[1];
                initialTouchDistance = Math.hypot(
                    touch2.clientX - touch1.clientX,
                    touch2.clientY - touch1.clientY
                );
            } else if (e.touches.length === 1 && state.zoomLevel > state.savedZoomLevel) {
                // One finger = drag/pan
                startDrag({
                    clientX: e.touches[0].clientX,
                    clientY: e.touches[0].clientY
                });
            }
        }

        function handleTouchMove(e) {
            if (!isMobile()) return;
            
            if (isPinching && e.touches.length === 2) {
                // Pinch zoom
                e.preventDefault();
                const touch1 = e.touches[0];
                const touch2 = e.touches[1];
                const currentDistance = Math.hypot(
                    touch2.clientX - touch1.clientX,
                    touch2.clientY - touch1.clientY
                );
                
                const scaleFactor = currentDistance / initialTouchDistance;
                state.zoomLevel = Math.max(state.minZoom, Math.min(initialZoom * scaleFactor, state.maxZoom));
                
                updateZoomControls();
            } else if (state.isDragging && e.touches.length === 1) {
                // Drag/pan
                drag({
                    clientX: e.touches[0].clientX,
                    clientY: e.touches[0].clientY,
                    preventDefault: () => e.preventDefault()
                });
            }
        }

        function handleTouchEnd(e) {
            if (!isMobile()) return;
            
            if (isPinching) {
                isPinching = false;
            }
            endDrag();
        }

        // Function to get URL parameter
        function getUrlParameter(name) {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get(name);
        }

        // Some XAMPP setups serve JSON with the wrong charset header, which makes UTF-8 Arabic appear as mojibake
        // (e.g., "Ø§Ù„..."). This deterministically decodes it back to proper Arabic.
        // This is decoding of stored data, not generation.
        function repairMojibake(value) {
            let str = String(value ?? '');
            // ASCII-only: avoid future re-encoding corruption of these literals.
            str = str.replace(/\u00D8-/g, '\u00D8\u00B7').replace(/\uFFFD/g, '');
            if (!/[\u00C3\u00D8\u00D9\u00E2]/.test(str)) return str;
            try {
                const bytes = Uint8Array.from(str, ch => ch.charCodeAt(0));
                return new TextDecoder('utf-8').decode(bytes);
            } catch (_e) {
                return str;
            }
        }

        function repairDomText(root = document.body) {
            const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
            let node;
            while ((node = walker.nextNode())) {
                if (/[\u00C3\u00D8\u00D9\u00E2]/.test(node.nodeValue)) {
                    node.nodeValue = repairMojibake(node.nodeValue);
                }
            }
        }
        
        // Function to load surah data from JSON files
        async function loadSurahData(surahNumber) {
            try {
                const response = await fetch(`./data/quran/surah_${surahNumber}.json`);
                if (!response.ok) {
                    throw new Error(`Failed to load surah ${surahNumber}`);
                }
                return await response.json();
            } catch (error) {
                console.error('Error loading surah data:', error);
                return getFallbackSurahData(surahNumber);
            }
        }
        
        // Fallback function
        function getFallbackSurahData(surahNumber) {
            const metadata = state.surahMetadata[surahNumber];
            if (!metadata) {
                return {
                    surah: surahNumber,
                    hasBasmallah: surahNumber !== 9,
                    basmallah: DEFAULT_BASMALLAH_AR,
                    verses: [
                        {
                            ayah: 1,
                            arabic: "",
                            english: "Alif, Lam, Meem.",
                            hausa: "A. L~. M~."
                        }
                    ]
                };
            }
            
            const verses = [];
            for (let i = 1; i <= Math.min(5, metadata.verses); i++) {
                verses.push({
                    ayah: i,
                    arabic: `Verse ${i} in Arabic`,
                    english: `This is verse ${i} in English`,
                    hausa: `Wannan ayar ${i} ce a Hausa`
                });
            }
            
            return {
                surah: surahNumber,
                hasBasmallah: surahNumber !== 9,
                basmallah: DEFAULT_BASMALLAH_AR,
                verses: verses
            };
        }
        
        // Generate page metadata based on surah page ranges
        function generatePageMetadata() {
            const pageMetadata = {};
            
            // Initialize all pages
            for (let page = 1; page <= state.totalPages; page++) {
                pageMetadata[page] = {
                    surahs: [],
                    verses: {}
                };
            }
            
            // Populate surahs for each page
            Object.keys(state.surahMetadata).forEach(surahNum => {
                const surah = state.surahMetadata[surahNum];
                for (let page = surah.startPage; page <= surah.endPage; page++) {
                    if (pageMetadata[page]) {
                        pageMetadata[page].surahs.push(parseInt(surahNum));
                    }
                }
            });
            
            state.pageMetadata = pageMetadata;
        }
        
        // Get surah information for a specific page
        function getSurahsOnPage(page) {
            if (!state.pageMetadata[page]) {
                return [];
            }
            return state.pageMetadata[page].surahs.map(surahNum => ({
                number: surahNum,
                name: state.surahMetadata[surahNum].arabic,
                englishName: state.surahMetadata[surahNum].english
            }));
        }
        
        // Get page range for a specific surah
        function getPageRangeForSurah(surahNumber) {
            const surah = state.surahMetadata[surahNumber];
            if (!surah) return { start: 1, end: 1 };
            return { start: surah.startPage, end: surah.endPage };
        }

        function getEstimatedMushafPageForAyah(surahNumber, ayahNumber) {
            const range = getPageRangeForSurah(surahNumber);
            const meta = state.surahMetadata[surahNumber];
            const totalAyahs = Number(meta && meta.verses || 0);
            const start = Number(range.start || 1);
            const end = Number(range.end || start);
            if (end <= start || totalAyahs <= 1) return start;

            const safeAyah = Math.max(1, Math.min(Number(ayahNumber || 1), totalAyahs));
            const pageSpan = end - start;
            const progress = (safeAyah - 1) / Math.max(totalAyahs - 1, 1);
            const estimated = start + Math.round(progress * pageSpan);
            return Math.max(start, Math.min(end, estimated));
        }
        
        // Get surah from page number
        function getSurahFromPage(page) {
            for (let surahNum in state.surahMetadata) {
                const surah = state.surahMetadata[surahNum];
                if (page >= surah.startPage && page <= surah.endPage) {
                    return parseInt(surahNum);
                }
            }
            return 1; // Default to Al-Fatiha
        }
        
        // Load and display surah data
        async function loadAndDisplaySurah(surahNumber, options = {}) {
            state.isLoading = true;
            state.currentSurah = Number(surahNumber || 1);
            state.preloadedAudios.clear();
            state.preloadingAyahs.clear();
            loader.style.display = 'block';
            ayahList.innerHTML = '';
            
            try {
                const metadata = state.surahMetadata[surahNumber] || {
                    arabic: "Unknown",
                    english: "Unknown",
                    revelation: "mecca",
                    verses: 0,
                    start: 1
                };
                // Restore Arabic metadata name if it was corrupted.
                if (SURAH_AR[surahNumber]) {
                    metadata.arabic = SURAH_AR[surahNumber];
                }
                
                state.surahInfo = {
                    arabicName: metadata.arabic,
                    englishName: metadata.english,
                    revelationType: metadata.revelation === 'mecca' ? 'Meccan' : 'Medinan',
                    totalAyahs: metadata.verses
                };
                
                updateSurahInfo();
                
                const surahData = await loadSurahData(surahNumber);
                
                state.ayahs = surahData.verses.map(verse => ({
                    number: verse.ayah,
                    arabic: repairMojibake(verse.arabic),
                    english: verse.english || "",
                    hausa: verse.hausa || ""
                }));
                
                if (surahNumber !== 9) {
                    const bEl = document.querySelector('.basmallah-arabic');
                    const bas = (surahData && surahData.basmallah) ? repairMojibake(surahData.basmallah) : DEFAULT_BASMALLAH_AR;
                    if (bEl) bEl.textContent = bas;
                    updateBasmallahTranslation();
                    basmallahBanner.style.display = 'block';
                } else {
                    basmallahBanner.style.display = 'none';
                }
                
                renderAyahList();
                repairDomText(ayahList);
                highlightTargetAyah();
                currentSurahName.textContent = metadata.english;
                
                // Set current page based on surah
                const pageRange = getPageRangeForSurah(surahNumber);
                if (state.currentMode === 'mushaf' && options.syncMushaf !== false) {
                    updateMushafPage(pageRange.start);
                } else {
                    state.currentPage = pageRange.start;
                    updatePageNavigation();
                }
                
                // Preload first few ayahs for smooth playback
                preloadAyahs(1, 5);
                
            } catch (error) {
                console.error('Error loading surah:', error);
                showError('Failed to load surah data. Please try again.');
            } finally {
                state.isLoading = false;
                loader.style.display = 'none';
            }
        }
        
        // Preload ayahs
        async function preloadAyahs(startAyah, count = 16) {
            if (!state.ayahs.length) return;

            const endAyah = Math.min(startAyah + count - 1, state.ayahs.length);
            const preloadTasks = [];
            const surahNumber = Number(state.currentSurah || 0);

            for (let i = startAyah; i <= endAyah; i++) {
                const cacheKey = getAudioCacheKey(surahNumber, i);
                if (state.preloadedAudios.has(cacheKey) || state.preloadingAyahs.has(cacheKey)) continue;
                const audioUrl = getAudioUrl(i);
                try {
                    state.preloadingAyahs.add(cacheKey);
                    const audio = new Audio();
                    audio.src = audioUrl;
                    audio.preload = 'auto';

                    state.preloadedAudios.set(cacheKey, {
                        audio: audio,
                        url: audioUrl,
                        loaded: false
                    });

                    preloadTasks.push(new Promise((resolve) => {
                        const markLoaded = () => {
                            const cached = state.preloadedAudios.get(cacheKey);
                            if (cached) cached.loaded = true;
                            state.preloadingAyahs.delete(cacheKey);
                            resolve();
                        };
                        const markTimeout = () => {
                            state.preloadingAyahs.delete(cacheKey);
                            resolve();
                        };
                        audio.addEventListener('canplaythrough', markLoaded, { once: true });
                        audio.addEventListener('canplay', markLoaded, { once: true });
                        audio.addEventListener('loadeddata', markLoaded, { once: true });
                        audio.addEventListener('error', markTimeout, { once: true });
                        setTimeout(markTimeout, 2600);
                    }));
                } catch (error) {
                    state.preloadingAyahs.delete(cacheKey);
                    console.warn(`Failed to preload ayah ${i}:`, error);
                }
            }

            await Promise.allSettled(preloadTasks);
        }
        
        // Get preloaded audio if available
        function getPreloadedAudio(ayahNumber) {
            const cacheKey = getAudioCacheKey(state.currentSurah, ayahNumber);
            if (state.preloadedAudios.has(cacheKey)) {
                const cached = state.preloadedAudios.get(cacheKey);
                if (cached.loaded) {
                    return cached.audio;
                }
            }
            return null;
        }
        
        // Update basmallah translation
        function updateBasmallahTranslation() {
            const translations = {
                'en': "In the name of Allah, the Entirely Merciful, the Especially Merciful.",
                'ha': "Da sunan Allah, Mai rahama, Mai jin ?ai.",
                'ar': DEFAULT_BASMALLAH_AR
            };
            basmallahTranslation.textContent = translations[state.currentLanguage] || translations['en'];
        }
        
        // Update surah info in header
        function updateSurahInfo() {
            arabicTitle.textContent = state.surahInfo.arabicName;
            englishTitle.textContent = state.surahInfo.englishName;
            updateLanguageIndicator();
        }
        
        // Update language indicator
        function updateLanguageIndicator() {
            const languageNames = {
                'en': 'English',
                'ha': 'Hausa',
                'ar': 'Arabic'
            };
            languageIndicator.textContent = languageNames[state.currentLanguage] || 'English';
        }
        
        // Get translation based on current language
        function getTranslation(ayah) {
            switch(state.currentLanguage) {
                case 'en':
                    return ayah.english || "Translation not available";
                case 'ha':
                    return ayah.hausa || ayah.english || "Fassarar ba ta samuwa";
                case 'ar':
                    return ayah.arabic;
                default:
                    return ayah.english || "Translation not available";
            }
        }
        
        // Change translation language
        async function changeTranslation(langCode, showNotification = true) {
            if (langCode === 'fr' || langCode === 'ur') {
                showNotification('This language will be available soon');
                return;
            }
            
            state.currentLanguage = langCode;
            
            // Update language selection UI
            document.querySelectorAll('.language-item').forEach(item => {
                const icon = item.querySelector('.fas.fa-check');
                if (item.dataset.lang === langCode) {
                    icon.style.display = 'block';
                    item.classList.add('active');
                } else {
                    icon.style.display = 'none';
                    item.classList.remove('active');
                }
            });
            
            // Update language indicator
            updateLanguageIndicator();
            
            // Update basmallah translation
            updateBasmallahTranslation();
            
            // Update all ayah translations
            updateAyahTranslations();
            
            if (showNotification) {
                showNotification(`Language changed to ${getLanguageName(langCode)}`);
            }
        }
        
        // Update all ayah translations
        function updateAyahTranslations() {
            document.querySelectorAll('.ayah-card').forEach((card, index) => {
                const ayah = state.ayahs[index];
                if (ayah) {
                    const translationElement = card.querySelector('.ayah-translation');
                    if (translationElement) {
                        translationElement.textContent = getTranslation(ayah);
                    }
                }
            });
        }
        
        // Helper function to get language name
        function getLanguageName(langCode) {
            const languages = {
                'en': 'English',
                'ha': 'Hausa',
                'fr': 'French',
                'ur': 'Urdu'
            };
            return languages[langCode] || langCode;
        }
        
        // Get audio URL for the selected reciter.
        // The URL mode is provided by backend (absolute_ayah or surah_ayah).
        function getAudioUrl(ayahNumber) {
            const reciter = audioUrls[state.currentReciter];
            
            if (!reciter || !reciter.working) {
                // Fallback to Alafasy
                const absoluteAyah = getAbsoluteAyahNumber(state.currentSurah, ayahNumber);
                return `https://cdn.islamic.network/quran/audio/64/ar.alafasy/${absoluteAyah}.mp3`;
            }
            
            if (String(reciter.urlMode || '') === 'surah_ayah') {
                // everyayah-style format: .../001001.mp3 (surah 3 digits + ayah 3 digits)
                const surahStr = state.currentSurah.toString().padStart(3, '0');
                const ayahStr = ayahNumber.toString().padStart(3, '0');
                return `${reciter.baseUrl}/${surahStr}${ayahStr}.${reciter.format}`;
            } else {
                // islamic.network-style format: .../{absoluteAyah}.mp3
                const absoluteAyah = getAbsoluteAyahNumber(state.currentSurah, ayahNumber);
                return `${reciter.baseUrl}/${absoluteAyah}.${reciter.format}`;
            }
        }
        
        // Get absolute ayah number (Quran-wide numbering)
        function getAbsoluteAyahNumber(surahNumber, ayahNumber) {
            let totalVerses = 0;
            for (let i = 1; i < surahNumber; i++) {
                if (state.surahMetadata[i]) {
                    totalVerses += state.surahMetadata[i].verses;
                }
            }
            return totalVerses + ayahNumber;
        }

        function getAudioCacheKey(surahNumber, ayahNumber) {
            return `${Number(surahNumber || 0)}:${Number(ayahNumber || 0)}`;
        }
        
        // Render ayah list
        function renderAyahList() {
            ayahList.innerHTML = '';
            
            state.ayahs.forEach((ayah, index) => {
                const ayahNumber = index + 1;
                
                const ayahCard = document.createElement('div');
                ayahCard.className = 'ayah-card';
                ayahCard.setAttribute('data-ayah', ayahNumber);
                ayahCard.innerHTML = `
                    <div class="ayah-header">
                        <div class="ayah-number-badge">${ayahNumber}</div>
                    </div>
                    <div class="ayah-arabic">${ayah.arabic}</div>
                    <div class="ayah-translation">${getTranslation(ayah)}</div>
                    <div class="ayah-actions">
                        <button class="action-btn play" data-ayah="${ayahNumber}" title="Play This Ayah">
                            <i class="fas fa-play"></i>
                        </button>
                        <button class="action-btn copy" data-ayah="${ayahNumber}" title="Copy">
                            <i class="far fa-copy"></i>
                        </button>
                        <button class="action-btn share" data-ayah="${ayahNumber}" title="Share">
                            <i class="fas fa-share-alt"></i>
                        </button>
                    </div>
                `;
                
                ayahList.appendChild(ayahCard);
            });
            
            attachAyahEventListeners();
        }

        function highlightTargetAyah() {
            const ayahNumber = Number(state.targetAyah || 0);
            if (!Number.isFinite(ayahNumber) || ayahNumber <= 0) return;
            if (!state.ayahs || ayahNumber > state.ayahs.length) return;

            const target = document.querySelector(`.ayah-card:nth-child(${ayahNumber})`);
            if (!target) return;

            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            target.classList.add('target-highlight');
            setTimeout(() => target.classList.remove('target-highlight'), 3000);
        }
        
        // Show error message
        function showError(message) {
            ayahList.innerHTML = `
                <div class="error-message">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h3>Something went wrong</h3>
                    <p>${message}</p>
                    <button class="retry-btn" id="retryBtn">Try Again</button>
                </div>
            `;
            
            document.getElementById('retryBtn').addEventListener('click', () => {
                loadAndDisplaySurah(state.currentSurah);
            });
        }
        
        // Show loading state on play button
        function showPlayButtonLoading(isLoading) {
            if (isLoading) {
                playBtn.classList.add('loading');
                playBtn.disabled = true;
            } else {
                playBtn.classList.remove('loading');
                playBtn.disabled = false;
            }
        }
        
        // Show loading state on ayah play button
        function showAyahPlayButtonLoading(ayahNumber, isLoading) {
            const ayahBtn = document.querySelector(`.action-btn.play[data-ayah="${ayahNumber}"]`);
            if (ayahBtn) {
                if (isLoading) {
                    ayahBtn.classList.add('loading');
                    ayahBtn.disabled = true;
                } else {
                    ayahBtn.classList.remove('loading');
                    ayahBtn.disabled = false;
                }
            }
        }
        
        // Play single ayah
        async function playSingleAyah(ayahNumber) {
            if (state.isLoadingAudio) return;
            
            state.playMode = 'single';
            state.currentAyah = ayahNumber;
            updatePlayModeIndicator();
            state.audioQueue = [];
            
            showAyahPlayButtonLoading(ayahNumber, true);
            state.isLoadingAudio = true;
            
            await playAyah(ayahNumber, true);
            
            state.isLoadingAudio = false;
            showAyahPlayButtonLoading(ayahNumber, false);
        }
        
        // Play full surah
        async function playFullSurah(startAyah = 1) {
            if (state.isLoadingAudio) return;

            state.playMode = 'surah';
            state.currentAyah = startAyah;
            updatePlayModeIndicator();

            state.audioQueue = [];
            for (let i = startAyah; i <= state.ayahs.length; i++) {
                state.audioQueue.push(i);
            }

            if (state.audioQueue.length > 0) {
                showPlayButtonLoading(true);
                state.isLoadingAudio = true;

                await playAyah(state.audioQueue[0], false);

                state.isLoadingAudio = false;
                showPlayButtonLoading(false);
            }
        }
        
        // Play specific ayah
        async function playAyah(ayahNumber, isSingleMode = false) {
            state.currentAyah = ayahNumber;
            currentAyahNumber.textContent = ayahNumber;

            const audioUrl = getAudioUrl(ayahNumber);
            const shouldReloadSource = audioElement.src !== audioUrl;
            const resumeFraction = shouldReloadSource ? state.pendingAudioSeekFraction : null;
            state.pendingAudioSeekFraction = null;

            if (shouldReloadSource) {
                const preloadedAudio = getPreloadedAudio(ayahNumber);
                if (preloadedAudio) {
                    audioElement.src = preloadedAudio.currentSrc || preloadedAudio.src || audioUrl;
                    audioElement.currentTime = 0;
                } else {
                    audioElement.src = audioUrl;
                }
            }

            audioElement.playbackRate = state.currentSpeed;

            if (isSingleMode) {
                showNotification(`Playing Ayah ${ayahNumber}`);
            }

            if (resumeFraction != null) {
                const applyResumeTime = () => {
                    if (Number.isFinite(audioElement.duration) && audioElement.duration > 0) {
                        audioElement.currentTime = Math.max(0, Math.min(resumeFraction * audioElement.duration, Math.max(audioElement.duration - 0.1, 0)));
                    }
                };
                if (audioElement.readyState >= 1) {
                    applyResumeTime();
                } else {
                    audioElement.addEventListener('loadedmetadata', applyResumeTime, { once: true });
                }
            }

            try {
                await audioElement.play();
                playBtn.innerHTML = '<i class="fas fa-pause"></i>';
                state.isPlaying = true;
                highlightPlayingAyah(ayahNumber, { force: true });

                if (state.playMode === 'surah') {
                    const currentIndex = state.audioQueue.indexOf(ayahNumber);
                    if (currentIndex !== -1) {
                        const nextAyah = state.audioQueue[currentIndex + 1];
                        if (nextAyah) {
                            preloadAyahs(nextAyah, 16);
                        }
                    }
                }

            } catch (error) {
                console.error('Error playing audio:', error);
                handleAudioError(ayahNumber, isSingleMode);
            }
        }
        
        function handleAudioError(ayahNumber, isSingleMode) {
            const fallbackUrl = getAudioUrl(ayahNumber);
            
            if (audioElement.src !== fallbackUrl) {
                audioElement.src = fallbackUrl;
                audioElement.play()
                    .then(() => {
                        playBtn.innerHTML = '<i class="fas fa-pause"></i>';
                        state.isPlaying = true;
                        highlightPlayingAyah(ayahNumber, { force: true });
                    })
                    .catch(fallbackError => {
                        console.error('Fallback also failed:', fallbackError);
                        playBtn.innerHTML = '<i class="fas fa-play"></i>';
                        state.isPlaying = false;
                        showNotification('Failed to play audio. Please check your connection.');
                    });
            } else {
                playBtn.innerHTML = '<i class="fas fa-play"></i>';
                state.isPlaying = false;
                showNotification('Failed to play audio. Please check your connection.');
            }
        }
        
        // Toggle play/pause
        async function togglePlayPause() {
            if (state.isLoadingAudio) return;

            if (!audioElement.src) {
                await playFullSurah(state.currentAyah || 1);
                return;
            }

            if (audioElement.paused) {
                try {
                    await audioElement.play();
                    playBtn.innerHTML = '<i class="fas fa-pause"></i>';
                    state.isPlaying = true;
                    highlightPlayingAyah(state.currentAyah, { force: false });
                } catch (error) {
                    console.error('Error resuming audio:', error);
                    state.isPlaying = false;
                    playBtn.innerHTML = '<i class="fas fa-play"></i>';
                }
            } else {
                audioElement.pause();
                playBtn.innerHTML = '<i class="fas fa-play"></i>';
                state.isPlaying = false;
            }
        }
        
        // Update play mode indicator
        function updatePlayModeIndicator() {
            if (state.playMode === 'surah') {
                playModeIndicator.textContent = 'Surah Mode';
                playModeIndicator.style.color = '#4CAF50';
            } else {
                playModeIndicator.textContent = 'Single Ayah';
                playModeIndicator.style.color = '#FF9800';
            }
        }
        
        // Highlight playing ayah
        function scrollPlayingAyahIntoView(ayahNumber, force = false) {
            if (state.currentMode !== 'text') return;
            const targetCard = document.querySelector(`.ayah-card:nth-child(${ayahNumber})`);
            if (!targetCard) return;

            const now = Date.now();
            const rect = targetCard.getBoundingClientRect();
            const viewportHeight = window.innerHeight || document.documentElement.clientHeight || 0;
            const comfortablyVisible = rect.top >= 110 && rect.bottom <= (viewportHeight - 140);

            if (!force) {
                if (state.lastTrackedAyah === ayahNumber && (now - Number(state.lastTrackedScrollAt || 0)) < 1200) return;
                if (comfortablyVisible) {
                    state.lastTrackedAyah = ayahNumber;
                    return;
                }
            }

            targetCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
            state.lastTrackedAyah = ayahNumber;
            state.lastTrackedScrollAt = now;
        }

        function highlightPlayingAyah(ayahNumber, options = {}) {
            document.querySelectorAll('.action-btn.play').forEach(btn => {
                btn.classList.remove('active', 'loading');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-play"></i>';
            });
            document.querySelectorAll('.ayah-card').forEach(card => {
                card.classList.remove('audio-playing');
            });

            const currentCard = document.querySelector(`.ayah-card:nth-child(${ayahNumber})`);
            const currentAyahBtn = document.querySelector(`.ayah-card:nth-child(${ayahNumber}) .action-btn.play`);
            if (currentCard) {
                currentCard.classList.add('audio-playing');
            }
            if (currentAyahBtn) {
                currentAyahBtn.classList.add('active');
                currentAyahBtn.innerHTML = '<i class="fas fa-volume-up"></i>';
            }

            if (options.track !== false) {
                scrollPlayingAyahIntoView(ayahNumber, !!options.force);
            }
            syncMushafPageToCurrentAyah(ayahNumber, !!options.force);
        }

        function ensureNextSurahModal() {
            if (document.getElementById('nextSurahModal')) return;
            const modal = document.createElement('div');
            modal.id = 'nextSurahModal';
            modal.style.cssText = 'position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.6);z-index:100000;padding:16px;';
            modal.innerHTML = `
                <div style="width:min(420px,100%);background:var(--white,#fff);color:var(--text-dark,#222);border-radius:18px;padding:20px;box-shadow:0 18px 40px rgba(0,0,0,.28);font-family:inherit;">
                    <div style="font-size:18px;font-weight:800;color:var(--primary-green,#1D6F42);margin-bottom:8px;">Moving to next surah</div>
                    <div id="nextSurahModalBody" style="font-size:14px;line-height:1.6;color:inherit;margin-bottom:14px;"></div>
                    <div style="display:flex;gap:10px;justify-content:flex-end;">
                        <button type="button" id="nextSurahCancelBtn" style="border:1px solid #d1d5db;background:#fff;color:#333;border-radius:10px;padding:10px 14px;cursor:pointer;font-weight:700;">Cancel</button>
                        <button type="button" id="nextSurahOkBtn" style="border:0;background:#1D6F42;color:#fff;border-radius:10px;padding:10px 14px;cursor:pointer;font-weight:700;">Okay</button>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
            modal.addEventListener('click', (e) => {
                if (e.target === modal) cancelNextSurahTransition();
            });
            modal.querySelector('#nextSurahCancelBtn')?.addEventListener('click', cancelNextSurahTransition);
            modal.querySelector('#nextSurahOkBtn')?.addEventListener('click', () => proceedToNextSurah(true));
        }

        function hideNextSurahModal() {
            const modal = document.getElementById('nextSurahModal');
            if (modal) modal.style.display = 'none';
        }

        function updateNextSurahModalCountdown() {
            const body = document.getElementById('nextSurahModalBody');
            if (!body) return;
            const next = state.surahMetadata[state.nextSurahTarget] || null;
            const nextName = next ? `${next.english} (${next.arabic || ''})` : `Surah ${state.nextSurahTarget}`;
            const seconds = Math.max(0, Number(state.nextSurahCountdownValue || 0));
            body.innerHTML = `Current surah finished. Moving to <strong>${nextName}</strong> in <strong>${seconds}</strong> second${seconds === 1 ? '' : 's'}...`;
        }

        function cancelNextSurahTransition() {
            if (state.nextSurahTimer) clearInterval(state.nextSurahTimer);
            state.nextSurahTimer = null;
            state.nextSurahCountdownValue = 0;
            state.nextSurahTarget = 0;
            state.isTransitioningSurah = false;
            hideNextSurahModal();
            playBtn.innerHTML = '<i class="fas fa-play"></i>';
            state.isPlaying = false;
        }

        async function proceedToNextSurah(fromUser = false) {
            const nextSurah = Number(state.nextSurahTarget || 0);
            if (nextSurah <= 0 || nextSurah > 114) {
                cancelNextSurahTransition();
                return;
            }
            if (state.nextSurahTimer) {
                clearInterval(state.nextSurahTimer);
                state.nextSurahTimer = null;
            }
            hideNextSurahModal();
            state.isTransitioningSurah = true;
            try {
                resetAudioSourceForSurahTransition();
                state.currentAyah = 1;
                state.lastTrackedAyah = 0;
                state.lastTrackedScrollAt = 0;
                state.lastTrackedMushafPage = 0;
                state.currentSurah = nextSurah;
                const nextUrl = new URL(window.location.href);
                nextUrl.searchParams.set('surah', String(nextSurah));
                nextUrl.searchParams.delete('ayah');
                window.history.replaceState({}, '', nextUrl.toString());
                await loadAndDisplaySurah(nextSurah);
                await playFullSurah(1);
                if (fromUser) showNotification('Playing next surah');
            } catch (error) {
                console.error('Error moving to next surah:', error);
                showNotification('Failed to move to the next surah');
                playBtn.innerHTML = '<i class="fas fa-play"></i>';
                state.isPlaying = false;
            } finally {
                state.nextSurahCountdownValue = 0;
                state.nextSurahTarget = 0;
                state.isTransitioningSurah = false;
            }
        }

        function promptNextSurahTransition() {
            const nextSurah = Number(state.currentSurah || 0) + 1;
            if (nextSurah > 114) {
                playBtn.innerHTML = '<i class="fas fa-play"></i>';
                state.isPlaying = false;
                showNotification('End of Quran');
                return;
            }
            ensureNextSurahModal();
            state.nextSurahTarget = nextSurah;
            state.nextSurahCountdownValue = 3;
            updateNextSurahModalCountdown();
            const modal = document.getElementById('nextSurahModal');
            if (modal) modal.style.display = 'flex';
            if (state.nextSurahTimer) clearInterval(state.nextSurahTimer);
            state.nextSurahTimer = setInterval(() => {
                state.nextSurahCountdownValue -= 1;
                if (state.nextSurahCountdownValue <= 0) {
                    proceedToNextSurah(false);
                    return;
                }
                updateNextSurahModalCountdown();
            }, 1000);
        }

        function syncMushafPageToCurrentAyah(ayahNumber, force = false) {
            return;
        }

        function resetAudioSourceForSurahTransition() {
            try {
                audioElement.pause();
            } catch (_) {}
            try {
                audioElement.removeAttribute('src');
                audioElement.load();
            } catch (_) {
                try {
                    audioElement.src = '';
                } catch (_) {}
            }
            state.audioQueue = [];
            state.preloadedAudios.clear();
            state.preloadingAyahs.clear();
            state.pendingAudioSeekFraction = null;
            state.isLoadingAudio = false;
            state.isPlaying = false;
        }
        
        // Update progress bar
        function updateProgressBar() {
            if (!audioElement.duration || !Number.isFinite(audioElement.duration)) return;

            let percentage = 0;
            if (state.playMode === 'surah' && state.audioQueue.length > 0) {
                const currentIndex = state.audioQueue.indexOf(state.currentAyah);
                const safeIndex = currentIndex === -1 ? 0 : currentIndex;
                const ayahFraction = Math.max(0, Math.min(audioElement.currentTime / audioElement.duration, 1));
                percentage = ((safeIndex + ayahFraction) / state.audioQueue.length) * 100;
            } else {
                percentage = (audioElement.currentTime / audioElement.duration) * 100;
            }
            progress.style.width = `${Math.max(0, Math.min(percentage, 100))}%`;
        }
        
        // Seek audio
        function seekAudio(event) {
            if (!audioElement.duration || state.isLoadingAudio) return;

            const rect = progressBar.getBoundingClientRect();
            const pos = Math.max(0, Math.min((event.clientX - rect.left) / rect.width, 1));

            if (state.playMode === 'surah' && state.audioQueue.length > 0) {
                const scaled = pos * state.audioQueue.length;
                const targetIndex = Math.min(Math.max(Math.floor(scaled), 0), state.audioQueue.length - 1);
                const targetAyah = state.audioQueue[targetIndex];
                const fractional = scaled - targetIndex;

                if (targetAyah === state.currentAyah && Number.isFinite(audioElement.duration)) {
                    audioElement.currentTime = fractional * audioElement.duration;
                    updateProgressBar();
                    return;
                }

                state.pendingAudioSeekFraction = fractional;
                playAyah(targetAyah, false);
                return;
            }

            audioElement.currentTime = pos * audioElement.duration;
            updateProgressBar();
        }
        
        // Change reciter
        function changeReciter(reciter) {
            const r = state.reciterByKey ? state.reciterByKey[reciter] : null;
            if (r && r.is_locked) {
                openUnlockReciterModal(reciter);
                return;
            }

            state.currentReciter = reciter;
            state.preloadedAudios.clear();
            try { localStorage.setItem('deenlink.quran.reciter', reciter); } catch (_) {}
            
            // Update dropdown UI (unlocked items show check; locked items show lock).
            if (settingsDropdown) {
                settingsDropdown.querySelectorAll('.dropdown-item[data-reciter]').forEach(item => {
                    const key = String(item.getAttribute('data-reciter') || '');
                    const locked = String(item.getAttribute('data-locked') || '0') === '1';
                    const icon = item.querySelector('i.fas');
                    if (!icon) return;
                    if (locked) {
                        // Keep lock visible.
                        icon.style.display = 'block';
                        item.classList.remove('active');
                        return;
                    }
                    if (key === reciter) {
                        icon.style.display = 'block';
                        item.classList.add('active');
                    } else {
                        icon.style.display = 'none';
                        item.classList.remove('active');
                    }
                });
            }
            
            if (state.isPlaying) {
                if (state.playMode === 'surah') {
                    playFullSurah(state.currentAyah);
                } else {
                    playSingleAyah(state.currentAyah);
                }
            }
            
            showNotification(`Reciter: ${getReciterDisplayName(reciter)}`);
        }
        
        function getReciterDisplayName(reciterKey) {
            try {
                const r = state.reciterByKey ? state.reciterByKey[reciterKey] : null;
                if (r && r.name) return String(r.name);
            } catch (_) {}
            const names = {
                'mishary': 'Mishary Alafasy',
                'abdulbasit': 'Abdul Basit',
                'saad': 'Saad Al Ghamdi',
                'maher': 'Maher Al Muaiqly',
                'sudais': 'Abdul Rahman Al-Sudais',
                'shuraim': 'Saud Al-Shuraim',
                'ayyub': 'Muhammad Ayyub',
                'yasser_aldosari': 'Yasser Al-Dosari'
            };
            return names[reciterKey] || reciterKey;
        }
        
        // Cycle through speed options
        function cycleSpeed() {
            const currentIndex = speedOptions.indexOf(state.currentSpeed);
            const nextIndex = (currentIndex + 1) % speedOptions.length;
            const nextSpeed = speedOptions[nextIndex];
            
            state.currentSpeed = nextSpeed;
            audioElement.playbackRate = state.currentSpeed;
            speedBtn.textContent = `${nextSpeed}x`;
            showNotification(`Speed: ${nextSpeed}x`);
        }
        
        // Bookmarking is handled in the selection pages (surah.html).
        
        // Copy ayah text
        function copyAyahText(ayahNumber) {
            const ayah = state.ayahs[ayahNumber - 1];
            const textToCopy = `${ayah.arabic}\n\n${getTranslation(ayah)}`;
            
            navigator.clipboard.writeText(textToCopy)
                .then(() => showNotification('Ayah copied to clipboard'))
                .catch(err => showNotification('Failed to copy ayah'));
        }
        
        // Share ayah
        function shareAyah(ayahNumber) {
            const ayah = state.ayahs[ayahNumber - 1];
            const shareText = `Surah ${state.surahInfo.englishName}, Ayah ${ayahNumber}:\n\n${ayah.arabic}\n\n${getTranslation(ayah)}`;
            
            if (navigator.share) {
                navigator.share({
                    title: `Quran Ayah ${ayahNumber}`,
                    text: shareText,
                    url: window.location.href
                });
            } else {
                navigator.clipboard.writeText(shareText)
                    .then(() => showNotification('Ayah text copied to clipboard'))
                    .catch(err => console.error('Failed to share:', err));
            }
        }
        
        // Show notification
        function showNotification(message) {
            const existing = document.querySelector('.notification');
            if (existing) existing.remove();
            
            const notification = document.createElement('div');
            notification.className = 'notification';
            notification.innerHTML = `
                <i class="fas fa-check-circle"></i>
                ${message}
            `;
            
            document.body.appendChild(notification);
            
            // Auto-remove after 3 seconds
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 3000);
        }
        
        // Attach event listeners to ayah action buttons
        function attachAyahEventListeners() {
            document.querySelectorAll('.action-btn.play').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    if (state.isLoadingAudio) return;
                    
                    e.stopPropagation();
                    const ayahNumber = parseInt(btn.dataset.ayah);
                    playSingleAyah(ayahNumber);
                });
            });
            
            document.querySelectorAll('.action-btn.copy').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const ayahNumber = parseInt(btn.dataset.ayah);
                    copyAyahText(ayahNumber);
                });
            });
            
            document.querySelectorAll('.action-btn.share').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const ayahNumber = parseInt(btn.dataset.ayah);
                    shareAyah(ayahNumber);
                });
            });
        }
        
        // Setup audio event listeners
        function setupAudioEvents() {
            audioElement.addEventListener('timeupdate', updateProgressBar);
            audioElement.addEventListener('timeupdate', () => {
                if (state.playMode !== 'surah' || !state.isPlaying || state.isLoadingAudio) return;
                const currentFraction = (!audioElement.duration || !Number.isFinite(audioElement.duration))
                    ? 0
                    : (audioElement.currentTime / audioElement.duration);
                if (currentFraction < 0.08 && state.lastTrackedAyah === state.currentAyah) return;
                highlightPlayingAyah(state.currentAyah, { force: currentFraction < 0.12 });
            });
            audioElement.addEventListener('timeupdate', () => {
                if (state.playMode !== 'surah' || !audioElement.duration || !Number.isFinite(audioElement.duration)) return;
                const currentIndex = state.audioQueue.indexOf(state.currentAyah);
                if (currentIndex === -1 || currentIndex >= state.audioQueue.length - 1) return;
                const remaining = audioElement.duration - audioElement.currentTime;
                if (remaining > 4) return;
                const nextAyah = state.audioQueue[currentIndex + 1];
                if (nextAyah) preloadAyahs(nextAyah, 16);
            });
            
            // Keep the handoff between ayahs short so recitation feels continuous.
            audioElement.addEventListener('ended', async () => {
                if (state.playMode === 'surah') {
                    const currentIndex = state.audioQueue.indexOf(state.currentAyah);
                    if (currentIndex !== -1 && currentIndex < state.audioQueue.length - 1) {
                        const nextAyah = state.audioQueue[currentIndex + 1];
                        
                        showPlayButtonLoading(true);
                        state.isLoadingAudio = true;
                        
                        preloadAyahs(nextAyah, 16);
                        setTimeout(async () => {
                            await playAyah(nextAyah, false);
                            state.isLoadingAudio = false;
                            showPlayButtonLoading(false);
                        }, 1);
                    } else {
                        playBtn.innerHTML = '<i class="fas fa-play"></i>';
                        state.isPlaying = false;
                        promptNextSurahTransition();
                    }
                } else {
                    playBtn.innerHTML = '<i class="fas fa-play"></i>';
                    state.isPlaying = false;
                }
            });
            
            audioElement.addEventListener('error', (e) => {
                console.error('Audio error:', e);
                state.isLoadingAudio = false;
                showPlayButtonLoading(false);
                showNotification('Audio error. Please try again.');
            });
            
            audioElement.addEventListener('waiting', () => {
                showPlayButtonLoading(true);
            });
            
            audioElement.addEventListener('canplay', () => {
                showPlayButtonLoading(false);
            });
        }
        
        // Apply dark mode
        function applyDarkMode() {
            if (state.isDarkMode) {
                body.classList.add('dark-theme');
                body.classList.remove('light-theme');
            } else {
                body.classList.remove('dark-theme');
                body.classList.add('light-theme');
            }
        }
        
        // ============================================
        // MUSHAF MODE FUNCTIONS
        // ============================================
        
        // Toggle between text and mushaf modes
        function toggleMode() {
            if (state.currentMode === 'text') {
                // Switch to Mushaf mode
                state.currentMode = 'mushaf';
                textModeContent.style.display = 'none';
                mushafModeContent.style.display = 'block';
                modeToggle.innerHTML = '<i class="fas fa-exchange-alt"></i><span>Mushaf / Text</span>';
                
                // Follow current recitation page when audio is active; otherwise open at the surah start.
                const targetPage = (state.playMode === 'surah' && state.currentAyah)
                    ? getEstimatedMushafPageForAyah(state.currentSurah, state.currentAyah)
                    : getPageRangeForSurah(state.currentSurah).start;
                updateMushafPage(targetPage);
                updatePageNavigation();
                
                showNotification('Switched to Mushaf mode');
            } else {
                // Switch to Text mode
                state.currentMode = 'text';
                textModeContent.style.display = 'block';
                mushafModeContent.style.display = 'none';
                modeToggle.innerHTML = '<i class="fas fa-exchange-alt"></i><span>Text / Mushaf</span>';
                
                showNotification('Switched to Text mode');
            }
        }
        
        // Get file number for webp image (pages start from 002, so page 1 = file 002)
        function getFileNumber(page) {
            // Page 1 = file 002, Page 2 = file 003, etc.
            return (page + 1).toString().padStart(3, '0');
        }
        
        // FIXED: Update mushaf page image with perfect centering and saved/default zoom
        async function updateMushafPage(targetPage = state.currentPage) {
            const page = Math.max(1, Math.min(state.totalPages, Number(targetPage || state.currentPage) || 1));
            const fileNumber = getFileNumber(page);
            const imageUrl = `./data/mushaf/pages/page_${fileNumber}.webp`;
            const token = ++state.mushafLoadToken;
            state.isMushafPageLoading = true;
            state.pendingMushafPage = page;

            mushafLoader.style.display = 'block';
            mushafPageImage.classList.add('loading');
            prevPageBtn.disabled = true;
            nextPageBtn.disabled = true;
            desktopPrevBtn.disabled = true;
            desktopNextBtn.disabled = true;
            jumpPageBtn.disabled = true;
            pageInput.disabled = true;
            
            try {
                const img = new Image();
                img.src = imageUrl;
                
                await new Promise((resolve, reject) => {
                    img.onload = resolve;
                    img.onerror = reject;
                });
                if (token !== state.mushafLoadToken) return;

                state.currentPage = page;
                state.lastTrackedMushafPage = page;
                state.translateX = 0;
                state.translateY = 0;
                mushafPageImage.src = imageUrl;
                mushafPageImage.style.display = 'block';
                mushafPageImage.style.margin = '0 auto';
                mushafPageImage.style.position = 'relative';
                mushafPageImage.style.left = '0';
                mushafPageImage.style.top = '0';
                currentPageElement.textContent = page;
                totalPagesElement.textContent = state.totalPages;
                updatePageAndSurahInfo();
                updatePageNavigation();
                setTimeout(updateZoomControls, 100);
            } catch (error) {
                if (token !== state.mushafLoadToken) return;
                console.error('Error loading mushaf page:', error);
                showNotification('Failed to load mushaf page');
                updatePageNavigation();
            } finally {
                if (token === state.mushafLoadToken) {
                    state.isMushafPageLoading = false;
                    state.pendingMushafPage = 0;
                    mushafLoader.style.display = 'none';
                    mushafPageImage.classList.remove('loading');
                    jumpPageBtn.disabled = false;
                    pageInput.disabled = false;
                    updatePageNavigation();
                }
            }
        }
        
        // Update page range information and header title
        function updatePageAndSurahInfo() {
            const page = state.currentPage;
            const surahs = getSurahsOnPage(page);
            
            if (surahs.length > 0) {
                let rangeText = '';
                if (surahs.length === 1) {
                    const surah = surahs[0];
                    rangeText = `${surah.englishName} (${surah.name})`;
                } else {
                    const surahNames = surahs.map(s => s.englishName).join(', ');
                    rangeText = `Surahs: ${surahNames}`;
                }
                surahRangeElement.textContent = rangeText;
            } else {
                surahRangeElement.textContent = 'No surah information available';
            }
        }
        
        // Update page navigation buttons
        function updatePageNavigation() {
            const page = state.isMushafPageLoading && state.pendingMushafPage
                ? state.pendingMushafPage
                : state.currentPage;
            
            // Update buttons
            prevPageBtn.disabled = state.isMushafPageLoading || page <= 1;
            nextPageBtn.disabled = state.isMushafPageLoading || page >= state.totalPages;
            desktopPrevBtn.disabled = state.isMushafPageLoading || page <= 1;
            desktopNextBtn.disabled = state.isMushafPageLoading || page >= state.totalPages;
            
            // Update input value
            pageInput.value = page;
            pageInput.min = 1;
            pageInput.max = state.totalPages;
        }
        
        // Go to previous page
        function goToPrevPage() {
            if (state.isMushafPageLoading) return;
            if (state.currentPage > 1) {
                const targetPage = state.currentPage - 1;
                updateMushafPage(targetPage);
                showNotification(`Loading page ${targetPage}`);
            }
        }
        
        // Go to next page
        function goToNextPage() {
            if (state.isMushafPageLoading) return;
            if (state.currentPage < state.totalPages) {
                const targetPage = state.currentPage + 1;
                updateMushafPage(targetPage);
                showNotification(`Loading page ${targetPage}`);
            }
        }
        
        // Jump to specific page
        function jumpToPage() {
            const pageInputValue = parseInt(pageInput.value);
            
            if (isNaN(pageInputValue)) {
                showNotification('Please enter a valid page number');
                pageInput.value = state.currentPage;
                return;
            }
            
            if (pageInputValue < 1 || pageInputValue > state.totalPages) {
                showNotification(`Page must be between 1 and ${state.totalPages}`);
                pageInput.value = state.currentPage;
                return;
            }
            
            if (state.isMushafPageLoading) return;
            updateMushafPage(pageInputValue);
            showNotification(`Loading page ${pageInputValue}`);
        }
        
        // Setup touch/swipe events for mushaf navigation
        function setupTouchEvents() {
            let touchStartX = 0;
            let touchEndX = 0;
            let touchStartY = 0;
            let touchEndY = 0;
            
            mushafModeContent.addEventListener('touchstart', (e) => {
                if (state.currentMode !== 'mushaf' || state.isMushafPageLoading || isPinching || state.isDragging || state.zoomLevel > (state.savedZoomLevel + 0.02)) return;
                touchStartX = e.changedTouches[0].screenX;
                touchStartY = e.changedTouches[0].screenY;
            });
            
            mushafModeContent.addEventListener('touchend', (e) => {
                if (state.currentMode !== 'mushaf' || state.isMushafPageLoading || isPinching || state.isDragging || state.zoomLevel > (state.savedZoomLevel + 0.02)) return;
                touchEndX = e.changedTouches[0].screenX;
                touchEndY = e.changedTouches[0].screenY;
                handleSwipe();
            });
            
            function handleSwipe() {
                const swipeThreshold = 50; // Minimum swipe distance
                const swipeDistance = touchEndX - touchStartX;
                const verticalDistance = Math.abs(touchEndY - touchStartY);
                
                if (Math.abs(swipeDistance) < swipeThreshold || verticalDistance > 80) {
                    return; // Not a significant swipe
                }
                
                // Swipe right = Next page, Swipe left = Previous page
                if (swipeDistance > 0) {
                    // Swipe right - go to next page
                    goToNextPage();
                } else {
                    // Swipe left - go to previous page
                    goToPrevPage();
                }
            }
        }
        
        // Setup mushaf event listeners
        function setupMushafEvents() {
            prevPageBtn.addEventListener('click', goToPrevPage);
            nextPageBtn.addEventListener('click', goToNextPage);
            desktopPrevBtn.addEventListener('click', goToPrevPage);
            desktopNextBtn.addEventListener('click', goToNextPage);
            jumpPageBtn.addEventListener('click', jumpToPage);
            
            pageInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    jumpToPage();
                }
            });
            
            // Keyboard navigation
            document.addEventListener('keydown', (e) => {
                if (state.currentMode !== 'mushaf') return;
                
                switch(e.key) {
                    case 'ArrowLeft':
                        goToPrevPage();
                        break;
                    case 'ArrowRight':
                        goToNextPage();
                        break;
                    case 'Home':
                        updateMushafPage(1);
                        break;
                    case 'End':
                        updateMushafPage(state.totalPages);
                        break;
                }
            });
            
            // Setup touch events
            setupTouchEvents();
        }
        
        // Initialize the page
        async function initPage() {
            const surahParam = getUrlParameter('surah');
            state.currentSurah = surahParam ? parseInt(surahParam) : 1;

            const ayahParam = parseInt(getUrlParameter('ayah') || '0', 10);
            state.targetAyah = Number.isFinite(ayahParam) ? ayahParam : 0;
            
            applyDarkMode();

            // Reciters + pricing/unlocks come from backend (DB controlled).
            ensureReciterUnlockModal();
            await loadRecitersAndRender(true);
            changeReciter(state.currentReciter);
            
            // Don't show notification on initial language set
            changeTranslation('en', false);
            
            // Generate page metadata
            generatePageMetadata();
            
            updatePlayModeIndicator();
            setupAudioEvents();
            setupMushafEvents();
            setupZoomControls(); // Add zoom controls setup
            loadAndDisplaySurah(state.currentSurah);
            setupEventListeners();
            try {
                if (window.DeenLinkQuranStreak && typeof window.DeenLinkQuranStreak.recordRead === 'function') {
                    setTimeout(() => {
                        window.DeenLinkQuranStreak.recordRead('quran_reader').catch(() => {});
                    }, 900);
                }
            } catch (_) {}
        }
        
        // Setup all event listeners
        function setupEventListeners() {
            modeToggle.addEventListener('click', toggleMode);
            
            playBtn.addEventListener('click', () => {
                if (state.isLoadingAudio) return;
                
                if (!audioElement.src) {
                    playFullSurah(state.currentAyah || 1);
                } else {
                    togglePlayPause();
                }
            });
            
            progressBar.addEventListener('click', seekAudio);
            
            settingsBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                settingsDropdown.classList.toggle('show');
            });
            
            speedBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                cycleSpeed();
                if (settingsDropdown.classList.contains('show')) {
                    settingsDropdown.classList.remove('show');
                }
            });
            
            languageButton.addEventListener('click', (e) => {
                e.stopPropagation();
                languageDropdown.classList.toggle('show');
            });
            
            document.addEventListener('click', (e) => {
                if (!settingsBtn.contains(e.target) && !settingsDropdown.contains(e.target)) {
                    settingsDropdown.classList.remove('show');
                }
                if (!languageButton.contains(e.target) && !languageDropdown.contains(e.target)) {
                    languageDropdown.classList.remove('show');
                }
            });
            
            // Reciters are rendered dynamically; use event delegation.
            if (settingsDropdown) {
                settingsDropdown.addEventListener('click', (e) => {
                    const item = e.target.closest('.dropdown-item[data-reciter]');
                    if (!item) return;
                    const key = String(item.getAttribute('data-reciter') || '').trim();
                    if (!key) return;
                    e.stopPropagation();
                    changeReciter(key);
                    settingsDropdown.classList.remove('show');
                });
            }
            
            document.querySelectorAll('.language-item').forEach(item => {
                item.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const langCode = item.dataset.lang;
                    changeTranslation(langCode, true);
                    languageDropdown.classList.remove('show');
                });
            });
        }
        
        // Initialize everything when DOM is loaded
        document.addEventListener('DOMContentLoaded', function() {
            initPage().catch(() => {});
            setupBackButtonLoader();
            // DeenPoints reward: if the user spends 10 minutes reading on this page, reward once per day.
            if (window.DeenlinkActivityRewards) {
                window.DeenlinkActivityRewards.start({
                    activity: 'quran_reader_10m',
                    minutes: 10,
                    points: 5, // server authoritative; client hint only
                    iconClass: 'fas fa-book-open',
                    title: 'MashaAllah',
                    subtitle: "You spent time reading the Qur'an.",
                    text: 'You earned DeenPoints for staying on the Qur\'an reader for 10 minutes.'
                });
            }
        });
