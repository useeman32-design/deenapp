const APP_BUILD = '20260619_1';
const SHELL_CACHE = `deenlink-shell-${APP_BUILD}`;
const RUNTIME_CACHE = `deenlink-runtime-${APP_BUILD}`;
const CACHE_PREFIX = 'deenlink-';
const OFFLINE_FALLBACK = './index.html';
const SHELL_ASSETS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './img/logo.png',
  './img/icon-192.png',
  './img/icon-512.png',
  './img/apple-touch-icon.png',
  './shared/public_settings.js?v=20260512_1',
  './shared/maintenance_gate.js?v=20260512_1'
];

function isCachableResponse(response) {
  return !!response && response.ok && response.type !== 'opaque';
}

function shouldBypass(url) {
  return url.pathname.includes('/api/') || url.pathname.endsWith('/sw.js');
}

function isStaticAsset(url) {
  return /\.(?:css|js|png|jpg|jpeg|gif|webp|svg|ico|woff2|woff|ttf|otf|json)$/i.test(url.pathname);
}

function buildFreshRequest(request) {
  const url = new URL(request.url);
  url.searchParams.set('__dlv', APP_BUILD);
  return new Request(url.toString(), {
    method: request.method,
    headers: request.headers,
    mode: request.mode,
    credentials: request.credentials,
    redirect: request.redirect,
    referrer: request.referrer,
    referrerPolicy: request.referrerPolicy,
    integrity: request.integrity,
    cache: 'no-store'
  });
}

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(SHELL_CACHE).then((cache) => cache.addAll(SHELL_ASSETS)).catch(() => Promise.resolve())
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(
      keys.map((key) => {
        if (!key.startsWith(CACHE_PREFIX)) return Promise.resolve();
        if (key === SHELL_CACHE || key === RUNTIME_CACHE) return Promise.resolve();
        return caches.delete(key);
      })
    );
    await self.clients.claim();
  })());
});

self.addEventListener('message', (event) => {
  if (!event.data || !event.data.type) return;
  if (event.data.type === 'PURGE_CACHES') {
    event.waitUntil((async () => {
      const keys = await caches.keys();
      await Promise.all(keys.map((key) => caches.delete(key)));
    })());
    return;
  }
  if (event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (shouldBypass(url)) return;

  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      const cache = await caches.open(RUNTIME_CACHE);
      try {
        const response = await fetch(request);
        if (isCachableResponse(response)) {
          cache.put(request, response.clone()).catch(() => {});
        }
        return response;
      } catch (_) {
        const cached = await cache.match(request);
        return cached || caches.match(OFFLINE_FALLBACK);
      }
    })());
    return;
  }

  if (isStaticAsset(url)) {
    event.respondWith((async () => {
      const cache = await caches.open(RUNTIME_CACHE);
      const cached = await cache.match(request);
      const networkFetch = fetch(buildFreshRequest(request))
        .then((response) => {
          if (isCachableResponse(response)) {
            cache.put(request, response.clone()).catch(() => {});
          }
          return response;
        })
        .catch(() => cached);
      return cached || networkFetch;
    })());
    return;
  }

  event.respondWith(fetch(request).catch(() => caches.match(request)));
});

self.addEventListener('push', (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch (_) {}
  const title = data.title || 'DeenLink';
  const options = {
    body: data.body || '',
    icon: data.icon || './img/logo.png',
    badge: data.badge || './img/icon-192.png',
    data: {
      url: data.url || './profile/notifications.html'
    }
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = (event.notification && event.notification.data && event.notification.data.url) || './profile/notifications.html';
  event.waitUntil((async () => {
    const allClients = await clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of allClients) {
      if (client.url === targetUrl && 'focus' in client) {
        return client.focus();
      }
    }
    if (clients.openWindow) {
      return clients.openWindow(targetUrl);
    }
  })());
});

