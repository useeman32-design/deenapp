(() => {
  window.__VIDEO_PROFILE_WIRED__ = true;

  const params = new URLSearchParams(window.location.search || '');
  const requestedUserId = Number(params.get('user_id') || 0);
  const requestedUsernameRaw = String(params.get('u') || params.get('username') || '').trim();
  const requestedUsername = requestedUsernameRaw.replace(/^@/, '').trim();
  const backNext = String(params.get('next') || '').trim();
  const openUploadOnLoad = params.get('open_upload') === '1';
  const state = {
    csrfToken: '',
    profileUserId: 0,
    editable: false,
    canUpload: false,
    email: '',
    emailVerificationEnabled: true,
    isEmailVerified: true,
    uploadMessage: 'Upload feature not available for all users yet. Coming soon.',
    posts: [],
    repostVideos: [],
    savedVideos: [],
    likedVideos: [],
    activeTab: 'posts',
    uploadInFlight: false,
    uploadPrefs: { tags: [], country: 'General', tribe: 'General' }
  };
  const settingsTags = [
    { name: 'dawah', icon: 'fas fa-mosque' },
    { name: 'quran', icon: 'fas fa-book-quran' },
    { name: 'hadith', icon: 'fas fa-scroll' },
    { name: 'fiqh', icon: 'fas fa-gavel' },
    { name: 'motivation', icon: 'fas fa-fire' },
    { name: 'entertainment', icon: 'fas fa-film' },
    { name: 'ramadan', icon: 'fas fa-moon' },
    { name: 'eid', icon: 'fas fa-star-and-crescent' },
    { name: 'fasting', icon: 'fas fa-clock' },
    { name: 'ibadah', icon: 'fas fa-praying-hands' },
    { name: 'prayer', icon: 'fas fa-kaaba' }
  ];

  const loader = document.getElementById('starLoader');
  const toast = document.getElementById('toastMsg');
  const settingsModal = document.getElementById('settingsModal');
  const editBioModal = document.getElementById('editBioModal');
  const addModal = document.getElementById('addVideoModal');
  const removeVideoModal = document.getElementById('removeVideoModal');
  const tabPosts = document.querySelector('.tab-item[data-tab="posts"]');
  const tabReposts = document.querySelector('.tab-item[data-tab="reposts"]');
  const tabSaved = document.querySelector('.tab-item[data-tab="saved"]');
  const tabLiked = document.querySelector('.tab-item[data-tab="liked"]');
  const postsGrid = document.getElementById('videoGridPosts');
  const repostsGrid = document.getElementById('videoGridReposts');
  const savedGrid = document.getElementById('videoGridSaved');
  const likedGrid = document.getElementById('videoGridLiked');
  const bioParagraph = document.getElementById('profileBio');
  const emailVerificationBanner = document.getElementById('emailVerificationBanner');
  const editBioTextarea = document.getElementById('editBioText');
  const fakeFileInput = document.getElementById('fakeFileInput');
  const fileInput = document.getElementById('fileInput');
  const postVideoBtn = document.getElementById('postVideoBtn');
  const editBioBtn = document.getElementById('editBioBtn');
  const profileVideoViewerModal = document.getElementById('profileVideoViewerModal');
  const profileVideoViewerFrame = document.getElementById('profileVideoViewerFrame');
  let pendingRemoveVideoId = 0;

  /* ── YouTube URL validator (bug fix) ────────────────────── */
  function isValidYouTubeUrl(url) {
    return /(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/.test(
      String(url || '').trim()
    );
  }

  function showStarLoader(ms = 450) {
    if (!loader) return;
    loader.classList.add('active');
    setTimeout(() => loader.classList.remove('active'), ms);
  }

  function showToast(msg, type = 'info', durationMs = 2600) {
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.toggle('error', type === 'error');
    toast.classList.toggle('success', type === 'success');
    toast.classList.add('show');
    setTimeout(() => {
      toast.classList.remove('show', 'error', 'success');
    }, durationMs);
  }

  function renderEmailVerificationBanner(profile) {
    if (!emailVerificationBanner) return;
    const enabled = profile ? profile.emailVerificationEnabled !== false : true;
    const verified = Number(profile?.isEmailVerified || 0) === 1;

    emailVerificationBanner.className = 'email-verification-banner';
    emailVerificationBanner.innerHTML = '';

    if (!state.editable) {
      emailVerificationBanner.classList.remove('is-visible');
      return;
    }

    if (!enabled) {
      emailVerificationBanner.classList.add('is-visible', 'disabled');
      emailVerificationBanner.innerHTML = `
        <div class="banner-copy"><i class="fas fa-circle-info"></i><span>Email verification is temporarily disabled. You can keep using DeenLink.</span></div>
      `;
      return;
    }

    if (verified) {
      emailVerificationBanner.classList.remove('is-visible');
      return;
    }

    emailVerificationBanner.classList.add('is-visible');
    emailVerificationBanner.innerHTML = `
      <div class="banner-copy"><i class="fas fa-triangle-exclamation"></i><span>Your email is unverified.</span></div>
      <button type="button" class="banner-action" id="verifyEmailNowBtn">Click here to verify email</button>
    `;
  }

  function ensureUploadProgress() {
    const modalContent = document.querySelector('#addVideoModal .modal-content');
    if (!modalContent) return null;
    let box = modalContent.querySelector('.dl-upload-progress');
    if (!box) {
      box = document.createElement('div');
      box.className = 'dl-upload-progress';
      box.innerHTML = `
        <div class="dl-upload-progress-top">
          <span class="dl-upload-progress-label">Preparing upload</span>
          <span class="dl-upload-progress-percent">0%</span>
        </div>
        <div class="dl-upload-progress-track">
          <div class="dl-upload-progress-fill"></div>
        </div>
      `;
      const actions = modalContent.querySelector('.action-buttons');
      modalContent.insertBefore(box, actions || null);
    }
    return box;
  }

  function setUploadProgress(percent, label) {
    const box = ensureUploadProgress();
    if (!box) return;
    const pct = Math.max(0, Math.min(100, Math.round(Number(percent) || 0)));
    box.classList.remove('error', 'success');
    box.classList.add('active');
    box.querySelector('.dl-upload-progress-label').textContent = label || 'Uploading video';
    box.querySelector('.dl-upload-progress-percent').textContent = `${pct}%`;
    box.querySelector('.dl-upload-progress-fill').style.width = `${pct}%`;
  }

  function finishUploadProgress(type, label) {
    const box = ensureUploadProgress();
    if (!box) return;
    box.classList.remove('error', 'success');
    if (type) box.classList.add(type);
    if (label) box.querySelector('.dl-upload-progress-label').textContent = label;
    if (type === 'success') {
      box.querySelector('.dl-upload-progress-percent').textContent = '100%';
      box.querySelector('.dl-upload-progress-fill').style.width = '100%';
    }
    if (type !== 'error') {
      setTimeout(() => {
        box.classList.remove('active', 'success');
        box.querySelector('.dl-upload-progress-fill').style.width = '0%';
      }, 900);
    }
  }

  function esc(v) {
    return String(v ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
  }

  function normalizeTag(tag) {
    return String(tag || '').trim().toLowerCase().replace(/[^a-z0-9_]+/g, '');
  }

  function formatStat(num) {
    const n = Number(num || 0);
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    return String(n);
  }

  function verificationBadgeHtml(badge) {
    const vb = String(badge || 'none').trim().toLowerCase();
    if (vb !== 'blue' && vb !== 'green' && vb !== 'gold') return '';
    const title = vb === 'gold'
      ? 'Official DeenLink account'
      : (vb === 'green' ? 'Verified scholar' : 'Verified account');
    return `<span class="dl-verify dl-verify--${esc(vb)}" title="${esc(title)}" aria-label="${esc(title)}"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M10.15 13.7 7.7 11.25l-1.4 1.4 3.85 3.85 7.55-7.55-1.4-1.4z"></path></svg></span>`;
  }

  function renderTags(containerId) {
    const el = document.getElementById(containerId);
    if (!el) return;
    el.innerHTML = settingsTags.map((t) =>
      `<div class="tag-chip" data-tag="${esc(t.name)}"><i class="${esc(t.icon)}"></i> ${esc(t.name)}</div>`
    ).join('');
  }

  function getSelectedTags(containerId) {
    return Array.from(document.querySelectorAll(`#${containerId} .tag-chip.selected`))
      .map((chip) => String(chip.getAttribute('data-tag') || '').trim())
      .filter(Boolean);
  }

  function setSelectedTags(containerId, tags) {
    const wanted = new Set((Array.isArray(tags) ? tags : []).map((t) => String(t || '').trim().toLowerCase()));
    document.querySelectorAll(`#${containerId} .tag-chip`).forEach((chip) => {
      const tag = String(chip.getAttribute('data-tag') || '').trim().toLowerCase();
      chip.classList.toggle('selected', wanted.has(tag));
    });
  }

  function toggleTribeVisibility(countryValue, tribeSectionId = 'tribeSection') {
    const country = String(countryValue || '').trim().toLowerCase();
    const section = document.getElementById(tribeSectionId);
    if (section) section.style.display = country === 'nigeria' ? 'block' : 'none';
  }

  function getSelectedTribe(containerSelector = '#tribeSection .tribe-option') {
    const selected = document.querySelector(`${containerSelector}.selected`);
    return selected ? String(selected.getAttribute('data-tribe') || 'General') : 'General';
  }

  function setSelectedTribe(value, containerSelector = '#tribeSection .tribe-option') {
    const wanted = String(value || 'General').trim().toLowerCase();
    let matched = false;
    document.querySelectorAll(containerSelector).forEach((opt) => {
      const isMatch = String(opt.getAttribute('data-tribe') || '').trim().toLowerCase() === wanted;
      opt.classList.toggle('selected', isMatch);
      if (isMatch) matched = true;
    });
    if (!matched) {
      const firstGeneral = document.querySelector(`${containerSelector}[data-tribe="General"]`);
      if (firstGeneral) firstGeneral.classList.add('selected');
    }
  }

  function youtubeIdFromUrl(url) {
    const raw = String(url || '').trim();
    if (!raw) return '';
    const m = raw.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/shorts\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/);
    return m ? m[1] : '';
  }

  function getVideoThumb(v) {
    const poster = String(v.posterUrl || '').trim();
    if (poster) return poster;
    const yid = youtubeIdFromUrl(String(v.sourceUrl || ''));
    if (yid) return `https://i.ytimg.com/vi/${yid}/hqdefault.jpg`;
    return 'https://images.unsplash.com/photo-1584551246679-0daf3d275d0f?w=600&auto=format';
  }

  async function ensureCsrfToken() {
    if (state.csrfToken) return state.csrfToken;
    const res = await fetch('../api/auth/csrf.php', { credentials: 'include' });
    const data = await res.json().catch(() => ({}));
    state.csrfToken = String(data?.csrf_token || '');
    return state.csrfToken;
  }

  async function apiJson(url, opts = {}) {
    const res = await fetch(url, opts);
    const raw = await res.text();
    let data = null;
    try {
      data = raw ? JSON.parse(raw) : null;
    } catch (_) {
      data = null;
    }
    if (!res.ok || !data || data.status !== 'success') {
      const fallback = raw ? raw.slice(0, 180) : 'Server error';
      throw new Error((data && data.message) ? data.message : fallback);
    }
    return data;
  }

  async function apiPostJson(url, payload) {
    const token = await ensureCsrfToken();
    return apiJson(url, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': token
      },
      body: JSON.stringify(payload || {})
    });
  }

  const VIDEO_CHUNK_BYTES = 1024 * 1024;
  const VIDEO_CHUNK_RETRIES = 2;

  function apiBase() {
    return String(window.API_BASE || '../api').replace(/\/$/, '');
  }

  async function fetchJsonWithTimeout(url, options, timeoutMs = 60000) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(url, { ...options, signal: ctrl.signal });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data) {
        throw new Error((data && data.message) ? data.message : `Request failed (${res.status})`);
      }
      return data;
    } catch (err) {
      if (err && err.name === 'AbortError') {
        throw new Error('Upload request timed out. Please retry on a stable connection.');
      }
      throw err;
    } finally {
      clearTimeout(timer);
    }
  }

  function xhrPostForm(url, fd, token, onProgress) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', url, true);
      xhr.withCredentials = true;
      xhr.timeout = 90000;
      if (token) xhr.setRequestHeader('X-CSRF-Token', token);
      if (xhr.upload && typeof onProgress === 'function') {
        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable) onProgress(e.loaded, e.total);
        };
      }
      xhr.onload = () => {
        let parsed = null;
        try { parsed = JSON.parse(xhr.responseText || '{}'); } catch (_) {}
        if (xhr.status >= 200 && xhr.status < 300) {
          resolve(parsed);
          return;
        }
        reject(new Error((parsed && parsed.message) ? parsed.message : `Upload failed (${xhr.status})`));
      };
      xhr.onerror = () => reject(new Error('Network error during upload. Please retry on a stable connection.'));
      xhr.ontimeout = () => reject(new Error('Upload timed out. Please retry on a stable connection.'));
      xhr.onabort = () => reject(new Error('Upload cancelled.'));
      xhr.send(fd);
    });
  }

  async function postChunkWithRetry(url, fd, token, onProgress) {
    let lastErr = null;
    for (let attempt = 0; attempt <= VIDEO_CHUNK_RETRIES; attempt++) {
      try {
        return await xhrPostForm(url, fd, token, onProgress);
      } catch (err) {
        lastErr = err;
        if (attempt >= VIDEO_CHUNK_RETRIES) break;
        await new Promise(resolve => setTimeout(resolve, 600 * (attempt + 1)));
      }
    }
    throw lastErr || new Error('Chunk upload failed.');
  }

  async function uploadLocalVideoChunked(file, meta, token, onProgress) {
    const totalChunks = Math.max(1, Math.ceil(file.size / VIDEO_CHUNK_BYTES));
    const init = await fetchJsonWithTimeout(`${apiBase()}/videos/upload.php?chunk_action=init`, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': token
      },
      body: JSON.stringify({
        filename: file.name || 'video.mp4',
        file_size: file.size,
        total_chunks: totalChunks
      })
    });
    if (init.status !== 'success' || !init.upload_id) {
      throw new Error(init.message || 'Could not start upload session');
    }

    for (let i = 0; i < totalChunks; i++) {
      const fd = new FormData();
      const start = i * VIDEO_CHUNK_BYTES;
      const end = Math.min(start + VIDEO_CHUNK_BYTES, file.size);
      fd.append('upload_id', String(init.upload_id));
      fd.append('chunk_index', String(i));
      fd.append('total_chunks', String(totalChunks));
      fd.append('chunk', file.slice(start, end), `part_${i}.bin`);
      await postChunkWithRetry(`${apiBase()}/videos/upload.php?chunk_action=chunk`, fd, token, (loaded, total) => {
        const pct = ((i + (loaded / Math.max(1, total))) / totalChunks) * 100;
        if (typeof onProgress === 'function') onProgress(Math.min(99, Math.round(pct)));
      });
    }

    const finalize = new FormData();
    finalize.append('upload_id', String(init.upload_id));
    finalize.append('description', meta.description || '');
    if (meta.tags) finalize.append('tags', meta.tags);
    finalize.append('country', meta.country || 'General');
    finalize.append('tribe', meta.tribe || 'General');
    return xhrPostForm(`${apiBase()}/videos/upload.php?chunk_action=finalize`, finalize, token, () => {
      if (typeof onProgress === 'function') onProgress(100, 'Finishing upload');
    });
  }

  function renderPostComingSoon() {
    if (!postsGrid) return;
    postsGrid.innerHTML = `
      <div class="grid-video-card" style="grid-column:1/-1; aspect-ratio:auto; min-height:120px; display:flex; align-items:center; justify-content:center; padding:20px; color:#ccc; text-align:center;">
        Posts are not available for all users yet. Coming soon.
      </div>
    `;
  }

  function renderEligiblePostMessage() {
    if (!postsGrid) return;
    postsGrid.innerHTML = `
      <div class="grid-video-card" style="grid-column:1/-1; aspect-ratio:auto; min-height:120px; display:flex; align-items:center; justify-content:center; padding:20px; color:#ccc; text-align:center;">
        This account is eligible to post video.
      </div>
    `;
  }

  function buildCardMedia(v) {
    const type = String(v.sourceType || '').toLowerCase();
    const thumb = getVideoThumb(v);
    if (type === 'local' && !String(v.posterUrl || '').trim()) {
      const src = String(v.sourceUrl || '').trim();
      if (src) {
        const localThumb = src.includes('#') ? src : `${src}#t=2`;
        return `<video src="${esc(localThumb)}" muted playsinline preload="metadata"></video>`;
      }
    }
    return `<img src="${esc(thumb)}" alt="video thumbnail" loading="lazy">`;
  }

  function renderPostsGrid(videos) {
    if (!postsGrid) return;
    const list = Array.isArray(videos) ? videos : [];
    if (!list.length) {
      if (state.canUpload) {
        renderEligiblePostMessage();
      } else {
        renderPostComingSoon();
      }
      return;
    }
    postsGrid.innerHTML = list.map(v => `
      <div class="grid-video-card" data-id="${Number(v.id || 0)}">
        ${buildCardMedia(v)}
        ${state.editable ? `<button class="grid-video-menu" type="button" data-remove-id="${Number(v.id || 0)}" aria-label="Video actions"><i class="fas fa-ellipsis-v"></i></button>` : ''}
        <div class="video-stats-overlay">
          <span><i class="fas fa-play"></i> ${esc(formatStat(v.views || 0))}</span>
          <span><i class="fas fa-heart"></i> ${esc(formatStat(v.likes || 0))}</span>
        </div>
      </div>
    `).join('');
  }

  function renderSimpleGrid(gridEl, videos, emptyMessage) {
    if (!gridEl) return;
    if (!Array.isArray(videos) || videos.length === 0) {
      gridEl.innerHTML = `
        <div class="grid-video-card" style="grid-column:1/-1; aspect-ratio:auto; min-height:120px; display:flex; align-items:center; justify-content:center; padding:20px; color:#ccc; text-align:center;">
          ${esc(emptyMessage)}
        </div>
      `;
      return;
    }
    gridEl.innerHTML = videos.map(v => `
      <div class="grid-video-card" data-id="${Number(v.id || 0)}">
        ${buildCardMedia(v)}
        <div class="video-stats-overlay">
          <span><i class="fas fa-play"></i> ${esc(formatStat(v.views || 0))}</span>
          <span><i class="fas fa-heart"></i> ${esc(formatStat(v.likes || 0))}</span>
        </div>
      </div>
    `).join('');
  }

  function renderRepostsGrid(videos) {
    renderSimpleGrid(repostsGrid, videos, 'No reposts yet.');
  }

  function renderSavedGrid(videos) {
    renderSimpleGrid(savedGrid, videos, 'No saved videos yet.');
  }

  function renderLikedGrid(videos) {
    renderSimpleGrid(likedGrid, videos, 'No liked videos yet.');
  }

  async function refreshProfileCollections() {
    try {
      await loadProfile();
    } catch (_) {}
  }

  function consumeVideoLibraryDirtyFlag() {
    try {
      const ts = Number(localStorage.getItem('deenlink_video_library_dirty_at') || 0);
      if (!ts) return false;
      localStorage.removeItem('deenlink_video_library_dirty_at');
      localStorage.removeItem('deenlink_video_library_dirty_kind');
      return true;
    } catch (_) {
      return false;
    }
  }

  function getActiveGrid() {
    if (state.activeTab === 'reposts') return repostsGrid;
    if (state.activeTab === 'saved') return savedGrid;
    if (state.activeTab === 'liked') return likedGrid;
    return postsGrid;
  }

  function switchProfileTab(tabName) {
    const tab = String(tabName || 'posts');
    if (state.activeTab === tab) return;
    state.activeTab = tab;
    const tabs = [tabPosts, tabReposts, tabSaved, tabLiked].filter(Boolean);
    tabs.forEach((el) => el.classList.toggle('active', el.getAttribute('data-tab') === tab));
    if (postsGrid) postsGrid.style.display = tab === 'posts' ? 'grid' : 'none';
    if (repostsGrid) repostsGrid.style.display = tab === 'reposts' ? 'grid' : 'none';
    if (savedGrid) savedGrid.style.display = tab === 'saved' ? 'grid' : 'none';
    if (likedGrid) likedGrid.style.display = tab === 'liked' ? 'grid' : 'none';
    showStarLoader(360);
  }

  window.addEventListener('deenlink-video-library-changed', () => {
    refreshProfileCollections();
  });

  window.addEventListener('pageshow', () => {
    if (consumeVideoLibraryDirtyFlag()) {
      refreshProfileCollections();
    }
  });

  window.addEventListener('storage', (e) => {
    if (e.key === 'deenlink_video_library_dirty_at' && e.newValue) {
      refreshProfileCollections();
    }
  });

  document.addEventListener('click', async (e) => {
    const btn = e.target.closest('#verifyEmailNowBtn');
    if (!btn) return;
    if (!state.email) {
      showToast('Email address not available yet.');
      return;
    }
    const original = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Sending...';
    try {
      const resp = await apiPostJson('../api/auth/resend_verification.php', { email: state.email });
      showToast(resp.message || 'Verification email sent', 'success');
    } catch (err) {
      showToast(err.message || 'Unable to send verification email', 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = original || 'Click here to verify email';
    }
  });

  function applyProfile(profile) {
    const p = profile || {};
    state.profileUserId = Number(p.userId || 0);
    state.email = String(p.email || '');
    state.emailVerificationEnabled = p.emailVerificationEnabled !== false;
    state.isEmailVerified = Number(p.isEmailVerified || 0) === 1;
    const username = String(p.username || 'user');
    const fullName = String(p.fullName || username);
    const bio = String(p.bio || '').trim() || 'No bio yet.';
    const verifyHtml = verificationBadgeHtml(p.verificationBadge || p.verification_badge || 'none');

    const topName = document.querySelector('.profile-username');
    if (topName) topName.innerHTML = `@${esc(username)}${verifyHtml}`;
    const dn = document.querySelector('.display-name');
    if (dn) dn.innerHTML = `${esc(fullName)}${verifyHtml}`;
    const uh = document.querySelector('.user-handle');
    if (uh) uh.textContent = '@' + username;
    if (bioParagraph) bioParagraph.textContent = bio;

    const avatar = document.querySelector('.profile-avatar');
    if (avatar) {
      avatar.src = p.profileImageUrl || '../img/default_profile.jpg';
      avatar.onerror = () => { avatar.src = '../img/default_profile.jpg'; };
    }
    const following = document.getElementById('followingCount');
    const followers = document.getElementById('followersCount');
    const likes = document.getElementById('likesCount');
    if (following) following.innerText = formatStat(p.following || 0);
    if (followers) followers.innerText = formatStat(p.followers || 0);
    if (likes) likes.innerText = formatStat(p.likes || 0);

    // Hide numeric IDs in the URL bar once we know the username.
    // This keeps profile URLs shareable without leaking internal user IDs.
    if (!requestedUsername && requestedUserId > 0 && username) {
      try {
        const u = new URL(window.location.href);
        u.searchParams.set('u', username);
        u.searchParams.delete('user_id');
        window.history.replaceState({}, '', u.toString());
      } catch (_) {}
    }

    state.editable = !!p.editable;
    state.canUpload = !!p.canUpload;
    state.uploadMessage = String(p.uploadMessage || state.uploadMessage);
    renderEmailVerificationBanner(p);
    if (editBioBtn) editBioBtn.style.display = state.editable ? 'block' : 'none';
    if (tabSaved) tabSaved.classList.toggle('tab-hidden', !state.editable);
    if (!state.editable && state.activeTab === 'saved') {
      switchProfileTab('posts');
    }

    const pref = p.preferences || {};
    state.uploadPrefs = {
      tags: Array.isArray(pref.tags) ? pref.tags.map(normalizeTag).filter(Boolean) : [],
      country: String(pref.country || 'General'),
      tribe: String(pref.tribe || 'General')
    };
    setSelectedTags('prefTagsContainer', Array.isArray(pref.tags) ? pref.tags : []);
    const countrySelect = document.getElementById('countrySelect');
    if (countrySelect) {
      countrySelect.value = String(pref.country || 'General');
      toggleTribeVisibility(countrySelect.value, 'tribeSection');
    }
    setSelectedTribe(String(pref.tribe || 'General'));

    const uploadCountry = document.getElementById('uploadCountrySelect');
    if (uploadCountry) {
      uploadCountry.value = String(pref.country || 'General');
      toggleTribeVisibility(uploadCountry.value, 'uploadTribeSection');
    }
    setSelectedTribe(String(pref.tribe || 'General'), '#uploadTribeSection .tribe-option');
  }

  async function loadProfile() {
    const url = requestedUsername
      ? `../api/videos/profile_data.php?u=${encodeURIComponent(String(requestedUsername))}`
      : (requestedUserId > 0
        ? `../api/videos/profile_data.php?user_id=${encodeURIComponent(String(requestedUserId))}`
        : '../api/videos/profile_data.php');
    const data = await apiJson(url, { credentials: 'include' });
    applyProfile(data.profile || {});
    state.posts = Array.isArray(data.posts) ? data.posts : [];
    state.repostVideos = Array.isArray(data.reposts) ? data.reposts : [];
    state.savedVideos = Array.isArray(data.saved) ? data.saved : [];
    state.likedVideos = Array.isArray(data.liked) ? data.liked : [];
    renderPostsGrid(state.posts);
    renderRepostsGrid(state.repostVideos);
    renderSavedGrid(state.savedVideos);
    renderLikedGrid(state.likedVideos);
    switchProfileTab(state.activeTab);
  }

  function bindTabs() {
    tabPosts?.addEventListener('click', () => switchProfileTab('posts'));
    tabReposts?.addEventListener('click', () => switchProfileTab('reposts'));
    tabSaved?.addEventListener('click', () => {
      if (!state.editable) {
        showToast('Saved videos are only visible on your own profile.');
        return;
      }
      switchProfileTab('saved');
    });
    tabLiked?.addEventListener('click', () => switchProfileTab('liked'));
  }

  function bindSettings() {
    document.getElementById('prefTagsContainer')?.addEventListener('click', (e) => {
      const chip = e.target.closest('.tag-chip');
      if (!chip) return;
      chip.classList.toggle('selected');
    });
    document.getElementById('uploadTagsContainer')?.addEventListener('click', (e) => {
      const chip = e.target.closest('.tag-chip');
      if (!chip) return;
      chip.classList.toggle('selected');
    });
    document.querySelectorAll('.tribe-option').forEach((opt) => {
      opt.addEventListener('click', () => {
        const parent = opt.closest('.modal-section');
        const scope = parent ? parent.querySelectorAll('.tribe-option') : document.querySelectorAll('.tribe-option');
        scope.forEach((o) => o.classList.remove('selected'));
        opt.classList.add('selected');
      });
    });
    const countrySelect = document.getElementById('countrySelect');
    countrySelect?.addEventListener('change', () => {
      toggleTribeVisibility(countrySelect.value, 'tribeSection');
      if (String(countrySelect.value || '').trim().toLowerCase() !== 'nigeria') {
        setSelectedTribe('General');
      }
    });

    document.getElementById('settingsGear')?.addEventListener('click', () => {
      settingsModal?.classList.add('active');
    });
    document.getElementById('closeSettingsBtn')?.addEventListener('click', () => {
      settingsModal?.classList.remove('active');
    });
    settingsModal?.addEventListener('click', (e) => {
      if (e.target === settingsModal) settingsModal.classList.remove('active');
    });
    document.getElementById('savePrefBtn')?.addEventListener('click', async () => {
      const tags = getSelectedTags('prefTagsContainer');
      const country = String(document.getElementById('countrySelect')?.value || 'General');
      const tribe = getSelectedTribe('#tribeSection .tribe-option');
      try {
        const data = await apiPostJson('../api/videos/preferences.php', { tags, country, tribe });
        const pref = data.preferences || {};
        state.uploadPrefs = {
          tags: Array.isArray(pref.tags) ? pref.tags.map(normalizeTag).filter(Boolean) : [],
          country: String(pref.country || country),
          tribe: String(pref.tribe || tribe)
        };
        settingsModal?.classList.remove('active');
        showToast('Preferences saved');
      } catch (e) {
        showToast(e.message || 'Unable to save preferences');
      }
    });
  }

  function bindBioModal() {
    document.getElementById('editBioBtn')?.addEventListener('click', () => {
      if (!state.editable) return;
      if (editBioTextarea && bioParagraph) editBioTextarea.value = bioParagraph.innerText || '';
      editBioModal?.classList.add('active');
    });
    document.getElementById('closeBioBtn')?.addEventListener('click', () => editBioModal?.classList.remove('active'));
    editBioModal?.addEventListener('click', (e) => {
      if (e.target === editBioModal) editBioModal.classList.remove('active');
    });
    document.getElementById('saveBioBtn')?.addEventListener('click', async () => {
      const newBio = String(editBioTextarea?.value || '').trim();
      if (!newBio) {
        showToast('Bio cannot be empty');
        return;
      }
      try {
        await apiPostJson('../api/videos/save_profile.php', { video_bio: newBio });
        if (bioParagraph) bioParagraph.innerText = newBio;
        editBioModal?.classList.remove('active');
        showToast('Bio updated');
      } catch (e) {
        showToast(e.message || 'Unable to save bio');
      }
    });
  }

  function openUploadModal() {
    if (!state.editable) {
      showToast('You can only upload on your profile.');
      return;
    }
    if (!state.canUpload) {
      showToast(state.uploadMessage || 'Upload feature not available for all users yet. Coming soon.');
      return;
    }
    addModal?.classList.add('active');
  }

  function bindUploadModal() {
    const optLocal = document.getElementById('optLocal');
    const optYoutube = document.getElementById('optYoutube');
    const localForm = document.getElementById('localUploadForm');
    const youtubeForm = document.getElementById('youtubeLinkForm');
    const youtubeLink = document.getElementById('youtubeLink');
    const videoDescription = document.getElementById('videoDescription');
    const youtubeDescription = document.getElementById('youtubeDescription');
    const uploadCountrySelect = document.getElementById('uploadCountrySelect');
    let currentSource = 'local';

    function activateSource(type) {
      currentSource = type === 'youtube' ? 'youtube' : 'local';
      const local = type === 'local';
      if (optLocal) optLocal.style.border = local ? '2px solid #1D6F42' : '1px solid #3a3a3a';
      if (optYoutube) optYoutube.style.border = local ? '1px solid #3a3a3a' : '2px solid #1D6F42';
      localForm?.classList.toggle('hidden', !local);
      youtubeForm?.classList.toggle('hidden', local);
    }

    optLocal?.addEventListener('click', () => activateSource('local'));
    optYoutube?.addEventListener('click', () => activateSource('youtube'));
    activateSource('local');
    uploadCountrySelect?.addEventListener('change', () => {
      toggleTribeVisibility(uploadCountrySelect.value, 'uploadTribeSection');
      if (String(uploadCountrySelect.value || '').trim().toLowerCase() !== 'nigeria') {
        setSelectedTribe('General', '#uploadTribeSection .tribe-option');
      }
    });

    /* ── File picker: label-based approach for iOS/Android ──
       Replace the div with a <label> so the browser handles the
       file dialog natively without a fragile .click() chain.     */
    function upgradeFilePicker() {
      const fake = document.getElementById('fakeFileInput');
      const fi   = document.getElementById('fileInput');
      if (!fake || !fi || fake.tagName === 'LABEL') return;
      if (!fi.id) fi.id = 'fileInputDL';
      const label = document.createElement('label');
      label.id = 'fakeFileInput';
      label.htmlFor = fi.id;
      label.className = fake.className;
      label.style.cssText = fake.style.cssText;
      label.innerHTML = fake.innerHTML;
      fake.parentNode.replaceChild(label, fake);
    }
    upgradeFilePicker();

    /* Re-upgrade every time modal opens (in case DOM was re-rendered) */
    addModal && new MutationObserver(function(muts) {
      for (const m of muts) {
        if (m.type === 'attributes' && m.attributeName === 'class') {
          if (addModal.classList.contains('active')) setTimeout(upgradeFilePicker, 50);
        }
      }
    }).observe(addModal, { attributes: true });

    fakeFileInput?.addEventListener('click', () => fileInput?.click());
    fileInput?.addEventListener('change', function () {
      if (!fakeFileInput) return;
      if (this.files && this.files.length) {
        fakeFileInput.innerHTML = `<i class="fas fa-check-circle"></i> ${esc(this.files[0].name.substring(0, 22))}`;
      } else {
        fakeFileInput.innerHTML = `<i class="fas fa-cloud-upload-alt"></i> Tap to choose video`;
      }
    });

    document.getElementById('cancelModalBtn')?.addEventListener('click', () => addModal?.classList.remove('active'));
    addModal?.addEventListener('click', (e) => {
      if (e.target === addModal) addModal.classList.remove('active');
    });

    postVideoBtn?.addEventListener('click', async () => {
      if (state.uploadInFlight) return;
      if (!state.canUpload) {
        showToast(state.uploadMessage || 'Upload feature unavailable');
        return;
      }
      const isLocal = currentSource === 'local';
      const desc = String(isLocal ? videoDescription?.value : youtubeDescription?.value).trim();
      if (!desc) {
        showToast('Please add video description');
        return;
      }

      const uploadTags = getSelectedTags('uploadTagsContainer');
      const uploadCountry = String(uploadCountrySelect?.value || 'General');
      const uploadTribe = getSelectedTribe('#uploadTribeSection .tribe-option');
      const meta = {
        description: desc,
        tags: uploadTags.length ? JSON.stringify(uploadTags) : '',
        country: uploadCountry,
        tribe: uploadTribe
      };
      let localFile = null;
      if (isLocal) {
        const f = fileInput?.files && fileInput.files[0] ? fileInput.files[0] : null;
        if (!f) {
          showToast('Please select a video file');
          return;
        }
        if (f.size > 120 * 1024 * 1024) {
          showToast('File is too large (max 120 MB).');
          return;
        }
        localFile = f;
      } else {
        showToast('YouTube uploads are no longer supported. Please choose a video file.');
        return;
      }

      const old = postVideoBtn.innerHTML;
      postVideoBtn.disabled = true;
      state.uploadInFlight = true;
      const setProgress = (pct, label) => {
        postVideoBtn.innerHTML = `<i class="fas fa-circle-notch fa-spin"></i> Uploading ${pct}%`;
        setUploadProgress(pct, label || (pct >= 99 ? 'Finishing upload' : 'Uploading video'));
      };
      setProgress(0, 'Preparing upload');
      try {
        const token = await ensureCsrfToken();
        const data = await uploadLocalVideoChunked(localFile, meta, token, setProgress);
        if (!data || data.status !== 'success') {
          throw new Error((data && data.message) ? data.message : 'Upload failed');
        }
        finishUploadProgress('success', 'Upload complete');
        showToast('Video uploaded successfully!', 'success');
        addModal?.classList.remove('active');
        if (fileInput) fileInput.value = '';
        if (youtubeLink) youtubeLink.value = '';
        if (videoDescription) videoDescription.value = '';
        if (youtubeDescription) youtubeDescription.value = '';
        if (fakeFileInput) fakeFileInput.innerHTML = `<i class="fas fa-cloud-upload-alt"></i> Tap to choose video`;
        setSelectedTags('uploadTagsContainer', []);
        await loadProfile();
      } catch (e) {
        const msg = e.message || 'Sorry, we were not able to upload your video.';
        finishUploadProgress('error', 'Upload failed');
        showToast(msg, 'error', 5200);
      } finally {
        state.uploadInFlight = false;
        postVideoBtn.disabled = false;
        postVideoBtn.innerHTML = old;
      }
    });
  }

  function bindNav() {
    const go = (url, useBack = false) => {
      showStarLoader(550);
      setTimeout(() => {
        if (useBack) {
          if (backNext) window.location.href = backNext;
          else if (window.history.length > 1) window.history.back();
          else window.location.href = url;
          return;
        }
        window.location.href = url;
      }, 150);
    };
    document.getElementById('navHome')?.addEventListener('click', () => {
      go('index.html');
    });
    document.getElementById('backBtn')?.addEventListener('click', () => {
      closeProfileVideoViewer();
      go('index.html', true);
    });
    document.getElementById('navAdd')?.addEventListener('click', openUploadModal);
    document.getElementById('navAddArea')?.addEventListener('click', openUploadModal);
    document.getElementById('navProfile')?.addEventListener('click', () => showStarLoader(300));
  }

  function openProfileVideoViewer(sourceType, videoId) {
    const id = Number(videoId || 0);
    const uid = Number(state.profileUserId || requestedUserId || 0);
    if (!id || !uid || !profileVideoViewerModal || !profileVideoViewerFrame) return;
    const sourceMap = {
      profile_liked: 'profile_liked',
      profile_saved: 'profile_saved',
      profile_reposts: 'profile_reposts',
      profile_posts: 'profile_posts'
    };
    const source = sourceMap[String(sourceType || '')] || 'profile_posts';
    profileVideoViewerFrame.src = `index.html?video_id=${encodeURIComponent(String(id))}&source=${encodeURIComponent(source)}&user_id=${encodeURIComponent(String(uid))}&embedded=1`;
    profileVideoViewerModal.classList.add('active');
    profileVideoViewerModal.setAttribute('aria-hidden', 'false');
  }

  function closeProfileVideoViewer() {
    if (!profileVideoViewerModal || !profileVideoViewerFrame) return;
    profileVideoViewerModal.classList.remove('active');
    profileVideoViewerModal.setAttribute('aria-hidden', 'true');
    setTimeout(() => { profileVideoViewerFrame.src = 'about:blank'; }, 120);
  }

  window.addEventListener('message', (event) => {
    const data = event && event.data;
    if (!data || typeof data !== 'object') return;
    if (data.type === 'deenlink-close-embedded-video-viewer') {
      closeProfileVideoViewer();
    }
  });

  function openRemoveVideoModal(videoId) {
    pendingRemoveVideoId = Number(videoId || 0);
    if (!pendingRemoveVideoId || !removeVideoModal) return;
    removeVideoModal.classList.add('active');
  }

  function closeRemoveVideoModal() {
    pendingRemoveVideoId = 0;
    removeVideoModal?.classList.remove('active');
  }

  async function confirmRemoveVideo() {
    const id = Number(pendingRemoveVideoId || 0);
    if (!id) return;
    const btn = document.getElementById('confirmRemoveVideoBtn');
    const old = btn ? btn.innerHTML : '';
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Removing...';
    }
    try {
      await apiPostJson('../api/videos/delete.php', { video_id: id });
      state.posts = (Array.isArray(state.posts) ? state.posts : []).filter((v) => Number(v.id || 0) !== id);
      renderPostsGrid(state.posts);
      closeRemoveVideoModal();
      showToast('Video removed');
    } catch (e) {
      showToast(e.message || 'Unable to remove video');
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = old;
      }
    }
  }

  function bindGridNavigation() {
    postsGrid?.addEventListener('click', (e) => {
      const menuBtn = e.target.closest('.grid-video-menu[data-remove-id]');
      if (menuBtn) {
        e.preventDefault();
        e.stopPropagation();
        const removeId = Number(menuBtn.getAttribute('data-remove-id') || 0);
        if (removeId > 0 && state.editable) {
          openRemoveVideoModal(removeId);
        }
        return;
      }
      const card = e.target.closest('.grid-video-card[data-id]');
      if (!card) return;
      const id = Number(card.dataset.id || 0);
      if (!id) return;
      openProfileVideoViewer('profile_posts', id);
    });
    repostsGrid?.addEventListener('click', (e) => {
      const card = e.target.closest('.grid-video-card[data-id]');
      if (!card) return;
      const id = Number(card.dataset.id || 0);
      if (!id) return;
      openProfileVideoViewer('profile_reposts', id);
    });
    savedGrid?.addEventListener('click', (e) => {
      const card = e.target.closest('.grid-video-card[data-id]');
      if (!card) return;
      const id = Number(card.dataset.id || 0);
      if (!id) return;
      openProfileVideoViewer('profile_saved', id);
    });
    likedGrid?.addEventListener('click', (e) => {
      const card = e.target.closest('.grid-video-card[data-id]');
      if (!card) return;
      const id = Number(card.dataset.id || 0);
      if (!id) return;
      openProfileVideoViewer('profile_liked', id);
    });
    document.getElementById('closeProfileVideoViewer')?.addEventListener('click', closeProfileVideoViewer);
    profileVideoViewerModal?.addEventListener('click', (e) => {
      if (e.target === profileVideoViewerModal) closeProfileVideoViewer();
    });
    document.getElementById('cancelRemoveVideoBtn')?.addEventListener('click', closeRemoveVideoModal);
    document.getElementById('confirmRemoveVideoBtn')?.addEventListener('click', confirmRemoveVideo);
    removeVideoModal?.addEventListener('click', (e) => {
      if (e.target === removeVideoModal) closeRemoveVideoModal();
    });
  }

  async function init() {
    renderTags('prefTagsContainer');
    renderTags('uploadTagsContainer');
    bindSettings();
    bindTabs();
    bindBioModal();
    bindUploadModal();
    bindNav();
    bindGridNavigation();
    window.addEventListener('pageshow', () => closeProfileVideoViewer());
    renderPostComingSoon();
    if (repostsGrid) repostsGrid.innerHTML = '';
    if (savedGrid) savedGrid.innerHTML = '';
    if (likedGrid) likedGrid.innerHTML = '';
    if (loader) loader.classList.add('active');
    try {
      await loadProfile();
      if (openUploadOnLoad) {
        openUploadModal();
      }
    } catch (e) {
      showToast(e.message || 'Failed to load profile');
    } finally {
      // Prevent dummy/static placeholder flash by revealing the page only
      // after the live profile payload has been attempted.
      setTimeout(() => {
        if (loader) loader.classList.remove('active');
        document.body.classList.remove('profile-hydrating');
      }, 120);
    }
  }

  init();
})();
