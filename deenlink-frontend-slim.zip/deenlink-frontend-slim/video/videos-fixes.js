/**
 * videos-fixes.js
 * Bug fixes for DeenLink /videos/index.html
 * Drop in /videos/ and add ONE line before </body>:
 *   <script src="videos-fixes.js"></script>
 *
 * Fixes applied:
 *  1. submitAddVideo — FormData upload no longer corrupted by Content-Type: application/json
 *  2. (YouTube removed) local-only upload flow
 *  3. showSuccessToast — replaces showComingSoon for positive outcomes
 *  4. File picker — label-based fallback for iOS/Android
 *  5. Upload allowed feedback — clearer messaging when uploads are gated
 *  6. Progress bar safe-area already handled in CSS (videos-glass.css)
 */

(function () {
    'use strict';

    /* ── Wait for the page to fully initialise ─────────────── */
    function onReady(fn) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', fn, { once: true });
        } else {
            fn();
        }
    }

    /* ══════════════════════════════════════════════════════════
       1. SUCCESS TOAST
       A proper green success toast — separate from the orange
       "coming soon" notification so users get clear feedback.
       ══════════════════════════════════════════════════════════ */
    function showSuccessToast(message, durationMs = 3000) {
        showUploadToast(message || 'Done!', 'success', durationMs);
    }

    function showUploadToast(message, type = 'success', durationMs = 3800) {
        // Remove any existing success toast
        document.querySelectorAll('.dl-success-toast').forEach(el => el.remove());

        const toast = document.createElement('div');
        const isError = type === 'error';
        toast.className = `dl-success-toast ${isError ? 'error' : 'success'}`;
        toast.innerHTML = `<i class="fas ${isError ? 'fa-exclamation-circle' : 'fa-check-circle'}"></i> <span>${String(message || (isError ? 'Upload failed.' : 'Done!'))}</span>`;
        document.body.appendChild(toast);

        // Force reflow then show
        requestAnimationFrame(() => {
            requestAnimationFrame(() => toast.classList.add('show'));
        });

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 400);
        }, durationMs);
    }

    /* Expose globally so existing code can call it too */
    window.showSuccessToast = showSuccessToast;

    function ensureUploadProgress() {
        const modalContent = document.querySelector('#addVideoModal .modal-content');
        if (!modalContent) return null;
        let box = modalContent.querySelector('.dl-upload-progress');
        if (!box) {
            box = document.createElement('div');
            box.className = 'dl-upload-progress';
            box.innerHTML = `
                <div class="dl-upload-progress-top">
                    <span class="dl-upload-progress-label">Preparing upload</span>
                    <span class="dl-upload-progress-percent">0%</span>
                </div>
                <div class="dl-upload-progress-track">
                    <div class="dl-upload-progress-fill"></div>
                </div>
            `;
            const actions = modalContent.querySelector('.action-buttons');
            modalContent.insertBefore(box, actions || null);
        }
        return box;
    }

    function setUploadProgress(percent, label) {
        const box = ensureUploadProgress();
        if (!box) return;
        const pct = Math.max(0, Math.min(100, Math.round(Number(percent) || 0)));
        box.classList.add('active');
        box.querySelector('.dl-upload-progress-label').textContent = label || 'Uploading video';
        box.querySelector('.dl-upload-progress-percent').textContent = `${pct}%`;
        box.querySelector('.dl-upload-progress-fill').style.width = `${pct}%`;
    }

    function finishUploadProgress(type, label) {
        const box = ensureUploadProgress();
        if (!box) return;
        box.classList.remove('error', 'success');
        if (type) box.classList.add(type);
        if (label) box.querySelector('.dl-upload-progress-label').textContent = label;
        if (type === 'success') {
            box.querySelector('.dl-upload-progress-percent').textContent = '100%';
            box.querySelector('.dl-upload-progress-fill').style.width = '100%';
        }
        if (type !== 'error') {
            setTimeout(() => {
                box.classList.remove('active', 'success');
                box.querySelector('.dl-upload-progress-fill').style.width = '0%';
            }, 900);
        }
    }

    const VIDEO_CHUNK_BYTES = 1024 * 1024; // 1 MB — avoids HTTP/2 long-upload drops on shared hosting
    const VIDEO_CHUNK_RETRIES = 2;

    function buildApiUrl(path) {
        const p = String(path || '').startsWith('/') ? path : '/' + String(path || '');
        const base = String(window.API_BASE || '/api').replace(/\/$/, '');
        const origin = String(window.location.origin || '');
        if (base.startsWith('http')) return base.replace(/\/$/, '') + p;
        return origin + (base.startsWith('/') ? base : '/' + base) + p;
    }

    function xhrPostForm(url, fd, csrfToken, onProgress) {
        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.open('POST', url, true);
            xhr.withCredentials = true;
            xhr.timeout = 90000;
            if (csrfToken) xhr.setRequestHeader('X-CSRF-Token', csrfToken);
            if (xhr.upload && typeof onProgress === 'function') {
                xhr.upload.onprogress = (e) => {
                    if (e.lengthComputable) onProgress(e.loaded, e.total);
                };
            }
            xhr.onload = () => {
                let parsed = null;
                try { parsed = JSON.parse(xhr.responseText || '{}'); } catch (_) {}
                if (xhr.status >= 200 && xhr.status < 300) {
                    resolve(parsed);
                    return;
                }
                const msg = (parsed && parsed.message) ? parsed.message : `Request failed (${xhr.status})`;
                reject(new Error(msg));
            };
            xhr.onerror = () => reject(new Error('Network error (connection dropped). Try Wi‑Fi or a smaller video.'));
            xhr.ontimeout = () => reject(new Error('Request timed out. Try a smaller video.'));
            xhr.onabort = () => reject(new Error('Upload cancelled.'));
            xhr.send(fd);
        });
    }

    async function fetchJsonWithTimeout(url, options, timeoutMs = 60000) {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), timeoutMs);
        try {
            const res = await fetch(url, { ...options, signal: ctrl.signal });
            const data = await res.json().catch(() => null);
            if (!res.ok || !data) {
                throw new Error((data && data.message) ? data.message : `Request failed (${res.status})`);
            }
            return data;
        } catch (err) {
            if (err && err.name === 'AbortError') {
                throw new Error('Upload request timed out. Please retry on a stable connection.');
            }
            throw err;
        } finally {
            clearTimeout(timer);
        }
    }

    async function postChunkWithRetry(url, fd, csrfToken, onProgress) {
        let lastErr = null;
        for (let attempt = 0; attempt <= VIDEO_CHUNK_RETRIES; attempt++) {
            try {
                return await xhrPostForm(url, fd, csrfToken, onProgress);
            } catch (err) {
                lastErr = err;
                if (attempt >= VIDEO_CHUNK_RETRIES) break;
                await new Promise(resolve => setTimeout(resolve, 600 * (attempt + 1)));
            }
        }
        throw lastErr || new Error('Chunk upload failed.');
    }

    async function uploadVideoChunked(file, formMeta, csrfToken, onProgress) {
        const totalChunks = Math.max(1, Math.ceil(file.size / VIDEO_CHUNK_BYTES));
        const initData = await fetchJsonWithTimeout(buildApiUrl('/videos/upload.php?chunk_action=init'), {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            },
            body: JSON.stringify({
                filename: file.name || 'video.mp4',
                file_size: file.size,
                total_chunks: totalChunks
            })
        }, 60000);
        if (initData.status !== 'success') throw new Error(initData.message || 'Could not start upload session');
        const uploadId = String(initData.upload_id || '');
        if (!uploadId) throw new Error('Invalid upload session');

        for (let i = 0; i < totalChunks; i++) {
            const start = i * VIDEO_CHUNK_BYTES;
            const end = Math.min(start + VIDEO_CHUNK_BYTES, file.size);
            const blob = file.slice(start, end);
            const fd = new FormData();
            fd.append('upload_id', uploadId);
            fd.append('chunk_index', String(i));
            fd.append('total_chunks', String(totalChunks));
            fd.append('chunk', blob, `part_${i}.bin`);

            await postChunkWithRetry(buildApiUrl('/videos/upload.php?chunk_action=chunk'), fd, csrfToken, (loaded, total) => {
                const overall = ((i + (loaded / Math.max(1, total))) / totalChunks) * 100;
                if (typeof onProgress === 'function') onProgress(Math.min(99, Math.round(overall)));
            });
        }

        const finalizeFd = new FormData();
        finalizeFd.append('upload_id', uploadId);
        finalizeFd.append('description', formMeta.description || '');
        finalizeFd.append('source_type', 'local');
        if (formMeta.tags) finalizeFd.append('tags', formMeta.tags);
        finalizeFd.append('country', formMeta.country || 'General');
        finalizeFd.append('tribe', formMeta.tribe || 'General');

        return xhrPostForm(buildApiUrl('/videos/upload.php?chunk_action=finalize'), finalizeFd, csrfToken, (loaded, total) => {
            if (typeof onProgress === 'function') {
                onProgress(Math.min(100, 99 + Math.round((loaded / Math.max(1, total)) * 1)), 'Finishing upload');
            }
        });
    }

    // YouTube uploads removed (local-only).

    /* ══════════════════════════════════════════════════════════
       3. PATCHED submitAddVideo
       Fixes: FormData sent without Content-Type (lets browser set
       the multipart boundary), YouTube validation, success toast.
       ══════════════════════════════════════════════════════════ */
    async function patchedSubmitAddVideo() {
        // Guard: upload capability (keep existing gate)
        if (typeof state === 'undefined') return;
        if (state.uploadInFlight) return;
        if (!state.uploadAllowed) {
            const msg = String(state.uploadMessage || '');
            if (typeof window.showComingSoon === 'function') {
                window.showComingSoon(msg || 'Uploads are not available for your account yet.');
            }
            return;
        }

        const addVideoModal = document.getElementById('addVideoModal');
        const source = 'local';

        const localFileInput  = document.getElementById('fileInput');
        const localDesc       = String(document.getElementById('videoDescription')?.value || '').trim();
        const desc            = localDesc;

        /* ── Validation ──────────────────────────────────────── */
        if (!desc) {
            if (typeof window.showComingSoon === 'function') window.showComingSoon('Please add a description.');
            return;
        }

        if (source === 'local') {
            const file = localFileInput?.files?.[0] || null;
            if (!file) {
                if (typeof window.showComingSoon === 'function') window.showComingSoon('Please choose a video file.');
                return;
            }
            // Basic size sanity check (500 MB)
            if (file.size > 120 * 1024 * 1024) {
                if (typeof window.showComingSoon === 'function') window.showComingSoon('File is too large (max 120 MB).');
                return;
            }
        }

        const normTag = (t) => String(t || '').trim().toLowerCase().replace(/[^a-z0-9_]+/g, '');
        const tags = (state.uploadTags || []).map(normTag).filter(Boolean);
        const tribeBtn = document.querySelector('#uploadTribeSection .tribe-option.selected');
        const formMeta = {
            description: desc,
            tags: tags.length ? JSON.stringify(tags) : '',
            country: String(document.getElementById('uploadCountrySelect')?.value || 'General'),
            tribe: String(tribeBtn?.getAttribute('data-tribe') || 'General')
        };
        const file = localFileInput.files[0];

        /* ── Submit ──────────────────────────────────────────── */
        const submitBtn = document.getElementById('postVideoBtn');
        const originalLabel = submitBtn?.innerHTML || 'Post';
        const setProgressLabel = (pct) => {
            if (!submitBtn) return;
            submitBtn.innerHTML = `<i class="fas fa-circle-notch fa-spin"></i> Uploading ${pct}%`;
            setUploadProgress(pct, pct >= 99 ? 'Finishing upload' : 'Uploading video');
        };
        if (submitBtn) {
            submitBtn.disabled = true;
            setProgressLabel(0);
        }
        state.uploadInFlight = true;

        try {
            let csrfToken = '';
            if (typeof state.csrfToken === 'string' && state.csrfToken) {
                csrfToken = state.csrfToken;
            } else if (typeof ensureCsrfToken === 'function') {
                csrfToken = await ensureCsrfToken();
            }

            let data = await uploadVideoChunked(file, formMeta, csrfToken, setProgressLabel);

            if (!data || data.status !== 'success') {
                const errMsg = (data && data.message) ? data.message : 'Upload failed. Please try again.';
                throw new Error(errMsg);
            }

            /* ── Success ─────────────────────────────────────── */
            addVideoModal?.classList.remove('active');
            finishUploadProgress('success', 'Upload complete');
            showSuccessToast('Video uploaded successfully!');

            // Reload feed
            if (typeof loadVideosFromApi === 'function') {
                await loadVideosFromApi();
            }
            if (typeof renderVideos === 'function') {
                renderVideos();
            }
            if (Array.isArray(state.videos) && state.videos.length > 0) {
                if (typeof queueActivate === 'function') queueActivate(0);
                if (typeof preloadUpcomingEmbeds === 'function') preloadUpcomingEmbeds(0);
            }

        } catch (err) {
            const msg = (err && err.name === 'AbortError')
                ? 'Upload took too long. Please retry on a stable connection.'
                : (err?.message || 'Unable to upload video. Please try again.');
            finishUploadProgress('error', 'Upload failed');
            showUploadToast(msg || 'Sorry, we were not able to upload your video.', 'error', 5200);
        } finally {
            state.uploadInFlight = false;
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalLabel;
            }
        }
    }

    /* ══════════════════════════════════════════════════════════
       4. FILE PICKER — label-based fix for iOS/Android
       The div.click() chain can fail on mobile gesture restrictions.
       We swap the fake div for a proper <label> at runtime so the
       browser handles the file dialog natively.
       ══════════════════════════════════════════════════════════ */
    function patchFilePicker() {
        const fakeBtn = document.getElementById('fakeFileInput');
        const fileInput = document.getElementById('fileInput');
        if (!fakeBtn || !fileInput) return;

        // Give the file input a unique id if it doesn't already have one
        if (!fileInput.id) fileInput.id = 'fileInputDL';

        // Replace the div with a label pointing at the real input
        const label = document.createElement('label');
        label.id = 'fakeFileInput'; // keep the same id so CSS applies
        label.htmlFor = fileInput.id;
        label.className = fakeBtn.className;
        label.style.cssText = fakeBtn.style.cssText;
        label.innerHTML = fakeBtn.innerHTML;
        label.style.display = 'flex';
        label.style.cursor = 'pointer';

        fakeBtn.parentNode.replaceChild(label, fakeBtn);

        // Update the change listener to target the label (already present on fileInput)
    }

    /* ══════════════════════════════════════════════════════════
       5. WIRE EVERYTHING UP
       We wait for DOMContentLoaded then:
         a) patch the Post button listener
         b) fix the file picker
       ══════════════════════════════════════════════════════════ */
    onReady(function () {
        /* Patch Post button — replace the existing listener by cloning the
           button (removes all previous addEventListener calls) then adding ours. */
        const postBtn = document.getElementById('postVideoBtn');
        if (postBtn) {
            const fresh = postBtn.cloneNode(true);
            postBtn.parentNode.replaceChild(fresh, postBtn);
            fresh.addEventListener('click', patchedSubmitAddVideo);
        }

        /* Fix file picker */
        patchFilePicker();

        /* Re-patch whenever the upload modal opens (in case it was re-rendered) */
        const addVideoModal = document.getElementById('addVideoModal');
        if (addVideoModal) {
            const observer = new MutationObserver(function (mutations) {
                for (const m of mutations) {
                    if (m.type === 'attributes' && m.attributeName === 'class') {
                        if (addVideoModal.classList.contains('active')) {
                            // Modal just opened — make sure picker is still a label
                            setTimeout(patchFilePicker, 50);
                        }
                    }
                }
            });
            observer.observe(addVideoModal, { attributes: true });
        }

        /* ── Upload state feedback improvement ─────────────── */
        // If uploadAllowed is false, show a friendlier icon in the add button
        // We wait a tick for loadUploadCapabilities to run first
        setTimeout(function () {
            if (typeof state !== 'undefined' && !state.uploadAllowed) {
                const addBtn = document.getElementById('addBtn');
                if (addBtn) {
                    addBtn.title = state.uploadMessage || 'Upload not available for your account yet';
                }
            }
        }, 2000);
    });

})();
