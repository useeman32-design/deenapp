// shared/location_resolver.js
// Real-location resolver:
// 1) Use browser/device coordinates
// 2) Server-side LocationIQ fallback (optional, key stays on server)
// 3) BigDataCloud reverse geocoding (free client-side endpoint)
// 4) Caller-level cache / regional fallback
(function () {
  function normalize(value) {
    return String(value || '').trim().replace(/\s+/g, ' ');
  }

  function firstNonEmpty(values) {
    for (const value of values) {
      const normalized = normalize(value);
      if (normalized) return normalized;
    }
    return '';
  }

  function parseBigDataCloud(data) {
    if (!data || typeof data !== 'object') return '';
    const city = firstNonEmpty([
      data.city,
      data.locality,
      data.localityInfo && data.localityInfo.informative && data.localityInfo.informative[0] && data.localityInfo.informative[0].name,
      data.localityInfo && data.localityInfo.administrative && data.localityInfo.administrative[2] && data.localityInfo.administrative[2].name,
      data.localityInfo && data.localityInfo.administrative && data.localityInfo.administrative[1] && data.localityInfo.administrative[1].name
    ]);
    const country = firstNonEmpty([data.countryName, data.countryCode]);
    if (city && country && city.toLowerCase() !== country.toLowerCase()) return `${city}, ${country}`;
    return city || country;
  }

  function parseLocationIq(data) {
    if (!data || typeof data !== 'object') return '';
    const address = data.address || {};
    const city = firstNonEmpty([
      address.city,
      address.town,
      address.village,
      address.hamlet,
      address.county,
      data.display_place
    ]);
    const country = firstNonEmpty([address.country, data.display_address]);
    if (city && country && city.toLowerCase() !== country.toLowerCase()) return `${city}, ${country}`;
    return city || country;
  }

  async function fromBigDataCloud(lat, lng) {
    const url = `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${encodeURIComponent(String(lat))}&longitude=${encodeURIComponent(String(lng))}&localityLanguage=en`;
    const res = await fetch(url, {
      method: 'GET',
      headers: { 'Accept': 'application/json' }
    });
    if (!res.ok) throw new Error(`BigDataCloud ${res.status}`);
    const data = await res.json();
    const name = parseBigDataCloud(data);
    if (!name) throw new Error('BigDataCloud empty city');
    return { name, source: 'bigdatacloud', raw: data };
  }

  async function fromServerFallback(lat, lng, endpoint) {
    const url = `${endpoint}?lat=${encodeURIComponent(String(lat))}&lng=${encodeURIComponent(String(lng))}`;
    const res = await fetch(url, {
      method: 'GET',
      headers: { 'Accept': 'application/json' }
    });
    if (!res.ok) throw new Error(`Location fallback ${res.status}`);
    const data = await res.json().catch(() => null);
    const name = normalize(data && data.cityName);
    if (!name) throw new Error('Location fallback empty city');
    return { name, source: String(data.source || 'server'), raw: data };
  }

  async function resolveFromCoords(lat, lng, options) {
    const opts = options || {};
    const endpoint = normalize(opts.serverEndpoint || 'api/location/reverse_geocode.php');
    const errors = [];

    try {
      return await fromBigDataCloud(lat, lng);
    } catch (err) {
      errors.push(String(err && err.message || err || 'BigDataCloud failed'));
    }

    if (endpoint) {
      try {
        return await fromServerFallback(lat, lng, endpoint);
      } catch (err) {
        errors.push(String(err && err.message || err || 'LocationIQ fallback failed'));
      }
    }

    return {
      name: '',
      source: 'none',
      errors
    };
  }

  window.DeenLinkLocationResolver = {
    normalize,
    resolveFromCoords,
    parseBigDataCloud,
    parseLocationIq
  };
})();
