// Generic DeenPoints reward modal (used for reading-time rewards, etc.).
// Matches the Daily Check-in modal styling from `profile/index.html`.
//
// Why this exists:
// - We reward users for beneficial actions (reading Qur'an/Hadith/Dua).
// - We must avoid native `alert()` and use a consistent DeenLink modal UI.
//
// Usage:
//   window.DeenlinkRewardModal.show({
//     points: 5,
//     title: 'MashaAllah',
//     subtitle: 'Keep reading and reflecting.',
//     text: 'You earned DeenPoints for spending time reading.',
//     iconClass: 'fas fa-book-open'
//   });
(function () {
  'use strict';

  function appRoot() {
    const p = String(window.location.pathname || '').replace(/\\/g, '/');
    const idx = p.toLowerCase().indexOf('/deenlink/');
    if (idx >= 0) return p.slice(0, idx + '/deenLink/'.length);
    return '/';
  }
  const ROOT = appRoot();

  function ensureInjected() {
    if (document.getElementById('deenpointsRewardModal')) return;

    const style = document.createElement('style');
    style.id = 'deenpointsRewardModalStyle';
    style.textContent = `
      .daily-checkin-modal.deenpoints-reward-modal {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.8);
        z-index: 2500;
        display: none;
        justify-content: center;
        align-items: center;
        padding: 20px;
      }
      .daily-checkin-modal.deenpoints-reward-modal.active {
        display: flex;
        animation: deenpointsRewardFadeIn 0.25s ease;
      }
      @keyframes deenpointsRewardFadeIn {
        from { opacity: 0; transform: translateY(-8px); }
        to { opacity: 1; transform: translateY(0); }
      }
      .deenpoints-reward-modal .daily-checkin-content {
        background: linear-gradient(135deg, #1D6F42, #2E7D32);
        border-radius: 20px;
        padding: 30px 20px;
        text-align: center;
        color: white;
        max-width: 360px;
        width: 100%;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
      }
      .deenpoints-reward-modal .daily-checkin-icon {
        font-size: 48px;
        color: #D4AF37;
        margin-bottom: 14px;
        animation: deenpointsRewardBounce 1s infinite alternate;
      }
      @keyframes deenpointsRewardBounce {
        from { transform: translateY(0); }
        to { transform: translateY(-8px); }
      }
      .deenpoints-reward-modal .daily-checkin-title {
        font-size: 22px;
        font-weight: 800;
        margin-bottom: 8px;
      }
      .deenpoints-reward-modal .daily-checkin-subtitle {
        font-size: 13px;
        opacity: 0.95;
        margin-bottom: 18px;
        line-height: 1.45;
      }
      .deenpoints-reward-modal .daily-checkin-reward {
        background: rgba(255, 255, 255, 0.12);
        border-radius: 12px;
        padding: 14px;
        margin-bottom: 18px;
        backdrop-filter: blur(10px);
      }
      .deenpoints-reward-modal .reward-amount {
        font-size: 36px;
        font-weight: 900;
        color: #D4AF37;
        margin-bottom: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
      }
      .deenpoints-reward-modal .reward-amount img {
        width: 30px;
        height: 30px;
      }
      .deenpoints-reward-modal .reward-text {
        font-size: 12px;
        opacity: 0.92;
        line-height: 1.45;
      }
      .deenpoints-reward-modal .daily-checkin-btn {
        background-color: #D4AF37;
        color: #333;
        border: none;
        padding: 14px 30px;
        border-radius: 10px;
        font-size: 16px;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.25s;
        width: 100%;
      }
      .deenpoints-reward-modal .daily-checkin-btn:hover {
        background-color: #e6c158;
        transform: scale(1.03);
      }
    `;
    document.head.appendChild(style);

    const modal = document.createElement('div');
    modal.className = 'daily-checkin-modal deenpoints-reward-modal';
    modal.id = 'deenpointsRewardModal';
    modal.innerHTML = `
      <div class="daily-checkin-content" role="dialog" aria-modal="true" aria-labelledby="deenpointsRewardTitle">
        <div class="daily-checkin-icon"><i id="deenpointsRewardIcon" class="fas fa-gift"></i></div>
        <div class="daily-checkin-title" id="deenpointsRewardTitle">MashaAllah</div>
        <div class="daily-checkin-subtitle" id="deenpointsRewardSubtitle">Keep reading and reflecting.</div>
        <div class="daily-checkin-reward">
          <div class="reward-amount">
            <span id="deenpointsRewardPoints">+0</span>
            <img src="${ROOT}img/deenpoints.png" alt="DeenPoints">
          </div>
          <div class="reward-text" id="deenpointsRewardText">You earned DeenPoints for spending time reading.</div>
        </div>
        <button class="daily-checkin-btn" id="deenpointsRewardCloseBtn" type="button">Continue</button>
      </div>
    `;
    document.body.appendChild(modal);

    const close = () => modal.classList.remove('active');
    modal.addEventListener('click', (e) => { if (e.target === modal) close(); });
    modal.querySelector('#deenpointsRewardCloseBtn').addEventListener('click', close);
  }

  function show(opts) {
    ensureInjected();
    const modal = document.getElementById('deenpointsRewardModal');
    const points = Number(opts && opts.points) || 0;
    const title = (opts && opts.title) ? String(opts.title) : 'MashaAllah';
    const subtitle = (opts && opts.subtitle) ? String(opts.subtitle) : 'Keep reading and reflecting.';
    const text = (opts && opts.text) ? String(opts.text) : 'You earned DeenPoints for spending time reading.';
    const iconClass = (opts && opts.iconClass) ? String(opts.iconClass) : 'fas fa-gift';

    const t = modal.querySelector('#deenpointsRewardTitle');
    const st = modal.querySelector('#deenpointsRewardSubtitle');
    const p = modal.querySelector('#deenpointsRewardPoints');
    const rt = modal.querySelector('#deenpointsRewardText');
    const ic = modal.querySelector('#deenpointsRewardIcon');
    if (t) t.textContent = title;
    if (st) st.textContent = subtitle;
    if (p) p.textContent = (points >= 0 ? '+' : '') + String(points);
    if (rt) rt.textContent = text;
    if (ic) ic.className = iconClass;

    modal.classList.add('active');
  }

  window.DeenlinkRewardModal = { show };
})();
