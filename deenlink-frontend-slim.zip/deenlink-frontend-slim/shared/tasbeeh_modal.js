(function () {
  function bootTasbeehModal() {
    const modal = document.getElementById('tasbeehModalOverlay');
    const openBtn = document.getElementById('quickTasbihBtn');
    const closeBtn = document.getElementById('tasbeehModalClose');
    const counterDisplay = document.getElementById('counterDisplay');
    const beadCounter = document.getElementById('beadCounter');
    const currentCount = document.getElementById('currentCount');
    const incrementBtn = document.getElementById('incrementBtn');
    const resetBtn = document.getElementById('resetBtn');
    const beadIncrement = document.getElementById('beadIncrement');
    const beadReset = document.getElementById('beadReset');
    const fullResetBtn = document.getElementById('fullResetBtn');
    const modernCounter = document.getElementById('modernCounter');
    const tasbeehBeads = document.getElementById('tasbeehBeads');
    const counterStyleBtns = document.querySelectorAll('.counter-style-btn');
    const soundToggle = document.getElementById('soundToggle');
    const targetSelect = document.getElementById('targetSelect');
    const customTargetInputContainer = document.getElementById('customTargetInputContainer');
    const customTargetInput = document.getElementById('customTargetInput');
    const setCustomTargetBtn = document.getElementById('setCustomTarget');
    const counterMessage = document.getElementById('counterMessage');
    const currentDhikrElement = document.getElementById('currentDhikr');
    const beadsCountLabel = document.querySelector('.beads-count');
    const currentCountInfo = document.querySelector('.counter-info-text');
    const prevDhikrBtn = document.getElementById('prevDhikr');
    const nextDhikrBtn = document.getElementById('nextDhikr');
    const beadsCircle = document.getElementById('beadsCircle');
    const dhikrOptions = document.querySelectorAll('.dhikr-option');
    const presetCards = document.querySelectorAll('.preset-card');

    if (!modal || !openBtn || !counterDisplay || !beadsCircle) return;

    let tasbeehCount = 0;
    let currentStyle = 'modern';
    let soundEnabled = true;
    let currentDhikr = 'subhanallah';
    let currentTarget = 33;
    let touchStartY = 0;
    const dhikrList = ['subhanallah', 'alhamdulillah', 'allahuakbar'];
    const dhikrNames = {
      subhanallah: 'Subhanallah',
      alhamdulillah: 'Alhamdulillah',
      allahuakbar: 'Allahu Akbar'
    };

    function notify(message) {
      if (typeof window.showNotification === 'function') window.showNotification(message);
    }

    function getDisplayCount() {
      return currentTarget === 0 ? tasbeehCount : Math.max(currentTarget - tasbeehCount, 0);
    }

    function updateDhikrDisplay() {
      if (currentDhikrElement) currentDhikrElement.textContent = dhikrNames[currentDhikr] || 'Subhanallah';
      if (beadsCountLabel) {
        beadsCountLabel.innerHTML = currentTarget === 0
          ? `Counted: <span id="beadsCount">${tasbeehCount}</span>`
          : `Remaining: <span id="beadsCount">${getDisplayCount()}</span>/${currentTarget}`;
      }
      dhikrOptions.forEach((option) => {
        option.classList.toggle('active', option.dataset.dhikr === currentDhikr);
      });
    }

    function updateBeads() {
      beadsCircle.querySelectorAll('.bead').forEach((bead, index) => {
        bead.classList.toggle('active', index + 1 <= tasbeehCount);
      });
    }

    function updateProgress() {
      const progressCircle = document.querySelector('.progress-circle');
      if (!progressCircle) return;

      if (currentTarget === 0) {
        progressCircle.style.strokeDashoffset = '0';
        progressCircle.classList.add('unlimited');
        if (counterMessage) counterMessage.textContent = tasbeehCount === 0 ? 'Start your dhikr' : `${tasbeehCount} counted`;
        return;
      }

      const progress = (tasbeehCount / currentTarget) * 565.48;
      progressCircle.style.strokeDashoffset = String(565.48 - progress);
      progressCircle.classList.remove('unlimited');
      if (!counterMessage) return;
      if (tasbeehCount === 0) counterMessage.textContent = `${currentTarget} remaining`;
      else if (tasbeehCount < currentTarget) counterMessage.textContent = `${getDisplayCount()} remaining`;
      else counterMessage.textContent = 'Completed!';
    }

    function updateAllCounters() {
      const display = getDisplayCount();
      counterDisplay.textContent = String(display);
      counterDisplay.style.transform = 'translate(-50%, -50%)';
      if (beadCounter) beadCounter.textContent = String(display);
      if (currentCount) currentCount.textContent = String(display);
      if (currentCountInfo) {
        currentCountInfo.innerHTML = currentTarget === 0
          ? `Current Count: <span id="currentCount">${tasbeehCount}</span>`
          : `Remaining: <span id="currentCount">${display}</span>`;
      }
      updateProgress();
      updateBeads();
      updateDhikrDisplay();
    }

    function createBeads() {
      beadsCircle.innerHTML = '';
      const centerX = beadsCircle.clientWidth / 2;
      const centerY = beadsCircle.clientHeight / 2;
      const radius = Math.min(centerX, centerY) * 0.8;
      const totalBeads = 33;

      for (let i = 1; i <= totalBeads; i += 1) {
        const angle = (i / totalBeads) * 2 * Math.PI - Math.PI / 2;
        const bead = document.createElement('div');
        bead.className = 'bead';
        bead.dataset.index = String(i);
        bead.style.left = `${centerX + radius * Math.cos(angle)}px`;
        bead.style.top = `${centerY + radius * Math.sin(angle)}px`;
        bead.textContent = String(i);
        if (i <= tasbeehCount) bead.classList.add('active');
        bead.addEventListener('click', () => {
          if (i <= tasbeehCount) {
            tasbeehCount = i;
            updateAllCounters();
          }
        });
        beadsCircle.appendChild(bead);
      }
    }

    function playCountSound() {
      if (!soundEnabled) return;
      try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        oscillator.frequency.value = 800;
        oscillator.type = 'sine';
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.1);
      } catch (_) {}
    }

    function switchCounterStyle(style) {
      currentStyle = style;
      counterStyleBtns.forEach((btn) => btn.classList.toggle('active', btn.dataset.style === style));
      if (modernCounter) modernCounter.style.display = style === 'modern' ? 'block' : 'none';
      if (tasbeehBeads) tasbeehBeads.style.display = style === 'beads' ? 'block' : 'none';
      if (style === 'beads') setTimeout(createBeads, 50);
    }

    function incrementCounter() {
      if (currentTarget > 0 && tasbeehCount >= currentTarget) return;
      tasbeehCount += 1;
      playCountSound();
      updateAllCounters();
      if ('vibrate' in navigator) navigator.vibrate(10);
      counterDisplay.style.color = '#FFD700';
      setTimeout(() => {
        counterDisplay.style.color = 'var(--accent-gold)';
      }, 200);
    }

    function resetCounter() {
      tasbeehCount = 0;
      updateAllCounters();
    }

    function switchDhikr(dhikr) {
      currentDhikr = dhikr;
      tasbeehCount = 0;
      updateAllCounters();
    }

    function applyPreset(presetType) {
      if (presetType === 'daily') {
        currentTarget = 33;
        if (targetSelect) targetSelect.value = '33';
      } else if (presetType === 'astaghfirullah') {
        currentTarget = 100;
        if (targetSelect) targetSelect.value = '100';
      } else if (presetType === 'salawat') {
        currentTarget = 11;
        if (targetSelect) targetSelect.value = '11';
      }
      if (customTargetInputContainer) customTargetInputContainer.style.display = 'none';
      tasbeehCount = 0;
      updateAllCounters();
    }

    function handleTargetChange() {
      if (!targetSelect) return;
      const selectedValue = targetSelect.value;
      if (selectedValue === 'custom') {
        if (customTargetInputContainer) customTargetInputContainer.style.display = 'block';
        currentTarget = 0;
      } else if (selectedValue === '0') {
        if (customTargetInputContainer) customTargetInputContainer.style.display = 'none';
        currentTarget = 0;
      } else {
        if (customTargetInputContainer) customTargetInputContainer.style.display = 'none';
        currentTarget = parseInt(selectedValue, 10) || 33;
        tasbeehCount = 0;
      }
      updateAllCounters();
    }

    function setCustomTarget() {
      const value = parseInt(String(customTargetInput && customTargetInput.value || ''), 10);
      if (!value || value <= 0) {
        notify('Please enter a valid number greater than 0');
        return;
      }
      currentTarget = value;
      if (targetSelect) targetSelect.value = String(value);
      if (customTargetInputContainer) customTargetInputContainer.style.display = 'none';
      if (customTargetInput) customTargetInput.value = '';
      tasbeehCount = 0;
      updateAllCounters();
    }

    function openTasbeehModal(event) {
      if (event) {
        event.preventDefault();
        event.stopPropagation();
      }
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
      updateAllCounters();
      setTimeout(createBeads, 100);
    }

    function closeTasbeehModal() {
      modal.classList.remove('active');
      document.body.style.overflow = 'auto';
    }

    openBtn.addEventListener('click', openTasbeehModal);
    if (closeBtn) closeBtn.addEventListener('click', closeTasbeehModal);
    modal.addEventListener('click', (event) => {
      if (event.target === modal) closeTasbeehModal();
    });

    [incrementBtn, beadIncrement].forEach((btn) => btn && btn.addEventListener('click', incrementCounter));
    [resetBtn, beadReset, fullResetBtn].forEach((btn) => btn && btn.addEventListener('click', resetCounter));
    counterStyleBtns.forEach((btn) => btn.addEventListener('click', () => switchCounterStyle(btn.dataset.style || 'modern')));
    if (soundToggle) {
      soundToggle.addEventListener('click', function () {
        soundEnabled = !soundEnabled;
        this.classList.toggle('active');
        this.innerHTML = soundEnabled
          ? '<i class="fas fa-volume-up"></i> Sound'
          : '<i class="fas fa-volume-mute"></i> Muted';
      });
    }
    if (targetSelect) targetSelect.addEventListener('change', handleTargetChange);
    if (setCustomTargetBtn) setCustomTargetBtn.addEventListener('click', setCustomTarget);
    if (customTargetInput) {
      customTargetInput.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') setCustomTarget();
      });
    }
    if (prevDhikrBtn) {
      prevDhikrBtn.addEventListener('click', () => {
        const currentIndex = dhikrList.indexOf(currentDhikr);
        switchDhikr(dhikrList[(currentIndex - 1 + dhikrList.length) % dhikrList.length]);
      });
    }
    if (nextDhikrBtn) {
      nextDhikrBtn.addEventListener('click', () => {
        const currentIndex = dhikrList.indexOf(currentDhikr);
        switchDhikr(dhikrList[(currentIndex + 1) % dhikrList.length]);
      });
    }
    dhikrOptions.forEach((option) => option.addEventListener('click', function () {
      switchDhikr(this.dataset.dhikr || 'subhanallah');
    }));
    presetCards.forEach((card) => card.addEventListener('click', function () {
      applyPreset(this.dataset.preset || '');
    }));

    document.addEventListener('keydown', (event) => {
      if (!modal.classList.contains('active')) return;
      if (event.key === 'Escape') closeTasbeehModal();
      else if (event.key === ' ' || event.key === 'Enter') {
        incrementCounter();
        event.preventDefault();
      } else if (event.key === 'r' || event.key === 'R') {
        resetCounter();
      }
    });

    if (tasbeehBeads) {
      tasbeehBeads.addEventListener('touchstart', (event) => {
        touchStartY = event.touches[0].clientY;
      });
      tasbeehBeads.addEventListener('touchend', (event) => {
        const diff = touchStartY - event.changedTouches[0].clientY;
        if (diff > 50) incrementCounter();
        if (diff < -50) resetCounter();
      });
    }

    window.addEventListener('resize', () => {
      if (currentStyle === 'beads') createBeads();
    });

    updateAllCounters();
    createBeads();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootTasbeehModal, { once: true });
  } else {
    bootTasbeehModal();
  }
})();
