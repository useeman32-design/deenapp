// shared/payment_complaint_modal.js
// Lightweight modal for "Report payment" when verification fails but user completed checkout.
//
// This prevents users from getting stuck and gives admins a review queue.
(function () {
  'use strict';

  function ensureModal() {
    let el = document.getElementById('dlPaymentComplaintModal');
    if (el) return el;

    el = document.createElement('div');
    el.id = 'dlPaymentComplaintModal';
    el.style.cssText = 'position:fixed;inset:0;display:none;align-items:center;justify-content:center;z-index:99999;background:rgba(0,0,0,.55);padding:16px;';
    el.innerHTML = `
      <div style="width:100%;max-width:520px;background:#fff;border-radius:16px;box-shadow:0 18px 48px rgba(0,0,0,.25);overflow:hidden;font-family:Poppins,system-ui,-apple-system,Segoe UI,Roboto,Arial;">
        <div style="padding:14px 16px;background:linear-gradient(135deg,#1D6F42,#0D47A1);color:#fff;display:flex;align-items:center;justify-content:space-between;">
          <div style="font-weight:800;">Report payment</div>
          <button type="button" id="dlPcClose" style="background:transparent;border:0;color:#fff;font-size:20px;cursor:pointer;line-height:1;">&times;</button>
        </div>
        <div style="padding:16px;">
          <div id="dlPcMeta" style="font-size:13px;color:#555;margin-bottom:10px;"></div>
          <div style="font-size:13px;color:#666;line-height:1.45;margin-bottom:10px;">
            If you completed payment but DeenLink couldn't confirm it, submit a short complaint and our team will review it.
          </div>
          <textarea id="dlPcMessage" rows="5" style="width:100%;border:1px solid #ddd;border-radius:12px;padding:12px;outline:none;resize:vertical;font-size:14px;" placeholder="Describe what happened (e.g. charged, reference shown on Flutterwave, time)..."></textarea>
          <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:12px;">
            <button type="button" id="dlPcCancel" style="border:1px solid #ddd;background:#fff;border-radius:12px;padding:10px 14px;font-weight:700;cursor:pointer;">Cancel</button>
            <button type="button" id="dlPcSend" style="border:0;background:#1D6F42;color:#fff;border-radius:12px;padding:10px 14px;font-weight:800;cursor:pointer;">Submit</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(el);

    // Close handlers
    const close = () => { el.style.display = 'none'; };
    el.addEventListener('click', (e) => { if (e.target === el) close(); });
    el.querySelector('#dlPcClose').addEventListener('click', close);
    el.querySelector('#dlPcCancel').addEventListener('click', close);

    return el;
  }

  function notify(msg, type) {
    try {
      if (typeof window.showNotification === 'function') {
        window.showNotification(String(msg || ''), type || 'info');
        return;
      }
    } catch (_) {}
    try {
      if (window.DeenlinkFlw && typeof window.DeenlinkFlw.toast === 'function') {
        window.DeenlinkFlw.toast(String(msg || ''), type || 'info');
        return;
      }
    } catch (_) {}
    // Avoid native alerts; fallback to console.
    try { console.log('[DeenLink]', type || 'info', String(msg || '')); } catch (_) {}
  }

  function showSuccessModal(message) {
    let el = document.getElementById('dlPaymentComplaintSuccess');
    if (!el) {
      el = document.createElement('div');
      el.id = 'dlPaymentComplaintSuccess';
      el.style.cssText = 'position:fixed;inset:0;display:none;align-items:center;justify-content:center;z-index:100000;background:rgba(0,0,0,.55);padding:16px;';
      el.innerHTML = `
        <div style="width:100%;max-width:520px;background:#fff;border-radius:16px;box-shadow:0 18px 48px rgba(0,0,0,.25);overflow:hidden;font-family:Poppins,system-ui,-apple-system,Segoe UI,Roboto,Arial;">
          <div style="padding:14px 16px;background:linear-gradient(135deg,#1D6F42,#2E7D32);color:#fff;display:flex;align-items:center;justify-content:space-between;">
            <div style="font-weight:900;display:flex;align-items:center;gap:10px;"><span style="font-size:18px;">✓</span><span>Complaint submitted</span></div>
            <button type="button" id="dlPcOkX" style="background:transparent;border:0;color:#fff;font-size:20px;cursor:pointer;line-height:1;">&times;</button>
          </div>
          <div style="padding:16px;">
            <div id="dlPcOkMsg" style="color:#333;font-weight:700;line-height:1.5;"></div>
            <div style="display:flex;justify-content:flex-end;margin-top:14px;">
              <button type="button" id="dlPcOkBtn" style="border:0;background:#1D6F42;color:#fff;border-radius:12px;padding:10px 14px;font-weight:900;cursor:pointer;">OK</button>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(el);
      const close = () => { el.style.display = 'none'; };
      el.addEventListener('click', (e) => { if (e.target === el) close(); });
      el.querySelector('#dlPcOkX').addEventListener('click', close);
      el.querySelector('#dlPcOkBtn').addEventListener('click', close);
    }
    const msgEl = el.querySelector('#dlPcOkMsg');
    msgEl.textContent = String(message || 'Our team will review it shortly.');
    el.style.display = 'flex';
  }

  async function open(opts) {
    const el = ensureModal();
    const meta = el.querySelector('#dlPcMeta');
    const ta = el.querySelector('#dlPcMessage');
    const send = el.querySelector('#dlPcSend');

    const txRef = String((opts && opts.tx_ref) || '');
    const txId = String((opts && opts.transaction_id) || '');
    const purpose = String((opts && opts.purpose) || '');

    meta.innerHTML = `
      <div><b>Tx ref:</b> <span style="font-family:ui-monospace,Consolas,monospace;">${txRef}</span></div>
      ${txId ? `<div style="margin-top:4px;"><b>Transaction id:</b> <span style="font-family:ui-monospace,Consolas,monospace;">${txId}</span></div>` : ''}
      ${purpose ? `<div style="margin-top:4px;"><b>Purpose:</b> ${purpose}</div>` : ''}
    `;

    ta.value = '';
    send.disabled = false;
    el.style.display = 'flex';

    send.onclick = async function () {
      const message = String(ta.value || '').trim();
      if (!message) {
        notify('Please enter your complaint.', 'error');
        return;
      }
      if (!window.DeenlinkFlw || typeof window.DeenlinkFlw.reportPayment !== 'function') {
        notify('Payment system not loaded. Please refresh and try again.', 'error');
        return;
      }
      send.disabled = true;
      try {
        await window.DeenlinkFlw.reportPayment(txRef, txId, message);
        showSuccessModal('Your report has been received. Our team will review it and update your donation history.');
        el.style.display = 'none';
        if (opts && typeof opts.onSubmitted === 'function') opts.onSubmitted();
      } catch (e) {
        notify((e && e.message) ? e.message : 'Failed to submit complaint', 'error');
      } finally {
        send.disabled = false;
      }
    };
  }

  window.DeenlinkPaymentComplaint = { open };
})();
