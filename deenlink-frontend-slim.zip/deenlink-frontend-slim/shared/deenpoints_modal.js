// shared/deenpoints_modal.js
// Universal DeenPoints purchase modal wiring (Flutterwave).
//
// This script is intentionally DOM-driven so we can reuse it across many pages
// that share the same modal IDs/classes (purchaseModal, confirmPurchaseBtn, etc.).
// It also removes the old "simulate purchase" click handlers by cloning buttons.
(function () {
  'use strict';

  if (!window.DeenlinkFlw) return;

  const Flw = window.DeenlinkFlw;
  const STANDARD_NOTE = 'DeenPoints do not buy fatwas or Islamic opinions. They are used for purchases in DeenLink, unlocking app content, and setting the priority of questions sent to scholars.';
  const IMG_SRC = '../img/deenPoints.png';

  let quoteCache = null;
  let quoteCacheAt = 0;
  let lastKnownBalance = 0;

  async function getQuoteCached() {
    const now = Date.now();
    if (quoteCache && (now - quoteCacheAt) < 60000) return quoteCache;
    const q = await Flw.quoteDeenpoints();
    quoteCache = q;
    quoteCacheAt = now;
    return q;
  }

  function $(id) { return document.getElementById(id); }

  function safeText(el, txt) { if (el) el.textContent = String(txt); }

  function ensureModalStyles() {
    if ($('deenpointsModalSharedStyles')) return;
    const style = document.createElement('style');
    style.id = 'deenpointsModalSharedStyles';
    style.textContent = `
      #purchaseModal{position:fixed;inset:0;display:none;align-items:center;justify-content:center;padding:20px;background:rgba(0,0,0,.7);z-index:10040;opacity:0;transition:opacity .25s ease}
      #purchaseModal.active{display:flex;opacity:1}
      #purchaseModal .modal-content{background:var(--surface,var(--white,#fff));color:var(--text,var(--text-dark,#222));border-radius:20px;max-width:500px;width:100%;max-height:90vh;overflow-y:auto;box-shadow:0 10px 40px rgba(0,0,0,.2)}
      #purchaseModal .modal-header{padding:20px;border-bottom:1px solid var(--border,var(--medium-gray,#e5e7eb));display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;background:var(--surface,var(--white,#fff));z-index:2;border-radius:20px 20px 0 0}
      #purchaseModal .modal-title{font-size:20px;font-weight:600;color:var(--text,var(--text-dark,#222));display:flex;align-items:center;gap:10px}
      #purchaseModal .close-modal{background:none;border:none;color:var(--muted,var(--dark-gray,#6b7280));font-size:20px;cursor:pointer;width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;transition:background-color .2s ease}
      #purchaseModal .close-modal:hover{background:var(--surface-2,var(--light-gray,#f3f4f6))}
      #purchaseModal .modal-body{padding:20px}
      #purchaseModal .info-box{margin-top:0;padding:16px;background:rgba(29,111,66,.1);border-radius:12px;border-left:4px solid var(--primary-green,#1D6F42)}
      #purchaseModal .info-title{display:flex;align-items:center;gap:8px;font-size:14px;font-weight:600;color:var(--primary-green,#1D6F42);margin-bottom:8px}
      #purchaseModal .info-text{font-size:13px;line-height:1.5;color:var(--text,var(--text-dark,#222))}
      #purchaseModal .purchase-options{display:grid;grid-template-columns:repeat(2,1fr);gap:15px;margin:20px 0}
      #purchaseModal .purchase-option{padding:20px;border-radius:12px;border:2px solid var(--border,var(--medium-gray,#d1d5db));background:var(--surface,var(--white,#fff));cursor:pointer;transition:all .2s ease;text-align:center}
      #purchaseModal .purchase-option:hover{border-color:var(--accent-gold,#D4AF37);transform:translateY(-2px)}
      #purchaseModal .purchase-option.selected{border-color:var(--accent-gold,#D4AF37);background:rgba(212,175,55,.1)}
      #purchaseModal .purchase-amount{font-size:18px;font-weight:600;color:var(--accent-gold,#D4AF37);margin-bottom:5px;display:flex;align-items:center;justify-content:center;gap:6px}
      #purchaseModal .purchase-amount img{width:20px;height:20px;flex-shrink:0}
      #purchaseModal .purchase-cost,#purchaseModal .currency{font-size:14px;color:var(--muted,var(--dark-gray,#6b7280))}
      #purchaseModal .custom-purchase{grid-column:1 / -1}
      #purchaseModal .custom-input-group{display:flex;gap:10px;align-items:center}
      #purchaseModal .custom-input-group input{flex:1;padding:14px 16px;border:1px solid var(--border,var(--medium-gray,#d1d5db));border-radius:12px;font-size:15px;color:var(--text,var(--text-dark,#222));background:var(--surface,var(--white,#fff))}
      #purchaseModal .important-note{background:rgba(212,175,55,.1);padding:15px;border-radius:10px;margin:20px 0;border-left:4px solid var(--accent-gold,#D4AF37)}
      #purchaseModal .important-note-title{display:flex;align-items:center;gap:8px;font-size:14px;font-weight:600;color:var(--accent-gold,#D4AF37);margin-bottom:8px}
      #purchaseModal .important-note-text{font-size:13px;color:var(--text,var(--text-dark,#222));line-height:1.6}
      #purchaseModal .modal-navigation{display:flex;justify-content:space-between;margin-top:30px;padding-top:20px;border-top:1px solid var(--border,var(--medium-gray,#d1d5db));gap:12px}
      #purchaseModal .modal-btn{padding:12px 24px;border-radius:10px;font-size:14px;font-weight:600;cursor:pointer;transition:all .2s ease;border:none;display:flex;align-items:center;justify-content:center;gap:8px;flex:1}
      #purchaseModal .btn-secondary{background:var(--surface-2,var(--medium-gray,#d1d5db));color:var(--text,var(--text-dark,#222))}
      #purchaseModal .btn-primary{background:var(--primary-green,#1D6F42);color:#fff}
      #purchaseModal .purchase-success{text-align:center;padding:30px 20px}
      #purchaseModal .purchase-success-icon{width:80px;height:80px;background:var(--success-green,#27ae60);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 25px;color:#fff;font-size:36px}
      #purchaseModal .purchase-success-title{font-size:24px;font-weight:600;color:var(--success-green,#27ae60);margin-bottom:15px}
      #purchaseModal .purchase-success-message{font-size:16px;color:var(--text,var(--text-dark,#222));line-height:1.6;margin-bottom:25px}
      #purchaseModal .purchase-success-details{background:var(--light-green,#e8f5e9);padding:20px;border-radius:12px;margin-bottom:30px;text-align:center}
      #purchaseModal .purchase-success-amount{font-size:28px;font-weight:700;color:var(--accent-gold,#D4AF37);margin-bottom:10px;display:flex;align-items:center;justify-content:center;gap:10px}
      #purchaseModal .purchase-success-amount img{width:28px;height:28px}
      #purchaseModal .purchase-success-balance{font-size:14px;color:var(--text,var(--text-dark,#222));margin-top:10px;padding-top:10px;border-top:1px solid var(--border,var(--medium-gray,#d1d5db))}
      #purchaseModal .close-success-btn{background:var(--primary-green,#1D6F42);color:#fff;border:none;padding:14px 30px;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;display:flex;align-items:center;gap:10px;margin:0 auto}
      @media (max-width:480px){#purchaseModal .purchase-options{grid-template-columns:1fr}#purchaseModal .modal-navigation{flex-direction:column}}
    `;
    document.head.appendChild(style);
  }

  function ensureModalMarkup() {
    if ($('purchaseModal')) return;
    const wrapper = document.createElement('div');
    wrapper.innerHTML = `
      <div class="modal-overlay" id="purchaseModal">
        <div class="modal-content">
          <div class="modal-header">
            <div class="modal-title"><i class="fas fa-coins"></i><span>Purchase DeenPoints</span></div>
            <button class="close-modal" id="closePurchaseModal" type="button"><i class="fas fa-times"></i></button>
          </div>
          <div class="modal-body">
            <div class="purchase-success" id="purchaseSuccessContent" style="display:none;">
              <div class="purchase-success-icon"><i class="fas fa-check"></i></div>
              <h2 class="purchase-success-title">Purchase Successful!</h2>
              <p class="purchase-success-message">Your DeenPoints have been added to your account.</p>
              <div class="purchase-success-details">
                <div class="purchase-success-amount" id="purchaseSuccessAmount"><img src="${IMG_SRC}" alt="DeenPoints"><span>0</span></div>
                <div class="purchase-success-cost" id="purchaseSuccessCost">USD 0.00</div>
                <div class="purchase-success-balance">New Balance: <strong id="newBalance">...</strong> DeenPoints</div>
              </div>
              <button class="close-success-btn" id="closeSuccessBtn" type="button"><i class="fas fa-check-circle"></i>Continue</button>
            </div>
            <div id="purchaseFormContent">
              <div class="info-box">
                <div class="info-title"><i class="fas fa-info-circle"></i><span>Current Balance</span></div>
                <div class="info-text"><div style="display:flex;align-items:center;gap:10px;font-size:18px;font-weight:600;"><img src="${IMG_SRC}" alt="DeenPoints" style="width:24px;height:24px;"><span id="currentBalanceDisplay">...</span><span>DeenPoints</span></div></div>
              </div>
              <div class="form-group">
                <label class="form-label">Quick Purchase Options</label>
                <div class="purchase-options">
                  <div class="purchase-option" data-points="500"><div class="purchase-amount"><img src="${IMG_SRC}" alt="DeenPoints"><span>500</span></div><div class="purchase-cost">...</div></div>
                  <div class="purchase-option" data-points="1000"><div class="purchase-amount"><img src="${IMG_SRC}" alt="DeenPoints"><span>1,000</span></div><div class="purchase-cost">...</div></div>
                  <div class="purchase-option" data-points="2500"><div class="purchase-amount"><img src="${IMG_SRC}" alt="DeenPoints"><span>2,500</span></div><div class="purchase-cost">...</div></div>
                  <div class="purchase-option" data-points="5000"><div class="purchase-amount"><img src="${IMG_SRC}" alt="DeenPoints"><span>5,000</span></div><div class="purchase-cost">...</div></div>
                  <div class="purchase-option custom-purchase">
                    <label class="form-label">Custom Amount</label>
                    <div class="custom-input-group">
                      <input type="number" class="form-input" id="customDeenPoints" min="100" max="10000" placeholder="Enter amount">
                      <span class="currency">DeenPoints</span>
                    </div>
                    <div style="margin-top:10px;font-size:14px;color:var(--dark-gray,#6b7280);">Cost: <span id="customCostDisplay">...</span> (<span data-per-point>...</span>)</div>
                  </div>
                </div>
              </div>
              <div class="important-note">
                <div class="important-note-title"><i class="fas fa-exclamation-triangle"></i><span>Important Note</span></div>
                <div class="important-note-text">${STANDARD_NOTE}</div>
              </div>
              <div class="modal-navigation">
                <button class="modal-btn btn-secondary" id="cancelPurchaseBtn" type="button"><i class="fas fa-times"></i>Cancel</button>
                <button class="modal-btn btn-primary" id="confirmPurchaseBtn" type="button"><i class="fas fa-shopping-cart"></i>Purchase</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(wrapper.firstElementChild);
  }

  function normalizeExistingModalContent() {
    document.querySelectorAll('#purchaseModal .important-note-text').forEach((el) => {
      safeText(el, STANDARD_NOTE);
    });
    document.querySelectorAll('#purchaseModal .purchase-cost').forEach((el) => {
      const raw = String(el.textContent || '').trim();
      if (!raw || raw.includes('Ã') || raw.includes('¢') || raw === '?0.00') el.textContent = '...';
    });
    const customCost = $('customCostDisplay');
    if (customCost) {
      const raw = String(customCost.textContent || '').trim();
      if (!raw || raw.includes('Ã') || raw.includes('¢') || raw === '?0.00') customCost.textContent = '...';
    }
  }

  function formatCompactDeenPoints(value) {
    const n = Number(value || 0);
    const abs = Math.abs(n);
    if (abs >= 1e9) return (n / 1e9).toFixed(abs >= 1e10 ? 0 : 1).replace(/\.0$/, '') + 'B';
    if (abs >= 1e6) return (n / 1e6).toFixed(abs >= 1e7 ? 0 : 1).replace(/\.0$/, '') + 'M';
    if (abs >= 1e3) return (n / 1e3).toFixed(abs >= 1e5 ? 0 : 1).replace(/\.0$/, '') + 'K';
    return String(Math.trunc(n));
  }
  window.formatDeenPointsCompact = window.formatDeenPointsCompact || formatCompactDeenPoints;
  function formatFullDeenPoints(value) {
    return Number(value || 0).toLocaleString();
  }

  function restoreCompactUserBalance() {
    const userSpan = $('userDeenPoints');
    if (userSpan) safeText(userSpan, formatCompactDeenPoints(lastKnownBalance));
  }

  function interceptClick(el, handler) {
    if (!el) return;
    // Capture-phase handler runs before page handlers; stopImmediatePropagation prevents legacy listeners.
    el.addEventListener('click', function (e) {
      try {
        e.preventDefault();
        e.stopImmediatePropagation();
      } catch (_) { /* ignore */ }
      handler(e);
    }, true);
  }

  function getSelectedPoints() {
    const selected = document.querySelector('.purchase-option:not(.custom-purchase).selected');
    if (selected && selected.dataset && selected.dataset.points) {
      return Number(selected.dataset.points) || 0;
    }
    const custom = $('customDeenPoints');
    if (custom && custom.value) return Number(custom.value) || 0;
    return 0;
  }

  function clearSelection() {
    document.querySelectorAll('.purchase-option').forEach((opt) => opt.classList.remove('selected'));
  }

  function setLoading(btn, isLoading, labelHtml) {
    if (!btn) return;
    if (isLoading) {
      btn.dataset._origHtml = btn.innerHTML;
      btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
      btn.disabled = true;
    } else {
      btn.innerHTML = labelHtml || btn.dataset._origHtml || '<i class="fas fa-shopping-cart"></i> Purchase';
      btn.disabled = false;
    }
  }

  function formatMoneyAdaptive(currency, amount) {
    const cur = String(currency || 'USD').toUpperCase();
    const n = Number(amount || 0);
    const abs = Math.abs(n);
    // Per-point prices can be tiny for some currencies; show more precision so it doesn't look like 0.00.
    const maxFrac = (abs > 0 && abs < 0.01) ? 6 : 2;
    const opts = { minimumFractionDigits: 2, maximumFractionDigits: maxFrac };
    if (cur === 'NGN') return '\u20A6' + n.toLocaleString(undefined, opts);
    return cur + ' ' + n.toLocaleString(undefined, opts);
  }

  function applyQuoteToModal(q) {
    const pricing = (q && q.pricing) ? q.pricing : null;
    const packs = (q && q.packs) ? q.packs : [];
    const cur = String(pricing?.currency || 'USD').toUpperCase();
    const rate = Number(pricing?.rate_ngn_to_currency || 1);
    const pppNgn = Number(pricing?.price_per_point_ngn || 1.5);

    // Quick options amounts
    const packMap = {};
    packs.forEach((p) => { packMap[Number(p.points)] = Number(p.amount); });

    document.querySelectorAll('.purchase-option:not(.custom-purchase)').forEach((opt) => {
      const pts = Number(opt.dataset.points || 0);
      const amount = (packMap[pts] != null) ? packMap[pts] : ((cur === 'NGN') ? (pts * pppNgn) : (pts * pppNgn * rate));
      const costEl = opt.querySelector('.purchase-cost');
      if (costEl) costEl.textContent = Flw.formatMoney(cur, amount);
      opt.dataset.cost_amount = String(amount);
      opt.dataset.cost_currency = cur;
    });

    // Custom input cost display
    const customInput = $('customDeenPoints');
    const customCostDisplay = $('customCostDisplay');
    if (customInput && customCostDisplay) {
      const pts = Number(customInput.value || 0);
      const base = pts * pppNgn;
      const amt = (cur === 'NGN') ? base : (base * rate);
      // If user hasn't entered any points yet, avoid showing "0.00" which looks broken.
      customCostDisplay.textContent = (pts > 0) ? Flw.formatMoney(cur, amt) : '--';
    }

    // Optional: update any "(... per DeenPoint)" helper text if present.
    const helper = document.querySelector('.custom-purchase [data-per-point]');
    if (helper) {
      const ppp = (cur === 'NGN') ? pppNgn : (pppNgn * rate);
      helper.textContent = formatMoneyAdaptive(cur, ppp) + ' per DeenPoint';
    }
  }

  async function refreshBalanceDisplays() {
    const userSpan = $('userDeenPoints');
    const modalSpan = $('modalDeenPoints');
    const currentBalance = $('currentBalanceDisplay');
    try {
      const b = await Flw.getBalance();
      const bal = Number(b.deenpoints_balance || 0);
      lastKnownBalance = bal;
      safeText(userSpan, formatCompactDeenPoints(bal));
      safeText(modalSpan, formatFullDeenPoints(bal));
      safeText(currentBalance, formatFullDeenPoints(bal));
      return bal;
    } catch (e) {
      // Not logged in: show 0 (avoid flashing wrong hardcoded values).
      lastKnownBalance = 0;
      safeText(userSpan, '0');
      safeText(modalSpan, '0');
      safeText(currentBalance, '0');
      return 0;
    }
  }

  async function openPurchaseModal() {
    const purchaseModal = $('purchaseModal');
    if (!purchaseModal) return;

    // Ensure UI starts clean.
    const purchaseFormContent = $('purchaseFormContent');
    const purchaseSuccessContent = $('purchaseSuccessContent');
    if (purchaseFormContent) purchaseFormContent.style.display = 'block';
    if (purchaseSuccessContent) purchaseSuccessContent.style.display = 'none';
    const customCost = $('customCostDisplay');
    if (customCost) customCost.textContent = '--';
    const helper = document.querySelector('.custom-purchase [data-per-point]');
    if (helper) helper.textContent = '...';

    // Open immediately, then hydrate the numbers in the background so the button never feels laggy.
    purchaseModal.classList.add('active');
    document.body.style.overflow = 'hidden';
    restoreCompactUserBalance();

    refreshBalanceDisplays().catch(() => {});

    // Quote prices for user's country/currency (Nigeria forced to NGN server-side).
    getQuoteCached().then((q) => {
      if (q && q.status === 'success') applyQuoteToModal(q);
    }).catch(() => {
      // Keep modal usable even if FX quote fails.
    });
  }

  function prewarmPricing() {
    try {
      refreshBalanceDisplays().catch(() => {});
      getQuoteCached().catch(() => {});
    } catch (_) {
      // Best-effort warmup only.
    }
  }

  function closePurchaseModal() {
    const purchaseModal = $('purchaseModal');
    if (purchaseModal) purchaseModal.classList.remove('active');
    document.body.style.overflow = 'auto';
    restoreCompactUserBalance();
    clearSelection();
    const custom = $('customDeenPoints');
    if (custom) custom.value = '';
    const customCost = $('customCostDisplay');
    if (customCost) customCost.textContent = '--';
    const helper = document.querySelector('.custom-purchase [data-per-point]');
    if (helper) helper.textContent = '...';
    const form = $('purchaseFormContent');
    const success = $('purchaseSuccessContent');
    if (form) form.style.display = 'block';
    if (success) success.style.display = 'none';
    restoreCompactUserBalance();
  }

  async function confirmPurchase() {
    const confirmBtn = $('confirmPurchaseBtn');
    const points = getSelectedPoints();
    if (!points || points <= 0) {
      Flw.toast('Please select a purchase option or enter a custom amount.', 'info');
      return;
    }

    setLoading(confirmBtn, true);
    try {
      const init = await Flw.initDeenpoints(points);
      if (!init || init.status !== 'success' || !init.checkout) {
        throw new Error((init && init.message) ? init.message : 'Unable to start payment');
      }

      let cbData = null;
      try {
        cbData = await Flw.openFlutterwaveCheckout(init.checkout);
      } catch (e) {
        throw e;
      }
      const txId = cbData && (cbData.transaction_id || cbData.id) ? (cbData.transaction_id || cbData.id) : '';
      if (!txId) throw new Error('Payment did not return transaction id');

      async function verifyWithRetry(txRef, txId) {
        const delays = [900, 1800, 2600, 3600];
        let lastErr = null;
        for (let i = 0; i < delays.length; i++) {
          try {
            return await Flw.verify(txRef, txId || '');
          } catch (e) {
            lastErr = e;
            await Flw.sleep(delays[i]);
          }
        }
        if (lastErr) throw lastErr;
        throw new Error('Verification failed');
      }

      const vr = await verifyWithRetry(init.checkout.tx_ref, txId);
      if (!vr || vr.status !== 'success') throw new Error((vr && vr.message) ? vr.message : 'Verification failed');

      const purchaseFormContent = $('purchaseFormContent');
      const purchaseSuccessContent = $('purchaseSuccessContent');
      const purchaseSuccessAmount = $('purchaseSuccessAmount');
      const purchaseSuccessCost = $('purchaseSuccessCost');
      const newBalance = $('newBalance');

      if (purchaseSuccessAmount) {
        purchaseSuccessAmount.innerHTML = '<img src="../img/deenPoints.png" alt="DeenPoints"> <span>' + Number(vr.points_added || points).toLocaleString() + '</span>';
      }
      if (purchaseSuccessCost) {
        purchaseSuccessCost.textContent = Flw.formatMoney(init.checkout.currency, init.checkout.amount);
      }
      if (newBalance) safeText(newBalance, formatFullDeenPoints(Number(vr.deenpoints_balance || 0)));

      lastKnownBalance = Number(vr.deenpoints_balance || 0);
      safeText($('userDeenPoints'), formatCompactDeenPoints(Number(vr.deenpoints_balance || 0)));
      safeText($('modalDeenPoints'), formatFullDeenPoints(Number(vr.deenpoints_balance || 0)));
      safeText($('currentBalanceDisplay'), formatFullDeenPoints(Number(vr.deenpoints_balance || 0)));

      if (purchaseFormContent) purchaseFormContent.style.display = 'none';
      if (purchaseSuccessContent) purchaseSuccessContent.style.display = 'block';

      Flw.toast('DeenPoints purchase successful.', 'success');
    } catch (e) {
      const msg = (e && e.message) ? e.message : 'Payment failed';
      if (String(msg).toLowerCase().includes('not logged in') || (e && e.status === 401)) {
        Flw.toast('Please log in to purchase DeenPoints.', 'error');
      } else if ((e && e.code === 'closed') || String(msg).toLowerCase().includes('closed') || String(msg).toLowerCase().includes('cancel')) {
        Flw.toast('Payment cancelled.', 'info');
      } else {
        Flw.toast(msg, 'error');
      }
    } finally {
      setLoading(confirmBtn, false);
    }
  }

  function setupOptionSelection() {
    document.querySelectorAll('.purchase-option:not(.custom-purchase)').forEach((opt) => {
      opt.addEventListener('click', function () {
        document.querySelectorAll('.purchase-option:not(.custom-purchase)').forEach((o) => o.classList.remove('selected'));
        opt.classList.add('selected');
        const custom = $('customDeenPoints');
        if (custom) custom.value = '';
      });
    });

    const custom = $('customDeenPoints');
    if (custom) {
      custom.addEventListener('input', async function () {
        const q = await getQuoteCached().catch(() => null);
        if (!q || q.status !== 'success') return;
        const cur = String(q.pricing?.currency || 'USD').toUpperCase();
        const rate = Number(q.pricing?.rate_ngn_to_currency || 1);
        const pppNgn = Number(q.pricing?.price_per_point_ngn || 1.5);
        const pts = Number(custom.value || 0);
        const base = pts * pppNgn;
        const amt = (cur === 'NGN') ? base : (base * rate);
        const costEl = $('customCostDisplay');
        if (costEl) costEl.textContent = (pts > 0) ? Flw.formatMoney(cur, amt) : '--';
        if (pts > 0) {
          document.querySelectorAll('.purchase-option:not(.custom-purchase)').forEach((o) => o.classList.remove('selected'));
        }
      });
    }
  }

  function init() {
    ensureModalStyles();
    ensureModalMarkup();
    normalizeExistingModalContent();
    if (!$('purchaseModal') || !$('confirmPurchaseBtn')) return;

    ['userDeenPoints', 'modalDeenPoints', 'currentBalanceDisplay', 'newBalance'].forEach((id) => {
      const el = $(id);
      if (el) el.textContent = '...';
    });

    const confirmBtn = $('confirmPurchaseBtn');
    const cancelBtn = $('cancelPurchaseBtn');
    const closeBtn = $('closePurchaseModal');
    const closeSuccessBtn = $('closeSuccessBtn');

    const openA = $('deenpointsBalanceBtn');
    const openB = $('modalDeenPointsBtn');

    interceptClick(openA, openPurchaseModal);
    interceptClick(openB, openPurchaseModal);

    interceptClick(closeBtn, closePurchaseModal);
    interceptClick(cancelBtn, closePurchaseModal);
    interceptClick(closeSuccessBtn, closePurchaseModal);

    const modal = $('purchaseModal');
    if (modal) {
      modal.addEventListener('click', function (e) {
        if (e.target === modal) closePurchaseModal();
      });
    }

    interceptClick(confirmBtn, confirmPurchase);

    setupOptionSelection();
    prewarmPricing();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
