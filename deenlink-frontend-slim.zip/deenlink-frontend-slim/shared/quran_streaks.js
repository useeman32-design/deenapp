(function () {
  function appBase() {
    var path = window.location.pathname || '';
    var idx = path.toLowerCase().indexOf('/deenlink/');
    return idx >= 0 ? path.slice(0, idx + '/deenlink'.length) : '';
  }

  function apiUrl() {
    return appBase() + '/api/quran/streak.php';
  }

  function currentPath() {
    return String(window.location.pathname || '').toLowerCase();
  }

  function isQuranModulePage() {
    var path = currentPath();
    return path.indexOf('/quranhadith/') !== -1;
  }

  function isSurahPage() {
    return currentPath().indexOf('/quranhadith/surah.html') !== -1;
  }

  function isAutoCelebratePage() {
    return isReaderPage();
  }

  function isReaderPage() {
    return currentPath().indexOf('/quranhadith/reader.html') !== -1;
  }

  function todayReaderVisitKey() {
    return 'dl_quran_reader_opened_' + todayLocalDate();
  }

  function markReaderVisitedToday() {
    try {
      localStorage.setItem(todayReaderVisitKey(), '1');
    } catch (_) {}
  }

  function hasVisitedReaderToday() {
    try {
      return localStorage.getItem(todayReaderVisitKey()) === '1';
    } catch (_) {
      return false;
    }
  }

  function canAutoCelebrateToday() {
    return isReaderPage();
  }

  function injectStyles() {
    if (document.getElementById('dl_quran_streak_styles')) return;
    var style = document.createElement('style');
    style.id = 'dl_quran_streak_styles';
    style.textContent = [
      '.dl-streak-badge{display:inline-flex;align-items:center;gap:6px;padding:4px 8px;border-radius:999px;background:linear-gradient(135deg,#ff8a3d,#ff5c2f);color:#fff;font-size:11px;font-weight:700;line-height:1;box-shadow:0 10px 22px rgba(255,92,47,.28)}',
      '.dl-streak-badge i{font-size:11px}',
      '.nav-item .dl-streak-badge{position:absolute;top:5px;right:14px;padding:2px 4px;font-size:8px;min-width:24px;gap:3px;justify-content:center;box-shadow:0 6px 16px rgba(255,92,47,.24)}',
      '.nav-item .dl-streak-badge i{font-size:9px}',
      '.nav-item{position:relative}',
      '.quran-card .dl-card-streak{position:absolute;top:16px;right:16px;z-index:3}',
      '.quran-card{position:relative;overflow:hidden}',
      '.dl-surah-header-streak{display:inline-flex;align-items:center;justify-content:flex-end;min-width:72px}',
      '.dl-surah-header-streak .dl-streak-badge{padding:8px 14px;font-size:14px;min-width:auto;box-shadow:0 12px 28px rgba(255,92,47,.28)}',
      '.dl-surah-header-streak .dl-streak-badge i{font-size:14px}',
      '.dl-surah-header-streak .dl-streak-badge span:last-child{font-size:14px}',
      '.dl-streak-clickable{cursor:pointer}',
      '.dl-streak-modal{position:fixed;inset:0;background:rgba(0,0,0,.55);display:none;align-items:center;justify-content:center;padding:18px;z-index:12000}',
      '.dl-streak-modal.show{display:flex}',
      '.dl-streak-panel{width:min(100%,420px);background:linear-gradient(180deg,var(--streak-surface-1,#fff),var(--streak-surface-2,#f7fafc));border-radius:28px;padding:24px 22px 20px;box-shadow:0 24px 60px rgba(0,0,0,.26);text-align:center;animation:dlStreakPop .28s ease;color:var(--streak-text,#18232d);border:1px solid var(--streak-border,rgba(255,255,255,.28));overflow:hidden}',
      '.dark-theme .dl-streak-panel{background:linear-gradient(180deg,var(--streak-surface-1,#13202a),var(--streak-surface-2,#0f171e));color:var(--streak-text,#ecf0f1);border:1px solid var(--streak-border,rgba(124,145,163,.18))}',
      '.dl-streak-icon{width:78px;height:78px;border-radius:24px;margin:0 auto 16px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,var(--streak-accent,#ef4444),var(--streak-accent-2,#b91c1c));color:#fff;font-size:32px;box-shadow:0 16px 32px var(--streak-shadow,rgba(239,68,68,.28))}',
      '.dl-streak-panel h3{font-size:24px;margin-bottom:8px}',
      '.dl-streak-panel p{font-size:14px;line-height:1.65;color:var(--streak-muted,#5b6973)}',
      '.dark-theme .dl-streak-panel p{color:var(--streak-muted,#c8d2d8)}',
      '.dl-streak-day{display:flex;align-items:center;justify-content:center;gap:8px;margin:16px auto 0;padding:10px 16px;border-radius:999px;background:var(--streak-day-bg,rgba(29,111,66,.08));color:var(--streak-day-text,#1d6f42);font-weight:800;width:fit-content;max-width:100%;box-shadow:0 8px 18px var(--streak-day-shadow,rgba(29,111,66,.08))}',
      '.dark-theme .dl-streak-day{background:var(--streak-day-bg,rgba(46,204,113,.12));color:var(--streak-day-text,#7ef0ac)}',
      '.dl-streak-meta{margin-top:12px;font-size:13px;line-height:1.6;color:var(--streak-muted,#5b6973)}',
      '.dark-theme .dl-streak-meta{color:var(--streak-muted,#c8d2d8)}',
      '.dl-streak-ok{display:block;margin:18px auto 0;border:none;border-radius:16px;background:linear-gradient(135deg,var(--streak-accent,#ef4444),var(--streak-accent-2,#b91c1c));color:#fff;padding:12px 18px;font-weight:700;cursor:pointer;box-shadow:0 12px 24px var(--streak-shadow,rgba(239,68,68,.22))}',
      '.dl-streak-panel.special .dl-streak-icon{background:linear-gradient(135deg,var(--streak-accent,#f39c12),var(--streak-accent-2,#ff5c2f))}',
      '.dl-streak-panel.warning{--streak-accent:#f59e0b;--streak-accent-2:#fbbf24;--streak-day-bg:rgba(245,158,11,.15);--streak-day-text:#b45309;--streak-shadow:rgba(245,158,11,.28)}',
      '.dl-streak-panel.expired{--streak-accent:#ef4444;--streak-accent-2:#b91c1c;--streak-day-bg:rgba(239,68,68,.12);--streak-day-text:#b91c1c;--streak-shadow:rgba(239,68,68,.28)}',
      '@keyframes dlStreakPop{from{transform:translateY(18px) scale(.96);opacity:0}to{transform:translateY(0) scale(1);opacity:1}}'
    ].join('');
    document.head.appendChild(style);
  }

  function ensureModal() {
    var modal = document.getElementById('dlQuranStreakModal');
    if (modal) return modal;
    modal = document.createElement('div');
    modal.id = 'dlQuranStreakModal';
    modal.className = 'dl-streak-modal';
    modal.innerHTML = '' +
      '<div class="dl-streak-panel" id="dlQuranStreakPanel">' +
      '<div class="dl-streak-icon"><i class="fas fa-fire"></i></div>' +
      '<h3 id="dlQuranStreakTitle">Streak Started</h3>' +
      '<p id="dlQuranStreakMessage">Keep reading Quran every day to build and protect your streak.</p>' +
      '<div class="dl-streak-day" id="dlQuranStreakDay"><i class="fas fa-fire"></i><span>Day 1</span></div>' +
      '<div class="dl-streak-meta" id="dlQuranStreakMeta"></div>' +
      '<button class="dl-streak-ok" id="dlQuranStreakOk" type="button">Keep Going</button>' +
      '</div>';
    document.body.appendChild(modal);
    modal.addEventListener('click', function (e) {
      if (e.target === modal) modal.classList.remove('show');
    });
    modal.querySelector('#dlQuranStreakOk').addEventListener('click', function () {
      modal.classList.remove('show');
    });
    return modal;
  }

  var lastLoadedData = null;

  function buildBadge(day, extraClass, clickable) {
    var label = Number(day || 0);
    if (!label) return '';
    var classes = 'dl-streak-badge ' + (clickable ? 'dl-streak-clickable ' : '') + (extraClass || '');
    var attrs = clickable ? ' role="button" tabindex="0"' : '';
    return '<span class="' + classes.trim() + '"' + attrs + '><i class="fas fa-fire"></i><span>' + label + '</span></span>';
  }

  function renderBadges(data) {
    var current = Number(data && data.streak && data.streak.current || 0);
    document.querySelectorAll('.dl-streak-badge, .dl-card-streak').forEach(function (node) { node.remove(); });
    if (!current) return;

    document.querySelectorAll('.nav-item[href*="quranHadith/index.html"]').forEach(function (nav) {
      nav.insertAdjacentHTML('beforeend', buildBadge(current, 'dl-nav-streak', false));
    });

    var quranCard = document.getElementById('quranCard');
    if (quranCard) {
      var wrap = document.createElement('div');
      wrap.className = 'dl-card-streak';
      wrap.innerHTML = buildBadge(current, 'dl-card-streak-inner', false);
      quranCard.appendChild(wrap);
    }

    document.querySelectorAll('.dl-surah-header-streak').forEach(function (slot) {
      slot.innerHTML = buildBadge(current, 'dl-surah-header-streak-inner', isSurahPage());
    });

    bindBadgeInteractions(data);
  }

  function nextMilestoneText(day) {
    var current = Number(day || 0);
    if (!current) return 'Start reading today to begin your Quran streak.';
    if (current < 10) return 'Next milestone: Day 10.';
    if (current < 100) {
      var nextTen = Math.ceil((current + 1) / 10) * 10;
      return 'Next milestone: Day ' + nextTen + '.';
    }
    var nextHundred = Math.ceil((current + 1) / 100) * 100;
    return 'Next milestone: Day ' + nextHundred + '.';
  }

  function milestoneTheme(day) {
    var current = Number(day || 0);
    if (!current) {
      return {
        accent: '#ef4444',
        accent2: '#b91c1c',
        surface1: '#ffffff',
        surface2: '#fff5f5',
        text: '#18232d',
        muted: '#5b6973',
        border: 'rgba(239,68,68,.12)',
        dayBg: 'rgba(239,68,68,.08)',
        dayText: '#b91c1c',
        shadow: 'rgba(239,68,68,.22)'
      };
    }
    if (current >= 100 && current % 100 === 0) {
      return {
        accent: '#d4af37',
        accent2: '#f6c343',
        surface1: '#fffdf2',
        surface2: '#f7f0d2',
        text: '#2a2110',
        muted: '#6a5a2e',
        border: 'rgba(212,175,55,.28)',
        dayBg: 'rgba(212,175,55,.16)',
        dayText: '#9a6f06',
        shadow: 'rgba(212,175,55,.32)'
      };
    }
    if (current >= 10 && current % 10 === 0) {
      var palettes = [
        { accent: '#7c3aed', accent2: '#a855f7', surface1: '#fbf5ff', surface2: '#efe5ff', text: '#28163f', muted: '#65427f', border: 'rgba(124,58,237,.22)', dayBg: 'rgba(124,58,237,.12)', dayText: '#6d28d9', shadow: 'rgba(124,58,237,.28)' },
        { accent: '#0ea5e9', accent2: '#38bdf8', surface1: '#f2fbff', surface2: '#dff4ff', text: '#0b2a3a', muted: '#426374', border: 'rgba(14,165,233,.22)', dayBg: 'rgba(14,165,233,.12)', dayText: '#0369a1', shadow: 'rgba(14,165,233,.28)' },
        { accent: '#14b8a6', accent2: '#34d399', surface1: '#f0fdfa', surface2: '#d7fce9', text: '#0f2f2a', muted: '#3d6661', border: 'rgba(20,184,166,.22)', dayBg: 'rgba(20,184,166,.12)', dayText: '#0f766e', shadow: 'rgba(20,184,166,.28)' },
        { accent: '#f97316', accent2: '#fb923c', surface1: '#fff8f1', surface2: '#ffe7d6', text: '#351a06', muted: '#7a4e24', border: 'rgba(249,115,22,.22)', dayBg: 'rgba(249,115,22,.12)', dayText: '#c2410c', shadow: 'rgba(249,115,22,.28)' },
        { accent: '#ef4444', accent2: '#f97316', surface1: '#fff5f5', surface2: '#ffe4e4', text: '#3a1111', muted: '#7a4141', border: 'rgba(239,68,68,.22)', dayBg: 'rgba(239,68,68,.12)', dayText: '#b91c1c', shadow: 'rgba(239,68,68,.28)' },
        { accent: '#10b981', accent2: '#22c55e', surface1: '#f0fdf4', surface2: '#dcfce7', text: '#10251a', muted: '#3a6650', border: 'rgba(16,185,129,.22)', dayBg: 'rgba(16,185,129,.12)', dayText: '#047857', shadow: 'rgba(16,185,129,.28)' },
        { accent: '#ec4899', accent2: '#f472b6', surface1: '#fff4fa', surface2: '#ffe3f1', text: '#351425', muted: '#7a4262', border: 'rgba(236,72,153,.22)', dayBg: 'rgba(236,72,153,.12)', dayText: '#be185d', shadow: 'rgba(236,72,153,.28)' },
        { accent: '#3b82f6', accent2: '#60a5fa', surface1: '#f3f8ff', surface2: '#dfeaff', text: '#12243f', muted: '#45607f', border: 'rgba(59,130,246,.22)', dayBg: 'rgba(59,130,246,.12)', dayText: '#1d4ed8', shadow: 'rgba(59,130,246,.28)' },
        { accent: '#8b5cf6', accent2: '#c084fc', surface1: '#faf6ff', surface2: '#efe6ff', text: '#26173f', muted: '#634b80', border: 'rgba(139,92,246,.22)', dayBg: 'rgba(139,92,246,.12)', dayText: '#7c3aed', shadow: 'rgba(139,92,246,.28)' }
      ];
      return palettes[Math.max(0, Math.floor(current / 10) - 1) % palettes.length];
    }
    return {
      accent: '#1d6f42',
      accent2: '#155c35',
      surface1: '#ffffff',
      surface2: '#f7fafc',
      text: '#18232d',
      muted: '#5b6973',
      border: 'rgba(29,111,66,.12)',
      dayBg: 'rgba(29,111,66,.08)',
      dayText: '#1d6f42',
      shadow: 'rgba(29,111,66,.22)'
    };
  }

  function applyThemeVars(panel, theme) {
    if (!panel || !theme) return;
    panel.style.setProperty('--streak-accent', theme.accent || '#1d6f42');
    panel.style.setProperty('--streak-accent-2', theme.accent2 || '#155c35');
    panel.style.setProperty('--streak-surface-1', theme.surface1 || '#ffffff');
    panel.style.setProperty('--streak-surface-2', theme.surface2 || '#f7fafc');
    panel.style.setProperty('--streak-text', theme.text || '#18232d');
    panel.style.setProperty('--streak-muted', theme.muted || '#5b6973');
    panel.style.setProperty('--streak-border', theme.border || 'rgba(29,111,66,.12)');
    panel.style.setProperty('--streak-day-bg', theme.dayBg || 'rgba(29,111,66,.08)');
    panel.style.setProperty('--streak-day-text', theme.dayText || '#1d6f42');
    panel.style.setProperty('--streak-shadow', theme.shadow || 'rgba(29,111,66,.22)');
  }

  function streakCacheToken(streak) {
    var raw = String(
      (streak && (streak.streak_expires_at || streak.last_activity_at || streak.last_activity_date)) || todayLocalDate()
    );
    return raw.replace(/\s+/g, ' ').trim() || todayLocalDate();
  }

  function openStatusModal(data) {
    var streak = data && data.streak ? data.streak : null;
    var current = Number(streak && streak.current || 0);
    if (!current) return;
    var best = Number(streak && streak.best || 0);
    var title = 'Quran Streak';
    var message = 'Keep reading Quran every day to protect your streak.';
    var meta = 'Current streak: ' + current + ' day' + (current === 1 ? '' : 's') + '.';
    if (best > current) meta += ' Best streak: ' + best + ' days.';
    meta += ' ' + nextMilestoneText(current);
    showModal({
      title: title,
      message: message,
      streak_day: current,
      special: current >= 10 && current % 10 === 0,
      theme: milestoneTheme(current),
      meta: meta
    }, false);
  }

  function bindBadgeInteractions(data) {
    document.querySelectorAll('.dl-streak-clickable').forEach(function (node) {
      if (node.dataset.bound === '1') return;
      node.dataset.bound = '1';
      node.addEventListener('click', function () {
        openStatusModal(data || lastLoadedData);
      });
      node.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          openStatusModal(data || lastLoadedData);
        }
      });
    });
  }

  function showModal(payload, markSeen) {
    if (!payload) return;
    var eventDate = String(payload.activity_date || todayLocalDate());
    var seenKey = 'dl_quran_streak_seen_' + eventDate;
    if (markSeen !== false) {
      try {
        if (localStorage.getItem(seenKey) === '1') return;
        localStorage.setItem(seenKey, '1');
      } catch (_) {}
    }

    var modal = ensureModal();
    var panel = document.getElementById('dlQuranStreakPanel');
    var title = document.getElementById('dlQuranStreakTitle');
    var message = document.getElementById('dlQuranStreakMessage');
    var day = document.getElementById('dlQuranStreakDay');
    var meta = document.getElementById('dlQuranStreakMeta');
    var icon = panel ? panel.querySelector('.dl-streak-icon i') : null;
    if (!modal || !panel || !title || !message || !day || !meta) return;
    panel.classList.remove('special', 'warning', 'expired');
    if (payload.variant === 'warning') panel.classList.add('warning');
    if (payload.variant === 'expired') panel.classList.add('expired');
    panel.classList.toggle('special', !!payload.special);
    applyThemeVars(panel, payload.theme || milestoneTheme(payload.streak_day));
    title.textContent = String(payload.title || 'Quran Streak');
    message.textContent = String(payload.message || 'Keep reading Quran every day.');
    var iconClass = payload.variant === 'warning' ? 'fa-hourglass-half' : (payload.variant === 'expired' ? 'fa-ban' : 'fa-fire');
    if (icon) icon.className = 'fas ' + iconClass;
    day.innerHTML = '<i class="fas ' + iconClass + '"></i><span>Day ' + Number(payload.streak_day || 0) + '</span>';
    meta.textContent = String(payload.meta || nextMilestoneText(payload.streak_day));
    modal.classList.add('show');
  }

  function showCelebration(celebration) {
    if (!celebration || !celebration.streak_day) return;
    celebration.meta = celebration.meta || nextMilestoneText(celebration.streak_day);
    celebration.theme = celebration.theme || milestoneTheme(celebration.streak_day);
    showModal(celebration, true);
  }

  function todayLocalDate() {
    var now = new Date();
    return [
      now.getFullYear(),
      String(now.getMonth() + 1).padStart(2, '0'),
      String(now.getDate()).padStart(2, '0')
    ].join('-');
  }

  function inferCelebrationFromState(data) {
    var streak = data && data.streak ? data.streak : null;
    var current = Number(streak && streak.current || 0);
    var lastActivityDate = String(streak && streak.last_activity_date || '');
    if (!current || !lastActivityDate || lastActivityDate !== todayLocalDate()) return null;
    if (current === 1) {
      return {
        type: 'started',
        title: 'Streak Started',
        message: 'Keep reading Quran every day to build and protect your streak.',
        streak_day: 1,
        activity_date: lastActivityDate,
        special: false,
        meta: nextMilestoneText(1)
      };
    }
    if (current >= 100 && current % 100 === 0) {
      return {
        type: 'milestone_100',
        title: 'Amazing Consistency',
        message: "Congratulations, you've reached " + current + ' days of Quran reading.',
        streak_day: current,
        activity_date: lastActivityDate,
        special: true,
        theme: milestoneTheme(current),
        meta: nextMilestoneText(current)
      };
    }
    if (current >= 10 && current % 10 === 0) {
      return {
        type: 'milestone_10',
        title: 'Quran Streak Milestone',
        message: "Congratulations, you've reached " + current + ' days. Keep going.',
        streak_day: current,
        activity_date: lastActivityDate,
        special: true,
        theme: milestoneTheme(current),
        meta: nextMilestoneText(current)
      };
    }
    return {
      type: 'daily_progress',
      title: 'Quran Streak Updated',
      message: 'Your Quran streak moved forward today. Keep reading tomorrow to protect it.',
      streak_day: current,
      activity_date: lastActivityDate,
      special: false,
      meta: nextMilestoneText(current)
    };
  }

  function maybeShowWarningModal(data) {
    if (!data || !data.warning) return;
    var streak = data.streak || {};
    var current = Number(streak.current || 0);
    if (!current) return;
    var dateKey = 'dl_quran_streak_warning_' + streakCacheToken(streak);
    try {
      if (localStorage.getItem(dateKey) === '1') return;
      localStorage.setItem(dateKey, '1');
    } catch (_) {}
    showModal({
      title: 'Streak expiring soon',
      message: 'Read today to keep your Quran streak alive.',
      streak_day: current,
      activity_date: todayLocalDate(),
      special: false,
      variant: 'warning',
      theme: milestoneTheme(current),
      meta: 'Open the Quran now to protect your streak.'
    }, false);
  }

  function maybeShowExpiredModal(data) {
    if (!data || !data.expired) return;
    var streak = data.streak || {};
    var dateKey = 'dl_quran_streak_expired_' + streakCacheToken(streak);
    try {
      if (localStorage.getItem(dateKey) === '1') return;
      localStorage.setItem(dateKey, '1');
    } catch (_) {}
    showModal({
      title: 'Streak expired',
      message: 'Your Quran streak has expired. Start a new streak today.',
      streak_day: 0,
      activity_date: todayLocalDate(),
      special: false,
      variant: 'expired',
      theme: milestoneTheme(0),
      meta: 'Open the Quran to restart your streak.'
    }, false);
  }

  async function fetchJson(method, body) {
    var res = await fetch(apiUrl(), {
      method: method || 'GET',
      credentials: 'include',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: body ? JSON.stringify(body) : undefined
    });
    return await res.json().catch(function () { return null; });
  }

  async function loadStreak() {
    var data = await fetchJson('GET');
    if (!data || data.status !== 'success') return null;
    lastLoadedData = data;
    renderBadges(data);
    if (isQuranModulePage()) {
      maybeShowWarningModal(data);
      maybeShowExpiredModal(data);
    }
    if (isReaderPage()) {
      var inferred = inferCelebrationFromState(data);
      if (inferred) showCelebration(inferred);
    }
    return data;
  }

  async function recordRead(source) {
    var localDate = todayLocalDate();
    markReaderVisitedToday();
    var data = await fetchJson('POST', {
      source: String(source || 'reader'),
      local_date: localDate
    });
    if (!data || data.status !== 'success') return null;
    lastLoadedData = data;
    renderBadges(data);
    if (isQuranModulePage()) {
      maybeShowWarningModal(data);
      maybeShowExpiredModal(data);
    }
    if (canAutoCelebrateToday()) {
      if (data.celebration) {
        data.celebration.meta = data.celebration.meta || nextMilestoneText(data.celebration.streak_day);
        showCelebration(data.celebration);
      } else {
        var inferred = inferCelebrationFromState(data);
        if (inferred) showCelebration(inferred);
      }
    }
    return data;
  }

  injectStyles();
  window.DeenLinkQuranStreak = {
    load: loadStreak,
    recordRead: recordRead,
    showCelebration: showCelebration
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      if (isReaderPage()) markReaderVisitedToday();
      loadStreak().catch(function () {});
    });
  } else {
    if (isReaderPage()) markReaderVisitedToday();
    loadStreak().catch(function () {});
  }
})();
