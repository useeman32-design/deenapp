// Public settings helper (cached).
// Used for lightweight client-side gating (maintenance, premium enabled, etc).
(function () {
  const CACHE_KEY = 'deenlink_public_settings_v1';
  const CACHE_TTL_MS = 30 * 1000; // keep it short so admin changes propagate quickly

  function now() { return Date.now(); }

  function getCached(options) {
    const allowStale = !!(options && options.allowStale);
    try {
      const raw = sessionStorage.getItem(CACHE_KEY);
      if (!raw) return null;
      const obj = JSON.parse(raw);
      if (!obj || typeof obj !== 'object') return null;
      if (!obj.t || !obj.settings) return null;
      if (!allowStale && (now() - obj.t) > CACHE_TTL_MS) return null;
      return obj.settings;
    } catch (_) {
      return null;
    }
  }

  function setCached(settings) {
    try {
      sessionStorage.setItem(CACHE_KEY, JSON.stringify({ t: now(), settings }));
    } catch (_) { /* ignore */ }
  }

  async function fetchPublicSettings(apiPath) {
    const cached = getCached();
    if (cached) return cached;

    const url = apiPath || 'api/settings/public.php';
    const stale = getCached({ allowStale: true });

    try {
      const res = await fetch(url, { credentials: 'include' });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data || data.status !== 'success' || !data.settings) {
        if (stale) return stale;
        throw new Error((data && data.message) ? data.message : `Failed to load settings (${res.status || 0})`);
      }
      setCached(data.settings);
      return data.settings;
    } catch (err) {
      if (stale) return stale;
      throw err;
    }
  }

  window.DeenLinkSettings = window.DeenLinkSettings || {};
  window.DeenLinkSettings.getPublic = fetchPublicSettings;
})();

// Web push subscription
(function () {
  const PROMPT_KEY = 'dl_webpush_prompted_v1';
  const ENABLED_KEY = 'dl_webpush_enabled_v1';
  const NOTIF_PREF_KEY = 'notificationsEnabled';
  let gesturePromptBound = false;

  function getBasePath() {
    if (typeof window.BASE_PATH === 'string') return window.BASE_PATH;
    const path = String(window.location.pathname || '');
    const idx = path.toLowerCase().indexOf('/deenlink/');
    return idx >= 0 ? path.slice(0, idx + '/deenlink'.length) : '';
  }

  function buildUrl(path) {
    const base = getBasePath();
    const clean = String(path || '').startsWith('/') ? String(path || '') : '/' + String(path || '');
    return base + clean;
  }

  function urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) outputArray[i] = rawData.charCodeAt(i);
    return outputArray;
  }

  async function fetchPublicKey() {
    const res = await fetch(buildUrl('/api/notifications/web_push_public_key.php'), { credentials: 'include' });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data || data.status !== 'success' || !data.enabled) return '';
    return String(data.public_key || '');
  }

  async function ensureSubscription(registration, publicKey) {
    const existing = await registration.pushManager.getSubscription();
    if (existing) {
      await fetch(buildUrl('/api/notifications/web_push_subscribe.php'), {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subscription: existing })
      });
      return existing;
    }
    const sub = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(publicKey)
    });
    await fetch(buildUrl('/api/notifications/web_push_subscribe.php'), {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ subscription: sub })
    });
    return sub;
  }

  async function initWebPush(options = {}) {
    const prompt = !!options.prompt;
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      return { ok: false, reason: 'unsupported' };
    }
    if (Notification.permission === 'denied') {
      return { ok: false, reason: 'permission_denied' };
    }

    const publicKey = await fetchPublicKey();
    if (!publicKey) return { ok: false, reason: 'public_key_missing' };

    const reg = await (window.DeenLinkAppUpdate?.registerServiceWorker ? window.DeenLinkAppUpdate.registerServiceWorker() : navigator.serviceWorker.register(buildUrl('/sw.js')));
    if (!reg) return { ok: false, reason: 'sw_failed' };

    const alreadyPrompted = localStorage.getItem(PROMPT_KEY) === '1';
    if (Notification.permission === 'default') {
      if (!prompt) return { ok: false, reason: 'permission_default' };
      localStorage.setItem(PROMPT_KEY, '1');
      const perm = await Notification.requestPermission();
      if (perm !== 'granted') return { ok: false, reason: 'permission_denied' };
    }
    if (Notification.permission !== 'granted') return { ok: false, reason: 'permission_denied' };
    try {
      await ensureSubscription(reg, publicKey);
    } catch (_) {
      return { ok: false, reason: 'subscribe_failed' };
    }
    localStorage.setItem(ENABLED_KEY, '1');
    return { ok: true };
  }

  async function disableWebPush() {
    if (!('serviceWorker' in navigator)) return;
    try {
      const reg = await navigator.serviceWorker.getRegistration();
      if (!reg) return;
      const sub = await reg.pushManager.getSubscription();
      if (!sub) return;
      await fetch(buildUrl('/api/notifications/web_push_unsubscribe.php'), {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ endpoint: sub.endpoint })
      }).catch(() => {});
      await sub.unsubscribe().catch(() => {});
      localStorage.removeItem(ENABLED_KEY);
    } catch (_) {}
  }

  window.DeenLinkWebPush = {
    request: () => initWebPush({ prompt: true }),
    ensure: () => initWebPush({ prompt: false }),
    disable: () => disableWebPush()
  };

  function ensureGesturePrompt() {
    if (gesturePromptBound) return;
    if (!('Notification' in window)) return;
    if (Notification.permission !== 'default') return;
    gesturePromptBound = true;
    const handler = () => {
      document.removeEventListener('click', handler, true);
      initWebPush({ prompt: true }).catch(() => {});
    };
    document.addEventListener('click', handler, true);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      if (localStorage.getItem(NOTIF_PREF_KEY) === null) {
        localStorage.setItem(NOTIF_PREF_KEY, 'true');
      }
      const enabledPref = localStorage.getItem(NOTIF_PREF_KEY) !== 'false';
      initWebPush({ prompt: !!enabledPref }).catch(() => {});
      if (enabledPref) ensureGesturePrompt();
    }, { once: true });
  } else {
    if (localStorage.getItem(NOTIF_PREF_KEY) === null) {
      localStorage.setItem(NOTIF_PREF_KEY, 'true');
    }
    const enabledPref = localStorage.getItem(NOTIF_PREF_KEY) !== 'false';
    initWebPush({ prompt: !!enabledPref }).catch(() => {});
    if (enabledPref) ensureGesturePrompt();
  }

  // Lightweight fallback notifications (no push subscription):
  // Poll for new unread notifications and display Web Notifications when permission is granted.
  // This matches the "working" behavior in the other project: it works while the app/site is open.
  (function initNotificationPolling() {
    const SEEN_KEY = 'dl_notif_seen_ids_v1';
    const LAST_POLL_KEY = 'dl_notif_last_poll_v1';
    const MAX_SEEN = 220;
    const POLL_MS = 45000;
    let timer = 0;
    let inFlight = false;

    function canRun() {
      try {
        if (!('Notification' in window)) return false;
        if (Notification.permission !== 'granted') return false;
        if (localStorage.getItem(NOTIF_PREF_KEY) === 'false') return false;
        return true;
      } catch (_) {
        return false;
      }
    }

    function loadSeen() {
      try {
        const raw = localStorage.getItem(SEEN_KEY);
        const arr = raw ? JSON.parse(raw) : [];
        return Array.isArray(arr) ? arr.map((v) => String(v)).filter(Boolean) : [];
      } catch (_) {
        return [];
      }
    }

    function saveSeen(ids) {
      try {
        localStorage.setItem(SEEN_KEY, JSON.stringify(ids.slice(0, MAX_SEEN)));
      } catch (_) {}
    }

    function markSeen(id) {
      const ids = loadSeen();
      const key = String(id || '').trim();
      if (!key) return;
      if (ids.includes(key)) return;
      ids.unshift(key);
      saveSeen(ids);
    }

    function markPollNow() {
      try { localStorage.setItem(LAST_POLL_KEY, String(Date.now())); } catch (_) {}
    }

    function shouldNotifyNow() {
      // Avoid firing notifications while the user is actively looking at the page.
      // This keeps the UX sane while still providing background alerts.
      try {
        if (document.hidden) return true;
        if (typeof document.hasFocus === 'function' && !document.hasFocus()) return true;
      } catch (_) {}
      return false;
    }

    async function pollOnce() {
      if (!canRun()) return;
      if (inFlight) return;
      inFlight = true;
      try {
        const res = await fetch(buildUrl('/api/notifications/list.php?limit=25'), { credentials: 'include' });
        const data = await res.json().catch(() => null);
        if (!res.ok || !data || data.status !== 'success') return;
        const list = Array.isArray(data.notifications) ? data.notifications : [];
        if (!list.length) return;

        const seen = new Set(loadSeen());
        const shouldNotify = shouldNotifyNow();
        list.forEach((n) => {
          const id = n && n.id != null ? String(n.id) : '';
          if (!id || seen.has(id)) return;
          // Only notify for unread items.
          if (n.is_read) return;

          // Mark seen immediately to avoid duplicates on rapid polls.
          markSeen(id);
          if (!shouldNotify) return;

          const title = String(n.title || 'DeenLink').trim() || 'DeenLink';
          const body = String(n.body || '').trim();
          try {
            new Notification(title, { body, tag: 'dl_notif_' + id, renotify: false, silent: false });
          } catch (_) {}
        });
      } catch (_) {
        // silent
      } finally {
        inFlight = false;
        markPollNow();
      }
    }

    function start() {
      if (!canRun()) return;
      if (timer) return;
      pollOnce().catch(() => {});
      timer = window.setInterval(() => pollOnce().catch(() => {}), POLL_MS);
      window.addEventListener('visibilitychange', () => {
        if (!document.hidden) pollOnce().catch(() => {});
      });
      window.addEventListener('focus', () => pollOnce().catch(() => {}));
      window.addEventListener('online', () => pollOnce().catch(() => {}));
    }

    // Start only if user already granted permission (we never auto-prompt here).
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', start, { once: true });
    } else {
      start();
    }
  })();
})();

// Global UI fixes
(function () {
  // 1) Keep console clean for end-users; errors still show.
  // Enable verbose logs only if localStorage dl_debug === '1'.
  try {
    const dbg = localStorage.getItem('dl_debug') === '1';
    if (!dbg) {
      const noop = function () {};
      console.log = noop;
      console.info = noop;
      console.debug = noop;
    }
  } catch (_) { /* ignore */ }

  // 2) iOS Safari auto-zooms inputs with font-size < 16px. Prevent this globally.
  try {
    if (!document.getElementById('dl_ios_input_zoom_fix')) {
      const style = document.createElement('style');
      style.id = 'dl_ios_input_zoom_fix';
      style.textContent = "@supports (-webkit-touch-callout: none) { input, textarea, select { font-size: 16px !important; } } img, video, canvas { -webkit-touch-callout: none !important; -webkit-user-drag: none !important; user-select: none !important; }";
      document.head.appendChild(style);
    }
  } catch (_) { /* ignore */ }

  // 3) Prevent easy save/drag interactions on media across the web app too.
  try {
    const stopMediaPreview = (event) => {
      const target = event.target;
      if (!target || !(target.closest && target.closest('img,video,canvas'))) return;
      event.preventDefault();
    };
    const lockMediaNodes = (root) => {
      try {
        const scope = root && root.querySelectorAll ? root : document;
        scope.querySelectorAll('img,video,canvas').forEach((node) => {
          try { node.setAttribute('draggable', 'false'); } catch (_) {}
          try { node.draggable = false; } catch (_) {}
        });
      } catch (_) {}
    };
    lockMediaNodes(document);
    document.addEventListener('contextmenu', stopMediaPreview, true);
    document.addEventListener('dragstart', stopMediaPreview, true);
    document.addEventListener('selectstart', stopMediaPreview, true);
    const mo = new MutationObserver((mutations) => {
      mutations.forEach((m) => {
        m.addedNodes.forEach((node) => {
          if (node && node.nodeType === 1) lockMediaNodes(node);
        });
      });
    });
    mo.observe(document.documentElement || document.body, { childList: true, subtree: true });
  } catch (_) {}
})();

// App update bootstrap
(function () {
  const BUILD = '20260619_2';
  const VERSION_CHECK_MS = 5 * 60 * 1000;
  const UPDATE_RELOAD_FALLBACK_MS = 1600;
  const UPDATE_TOAST_FAILSAFE_MS = 8000;
  const RELOAD_MARKER_KEY = 'deenlink_app_reload_marker';
  const ACTIVE_BUILD_KEY = 'deenlink_active_build';
  let registered = false;
  let updateTriggered = false;
  let controllerHandled = false;
  let hadControllerAtBoot = false;
  let updateToastTimer = 0;

  function getCurrentBuild() {
    try {
      const stored = String(localStorage.getItem(ACTIVE_BUILD_KEY) || '').trim();
      return stored || BUILD;
    } catch (_) {
      return BUILD;
    }
  }

  function setCurrentBuild(build) {
    try {
      const next = String(build || '').trim() || BUILD;
      localStorage.setItem(ACTIVE_BUILD_KEY, next);
    } catch (_) {}
  }

  function getBasePath() {
    if (typeof window.BASE_PATH === 'string') return window.BASE_PATH;
    const path = String(window.location.pathname || '');
    const idx = path.toLowerCase().indexOf('/deenlink/');
    return idx >= 0 ? path.slice(0, idx + '/deenlink'.length) : '';
  }

  function buildUrl(path) {
    const base = getBasePath();
    const clean = String(path || '').startsWith('/') ? String(path || '') : '/' + String(path || '');
    return base + clean;
  }

  function swScope() {
    const base = getBasePath();
    return (base || '') + '/';
  }

  function getServiceWorkerBuild(workerLike) {
    try {
      const scriptUrl = String(workerLike && workerLike.scriptURL || '');
      if (!scriptUrl) return '';
      const url = new URL(scriptUrl, window.location.origin);
      return String(url.searchParams.get('v') || url.searchParams.get('__dlv') || '').trim();
    } catch (_) {
      return '';
    }
  }

  function shouldActivateWaitingWorker(registration, targetBuild) {
    try {
      if (!registration || !registration.waiting) return false;
      const waitingBuild = getServiceWorkerBuild(registration.waiting);
      const activeBuild = getServiceWorkerBuild(registration.active);
      const nextBuild = String(targetBuild || '').trim();
      if (waitingBuild && activeBuild && waitingBuild === activeBuild) return false;
      if (nextBuild && waitingBuild === nextBuild && activeBuild === nextBuild) return false;
      return true;
    } catch (_) {
      return !!(registration && registration.waiting);
    }
  }

  function markReload(build) {
    try { sessionStorage.setItem(RELOAD_MARKER_KEY, String(build || '')); } catch (_) {}
  }

  function hasReloadedFor(build) {
    try { return sessionStorage.getItem(RELOAD_MARKER_KEY) === String(build || ''); } catch (_) { return false; }
  }

  function clearReloadMarker(build) {
    try {
      const current = sessionStorage.getItem(RELOAD_MARKER_KEY);
      if (!build || current === String(build || '')) {
        sessionStorage.removeItem(RELOAD_MARKER_KEY);
      }
    } catch (_) {}
  }

  function hideUpdatingToast() {
    try {
      window.clearTimeout(updateToastTimer);
      const el = document.getElementById('dlAppUpdateToast');
      if (!el) return;
      el.style.opacity = '0';
      el.style.pointerEvents = 'none';
      el.style.transform = 'translateX(-50%) translateY(8px)';
      window.setTimeout(() => {
        if (el && el.parentNode) el.parentNode.removeChild(el);
      }, 220);
    } catch (_) {}
  }

  function settleCurrentBuildUi() {
    clearReloadMarker(getCurrentBuild());
    hideUpdatingToast();
    updateTriggered = false;
  }

  clearReloadMarker(getCurrentBuild());

  function showUpdatingToast() {
    try {
      let styleEl = document.getElementById('dlAppUpdateToastStyle');
      if (!styleEl) {
        styleEl = document.createElement('style');
        styleEl.id = 'dlAppUpdateToastStyle';
        styleEl.textContent = '@keyframes dlUpdateDotPulse{0%{transform:scale(.92);opacity:.7;box-shadow:0 0 0 0 rgba(29,111,66,.55)}55%{transform:scale(1.18);opacity:1;box-shadow:0 0 0 10px rgba(29,111,66,0)}100%{transform:scale(.92);opacity:.8;box-shadow:0 0 0 0 rgba(29,111,66,0)}}';
        document.head.appendChild(styleEl);
      }
      let el = document.getElementById('dlAppUpdateToast');
      if (!el) {
        el = document.createElement('div');
        el.id = 'dlAppUpdateToast';
        el.style.cssText = [
          'position:fixed',
          'left:50%',
          'bottom:calc(104px + env(safe-area-inset-bottom, 0px))',
          'transform:translateX(-50%)',
          'z-index:2147483647',
          'padding:12px 18px',
          'border-radius:999px',
          'background:rgba(12,18,28,.96)',
          'color:#fff',
          'font:600 13px/1.2 Poppins,sans-serif',
          'box-shadow:0 14px 32px rgba(0,0,0,.32)',
          'border:1px solid rgba(255,255,255,.1)',
          'display:flex',
          'align-items:center',
          'gap:8px',
          'opacity:1',
          'pointer-events:none',
          'transition:opacity .22s ease, transform .22s ease'
        ].join(';');
        el.innerHTML = '<span style="width:10px;height:10px;border-radius:50%;background:#22c55e;display:inline-block;animation:dlUpdateDotPulse .78s ease-in-out infinite"></span><span>Updating DeenLink...</span>';
        document.body.appendChild(el);
      }
      el.style.display = 'flex';
      el.style.opacity = '1';
      el.style.transform = 'translateX(-50%)';
      window.clearTimeout(updateToastTimer);
      updateToastTimer = window.setTimeout(() => {
        settleCurrentBuildUi();
      }, UPDATE_TOAST_FAILSAFE_MS);
    } catch (_) {}
  }

  function reloadForBuild(build) {
    if (hasReloadedFor(build)) {
      if (String(build || getCurrentBuild()) === getCurrentBuild()) {
        settleCurrentBuildUi();
      }
      return;
    }
    markReload(build);
    setCurrentBuild(build);
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('appv', String(build || getCurrentBuild()));
      window.location.replace(url.toString());
    } catch (_) {
      window.location.reload();
    }
  }

  function activateWaitingWorker(registration, build) {
    if (!registration || !registration.waiting) return;
    if (!shouldActivateWaitingWorker(registration, build)) {
      settleCurrentBuildUi();
      return;
    }
    try {
      registration.waiting.postMessage({ type: 'PURGE_CACHES', build: String(build || getCurrentBuild()) });
      registration.waiting.postMessage({ type: 'SKIP_WAITING', build: String(build || getCurrentBuild()) });
    } catch (_) {
      reloadForBuild(build || getCurrentBuild());
    }
  }

  function requestCachePurge(registration, build) {
    try {
      const message = { type: 'PURGE_CACHES', build: String(build || getCurrentBuild()) };
      if (registration && registration.waiting) {
        registration.waiting.postMessage(message);
      }
      if (registration && registration.active) {
        registration.active.postMessage(message);
      }
      if (navigator.serviceWorker && navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage(message);
      }
    } catch (_) {}
  }

  async function fetchServerBuild() {
    const url = new URL(buildUrl('/api/app/version.php'), window.location.origin);
    url.searchParams.set('t', String(Date.now()));
    const res = await fetch(url.toString(), {
      cache: 'no-store',
      credentials: 'same-origin',
      headers: { Accept: 'application/json' }
    });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data || data.status !== 'success') return '';
    return String(data.build || '');
  }

  function handleBuildMismatch(nextBuild, registration) {
    if (!nextBuild || nextBuild === getCurrentBuild() || updateTriggered) return;
    updateTriggered = true;
    showUpdatingToast();

    if (registration && registration.waiting) {
      requestCachePurge(registration, nextBuild);
      activateWaitingWorker(registration, nextBuild);
      window.setTimeout(() => reloadForBuild(nextBuild), document.hidden ? 900 : UPDATE_RELOAD_FALLBACK_MS);
      return;
    }

    requestCachePurge(registration, nextBuild);

    if (registration && typeof registration.update === 'function') {
      registration.update().catch(() => {});
    }

    window.setTimeout(() => reloadForBuild(nextBuild), document.hidden ? 900 : UPDATE_RELOAD_FALLBACK_MS);
  }

  async function checkForUpdates(registration) {
    if (updateTriggered) return;
    try {
      const build = await fetchServerBuild();
      handleBuildMismatch(build, registration || null);
    } catch (_) {}
  }

  function wireControllerReload() {
    if (!('serviceWorker' in navigator)) return;
    hadControllerAtBoot = hadControllerAtBoot || !!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (controllerHandled) return;
      if (!hadControllerAtBoot && !updateTriggered) return;
      controllerHandled = true;
      reloadForBuild(getCurrentBuild());
    });
  }

  async function registerServiceWorker() {
    if (!('serviceWorker' in navigator)) return null;
    if (registered) {
      try {
        return await navigator.serviceWorker.getRegistration(swScope());
      } catch (_) {
        return null;
      }
    }
    registered = true;
    wireControllerReload();
    try {
      const registration = await navigator.serviceWorker.register(buildUrl('/sw.js?v=' + encodeURIComponent(BUILD)), {
        scope: swScope(),
        updateViaCache: 'none'
      });

      if (registration.waiting && navigator.serviceWorker.controller) {
        if (updateTriggered && shouldActivateWaitingWorker(registration, getCurrentBuild())) {
          activateWaitingWorker(registration, getCurrentBuild());
        } else {
          settleCurrentBuildUi();
        }
      } else {
        settleCurrentBuildUi();
      }

      registration.addEventListener('updatefound', () => {
        const installing = registration.installing;
        if (!installing) return;
        installing.addEventListener('statechange', () => {
          if (installing.state === 'installed' && navigator.serviceWorker.controller) {
            if (updateTriggered && shouldActivateWaitingWorker(registration, getCurrentBuild())) {
              activateWaitingWorker(registration, getCurrentBuild());
            } else {
              settleCurrentBuildUi();
            }
          }
        });
      });

      checkForUpdates(registration);
      window.setInterval(() => checkForUpdates(registration), VERSION_CHECK_MS);
      window.addEventListener('focus', () => checkForUpdates(registration));
      document.addEventListener('visibilitychange', () => {
        if (!document.hidden) checkForUpdates(registration);
      });

      window.addEventListener('pageshow', () => {
        if (!updateTriggered) settleCurrentBuildUi();
      });
      window.addEventListener('load', () => {
        window.setTimeout(() => {
          if (!updateTriggered) settleCurrentBuildUi();
        }, 900);
      }, { once: true });

      return registration;
    } catch (_) {
      return null;
    }
  }

  window.DeenLinkAppUpdate = window.DeenLinkAppUpdate || {
    build: getCurrentBuild(),
    basePath: getBasePath(),
    registerServiceWorker,
    checkNow: () => checkForUpdates(null)
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      registerServiceWorker().catch(() => {});
    }, { once: true });
  } else {
    registerServiceWorker().catch(() => {});
  }
})();
