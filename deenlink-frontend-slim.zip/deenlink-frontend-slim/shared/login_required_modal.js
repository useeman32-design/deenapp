// Login required modal (no native alerts).
// Used to gate modules for non-logged-in users (videos, posters, AI, wallpapers, quiz, etc).
(function () {
  function ensureStyles() {
    if (document.getElementById('dlLoginReqStyles')) return;
    const css = `
      .dl-loginreq-overlay{
        position:fixed; inset:0; z-index:99998;
        background:rgba(0,0,0,.88);
        display:flex; align-items:center; justify-content:center;
        padding:24px;
      }
      .dl-loginreq-card{
        width:min(520px, 92vw);
        background:#0e1512;
        border:1px solid rgba(255,255,255,.14);
        border-radius:18px;
        padding:18px;
        color:#fff;
        box-shadow:0 30px 70px rgba(0,0,0,.55);
      }
      .dl-loginreq-head{display:flex; align-items:center; gap:10px; margin-bottom:10px;}
      .dl-loginreq-logo{width:34px; height:34px; border-radius:10px; background:rgba(29,111,66,.25); display:grid; place-items:center;}
      .dl-loginreq-title{font-weight:900; font-size:18px; margin:0;}
      .dl-loginreq-sub{opacity:.92; margin:0 0 14px; line-height:1.4; font-size:13px;}
      .dl-loginreq-actions{display:flex; gap:10px; flex-wrap:wrap;}
      .dl-loginreq-btn{
        border:0; border-radius:12px; padding:10px 14px;
        font-weight:800; cursor:pointer;
      }
      .dl-loginreq-btn.primary{background:#1D6F42; color:#fff;}
      .dl-loginreq-btn.ghost{background:rgba(255,255,255,.12); color:#fff;}
    `;
    const style = document.createElement('style');
    style.id = 'dlLoginReqStyles';
    style.textContent = css;
    document.head.appendChild(style);
  }

  function close() {
    const el = document.getElementById('dlLoginReqOverlay');
    if (el) el.remove();
  }

  function goBackOrHome(homeUrl) {
    try {
      if (history.length > 1) {
        history.back();
        return;
      }
    } catch (_) {}
    window.location.href = homeUrl || '../index.html';
  }

  function show(opts) {
    ensureStyles();
    close();
    const overlay = document.createElement('div');
    overlay.id = 'dlLoginReqOverlay';
    overlay.className = 'dl-loginreq-overlay';

    const next = (opts && opts.next) ? String(opts.next) : '';
    const loginUrl = (opts && opts.loginUrl) ? String(opts.loginUrl) : `profile/index.html?openAuth=login&next=${encodeURIComponent(next || window.location.pathname + window.location.search)}`;

    const card = document.createElement('div');
    card.className = 'dl-loginreq-card';
    card.innerHTML = `
      <div class="dl-loginreq-head">
        <div class="dl-loginreq-logo"><img src="${opts && opts.logoUrl ? opts.logoUrl : 'img/logo.png'}" alt="DeenLink" style="width:20px;height:20px;object-fit:contain" /></div>
        <h3 class="dl-loginreq-title">Login required</h3>
      </div>
      <p class="dl-loginreq-sub">${(opts && opts.message) ? opts.message : 'Please log in to continue.'}</p>
      <div class="dl-loginreq-actions">
        <button class="dl-loginreq-btn primary" id="dlLoginReqGo" type="button">Go to login</button>
        <button class="dl-loginreq-btn ghost" id="dlLoginReqCancel" type="button">Cancel</button>
      </div>
    `;
    overlay.appendChild(card);
    document.body.appendChild(overlay);

    const cancelMode = (opts && opts.cancelMode) ? String(opts.cancelMode) : 'close'; // close|back

    card.querySelector('#dlLoginReqCancel').addEventListener('click', () => {
      if (cancelMode === 'back') {
        close();
        goBackOrHome(opts && opts.homeUrl);
      } else {
        close();
      }
    });
    card.querySelector('#dlLoginReqGo').addEventListener('click', () => {
      window.location.href = loginUrl;
    });

    // Clicking outside:
    overlay.addEventListener('click', (e) => {
      if (e.target !== overlay) return;
      if (cancelMode === 'back') {
        close();
        goBackOrHome(opts && opts.homeUrl);
      } else {
        close();
      }
    });
  }

  window.DeenLinkAuthGate = window.DeenLinkAuthGate || {};
  window.DeenLinkAuthGate.showLoginRequired = show;
})();
