// Maintenance gate:
// Pages call this early to enforce admin "Maintenance Mode" settings.
// Why it exists:
// - Admin toggles are stored in DB (system_settings)
// - Client pages must actually read & enforce those toggles
// - We keep it lightweight (one cached call) and UX-friendly.
(function () {
  function ensureStyles() {
    if (document.getElementById('deenlinkMaintenanceGateStyles')) return;
    const css = `
      .dl-maintenance-overlay{
        position:fixed; inset:0; z-index:99999;
        background:rgba(0,0,0,.92);
        display:flex; align-items:center; justify-content:center;
        padding:24px;
      }
      .dl-maintenance-card{
        width:min(520px, 92vw);
        background:linear-gradient(180deg, rgba(255,255,255,.08), rgba(255,255,255,.04));
        border:1px solid rgba(255,255,255,.14);
        border-radius:18px;
        padding:18px;
        color:#fff;
        box-shadow:0 30px 70px rgba(0,0,0,.55);
        backdrop-filter: blur(10px);
      }
      .dl-maintenance-title{font-weight:900; font-size:18px; letter-spacing:.2px; margin:0 0 6px;}
      .dl-maintenance-sub{opacity:.9; margin:0 0 16px; line-height:1.4; font-size:13px;}
      .dl-maintenance-actions{display:flex; gap:10px; flex-wrap:wrap;}
      .dl-maintenance-btn{
        border:0; border-radius:12px; padding:10px 14px;
        font-weight:800; cursor:pointer;
      }
      .dl-maintenance-btn.primary{background:#1D6F42; color:#fff;}
      .dl-maintenance-btn.ghost{background:rgba(255,255,255,.12); color:#fff;}
    `;
    const style = document.createElement('style');
    style.id = 'deenlinkMaintenanceGateStyles';
    style.textContent = css;
    document.head.appendChild(style);
  }

  function showOverlay(opts) {
    ensureStyles();
    const existing = document.getElementById('dlMaintenanceOverlay');
    if (existing) existing.remove();

    const overlay = document.createElement('div');
    overlay.id = 'dlMaintenanceOverlay';
    overlay.className = 'dl-maintenance-overlay';

    const card = document.createElement('div');
    card.className = 'dl-maintenance-card';
    card.innerHTML = `
      <div class="dl-maintenance-title">Under maintenance</div>
      <p class="dl-maintenance-sub">${opts.message || 'This section is temporarily unavailable. Please check back soon.'}</p>
      <div class="dl-maintenance-actions">
        <button class="dl-maintenance-btn primary" id="dlMaintGoBack" type="button">Go back</button>
        <button class="dl-maintenance-btn ghost" id="dlMaintHome" type="button">Home</button>
      </div>
    `;
    overlay.appendChild(card);
    document.body.appendChild(overlay);

    const goBack = card.querySelector('#dlMaintGoBack');
    const goHome = card.querySelector('#dlMaintHome');

    goBack.addEventListener('click', () => {
      // Best-effort: if history is usable, go back; otherwise redirect.
      try {
        if (history.length > 1) history.back();
        else window.location.href = opts.homeUrl || '../index.html';
      } catch (_) {
        window.location.href = opts.homeUrl || '../index.html';
      }
    });
    goHome.addEventListener('click', () => {
      window.location.href = opts.homeUrl || '../index.html';
    });
  }

  async function enforce(opts) {
    const moduleKey = String(opts && opts.module ? opts.module : '').trim();
    const apiPath = (opts && opts.apiPath) ? opts.apiPath : null;

    try {
      if (!window.DeenLinkSettings || !window.DeenLinkSettings.getPublic) return;
      const settings = await window.DeenLinkSettings.getPublic(apiPath);
      const master = !!settings['maintenance.master'];
      const moduleFlag = moduleKey ? !!settings[`maintenance.${moduleKey}`] : false;
      if (master || moduleFlag) {
        showOverlay({
          message: opts && opts.message,
          homeUrl: opts && opts.homeUrl
        });
      }
    } catch (_) {
      // If settings can't be fetched, don't block the app.
    }
  }

  window.DeenLinkMaintenance = window.DeenLinkMaintenance || {};
  window.DeenLinkMaintenance.enforce = enforce;
})();

