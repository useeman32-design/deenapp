// Donation reward modal (used after successful charity payments).
// Matches the Daily Check-in modal styling from `profile/index.html`.
//
// Why this exists:
// - Donations are verified server-side, and we may reward donors with DeenPoints.
// - We show a consistent, non-native UI modal instead of `alert()`.
//
// Usage:
//   window.DeenlinkDonationReward.show({ points: 100, message: '...' })
//
// This script only injects DOM/CSS once.
(function () {
  'use strict';

  function appRoot() {
    const p = String(window.location.pathname || '').replace(/\\/g, '/');
    const idx = p.toLowerCase().indexOf('/deenlink/');
    if (idx >= 0) return p.slice(0, idx + '/deenLink/'.length);
    // Root deployment fallback
    return '/';
  }

  const ROOT = appRoot();

  function ensureInjected() {
    if (document.getElementById('donationRewardModal')) return;

    const style = document.createElement('style');
    style.id = 'donationRewardModalStyle';
    style.textContent = `
      .daily-checkin-modal.donation-reward-modal {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.8);
        z-index: 2500;
        display: none;
        justify-content: center;
        align-items: center;
        padding: 20px;
      }
      .daily-checkin-modal.donation-reward-modal.active {
        display: flex;
        animation: donationRewardFadeIn 0.3s ease;
      }
      @keyframes donationRewardFadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
      }
      .donation-reward-modal .daily-checkin-content {
        background: linear-gradient(135deg, #1D6F42, #2E7D32);
        border-radius: 20px;
        padding: 30px 20px;
        text-align: center;
        color: white;
        max-width: 350px;
        width: 100%;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
      }
      .donation-reward-modal .daily-checkin-icon {
        font-size: 50px;
        color: #D4AF37;
        margin-bottom: 15px;
        animation: donationRewardBounce 1s infinite alternate;
      }
      @keyframes donationRewardBounce {
        from { transform: translateY(0); }
        to { transform: translateY(-10px); }
      }
      .donation-reward-modal .daily-checkin-title {
        font-size: 22px;
        font-weight: 700;
        margin-bottom: 8px;
      }
      .donation-reward-modal .daily-checkin-subtitle {
        font-size: 14px;
        opacity: 0.95;
        margin-bottom: 20px;
      }
      .donation-reward-modal .daily-checkin-reward {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 12px;
        padding: 15px;
        margin-bottom: 20px;
        backdrop-filter: blur(10px);
      }
      .donation-reward-modal .reward-amount {
        font-size: 36px;
        font-weight: 700;
        color: #D4AF37;
        margin-bottom: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
      }
      .donation-reward-modal .reward-amount img {
        width: 32px;
        height: 32px;
      }
      .donation-reward-modal .reward-text {
        font-size: 12px;
        opacity: 0.92;
      }
      .donation-reward-modal .daily-checkin-btn {
        background-color: #D4AF37;
        color: #333;
        border: none;
        padding: 14px 30px;
        border-radius: 10px;
        font-size: 16px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
        width: 100%;
      }
      .donation-reward-modal .daily-checkin-btn:hover {
        background-color: #e6c158;
        transform: scale(1.05);
      }
    `;
    document.head.appendChild(style);

    const modal = document.createElement('div');
    modal.className = 'daily-checkin-modal donation-reward-modal';
    modal.id = 'donationRewardModal';
    modal.innerHTML = `
      <div class="daily-checkin-content" role="dialog" aria-modal="true" aria-labelledby="donationRewardTitle">
        <div class="daily-checkin-icon"><i class="fas fa-heart"></i></div>
        <div class="daily-checkin-title" id="donationRewardTitle">JazakAllahu khayran</div>
        <div class="daily-checkin-subtitle" id="donationRewardSubtitle">Your donation was received successfully.</div>
        <div class="daily-checkin-reward">
          <div class="reward-amount">
            <span id="donationRewardPoints">+0</span>
            <img src="${ROOT}img/deenpoints.png" alt="DeenPoints">
          </div>
          <div class="reward-text" id="donationRewardText">DeenPoints added as a thank you reward.</div>
        </div>
        <button class="daily-checkin-btn" id="donationRewardCloseBtn" type="button">Continue</button>
      </div>
    `;
    document.body.appendChild(modal);

    const close = () => modal.classList.remove('active');
    modal.addEventListener('click', (e) => { if (e.target === modal) close(); });
    modal.querySelector('#donationRewardCloseBtn').addEventListener('click', close);
  }

  function show(opts) {
    ensureInjected();
    const modal = document.getElementById('donationRewardModal');
    const points = Number(opts && opts.points) || 0;
    const title = (opts && opts.title) ? String(opts.title) : 'JazakAllahu khayran';
    const subtitle = (opts && opts.subtitle) ? String(opts.subtitle) : 'Your donation was received successfully.';
    const text = (opts && opts.text) ? String(opts.text) : 'DeenPoints added as a thank you reward.';

    const t = modal.querySelector('#donationRewardTitle');
    const st = modal.querySelector('#donationRewardSubtitle');
    const p = modal.querySelector('#donationRewardPoints');
    const rt = modal.querySelector('#donationRewardText');
    if (t) t.textContent = title;
    if (st) st.textContent = subtitle;
    if (p) p.textContent = (points >= 0 ? '+' : '') + String(points);
    if (rt) rt.textContent = text;

    modal.classList.add('active');
  }

  window.DeenlinkDonationReward = { show };
})();
