// shared/header_images.js
// Centralized header backgrounds (no external URLs).
// Pages call DeenLinkHeaderImages.applyRandomTopSection({ selector, basePath }).
(function () {
  const DEFAULTS = ['mecca.jpg', 'medina.jpg', 'kaabah.jpg'];

  function join(basePath, file) {
    const b = String(basePath || '.').replace(/\/+$/, '');
    return b + '/img/' + file;
  }

  function pickRandom(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  function applyRandomTopSection(opts) {
    const selector = (opts && opts.selector) ? String(opts.selector) : '.top-section-background';
    const basePath = (opts && opts.basePath) ? String(opts.basePath) : '..';
    const el = document.querySelector(selector);
    if (!el) return;

    const files = (opts && Array.isArray(opts.files) && opts.files.length)
      ? opts.files.map(String)
      : DEFAULTS.slice();

    const chosen = pickRandom(files);
    el.style.backgroundImage = "url('" + join(basePath, chosen) + "')";
  }

  window.DeenLinkHeaderImages = window.DeenLinkHeaderImages || {};
  window.DeenLinkHeaderImages.applyRandomTopSection = applyRandomTopSection;
})();

