// shared/donation_receipt.js
// Universal donation receipt renderer (used by Charity pages + history).
//
// Goal:
// - One consistent receipt layout across Zakat/Sadaqah/Support/History.
// - Includes DeenLink logo and selected recipient categories.
// - Purely presentational: uses existing page CSS where possible.
(function () {
  'use strict';

  function appRoot() {
    const p = String(window.location.pathname || '').replace(/\\/g, '/');
    const idx = p.toLowerCase().indexOf('/deenlink/');
    if (idx >= 0) return p.slice(0, idx + '/deenLink/'.length);
    return '/';
  }

  const ROOT = appRoot();

  function esc(s) {
    return String(s ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function formatMoney(currency, amount) {
    const c = String(currency || '').toUpperCase() || 'USD';
    const n = Number(amount || 0);
    return c + ' ' + n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function render(container, data) {
    const el = (typeof container === 'string') ? document.querySelector(container) : container;
    if (!el) return;

    const d = data || {};
    const title = String(d.title || 'Donation Receipt');
    const subtitle = String(d.subtitle || 'DeenLink');
    const txRef = String(d.tx_ref || '');
    const dateTime = String(d.date_time || '');
    const donorName = String(d.donor_name || '');
    const method = String(d.payment_method || 'Flutterwave');
    const currency = String(d.currency || 'USD');
    const amount = Number(d.amount || 0);
    const note = String(d.note || '').trim();
    const cats = Array.isArray(d.recipient_categories) ? d.recipient_categories.filter(Boolean) : [];

    const footer = String(
      d.footer_text ||
        'May Allah accept your charity and reward you. JazakAllahu khayran.'
    );

    const catsHtml = (cats.length > 0)
      ? cats.map((c) => `<span class="category-tag" style="display:inline-block;margin:4px 6px 0 0;">${esc(c)}</span>`).join('')
      : '<span style="color:#757575;">Not specified</span>';

    // Keep class names compatible with existing Charity page CSS, but also apply a few
    // inline styles so the receipt stays professional even on pages that don't define
    // all receipt classes (e.g. history modal).
    el.innerHTML = `
      <div class="receipt-header" style="display:flex;align-items:center;gap:12px;padding:16px;background:linear-gradient(135deg,#1D6F42,#2E7D32);color:#fff;">
        <img src="${esc(ROOT + 'img/logo.png')}" alt="DeenLink" style="width:38px;height:38px;border-radius:10px;object-fit:contain;background:rgba(255,255,255,0.12);padding:6px;">
        <div style="min-width:0;">
          <div class="receipt-title" style="font-weight:900;font-size:16px;line-height:1.1;">${esc(title)}</div>
          <div class="receipt-subtitle" style="font-weight:600;font-size:12px;opacity:.92;margin-top:3px;">${esc(subtitle)}</div>
        </div>
      </div>
      <div class="receipt-body" style="padding:14px;background:#fff;color:#222;">
        <div class="receipt-info" style="border:1px solid #eee;border-radius:14px;padding:10px 12px;">
          <div class="receipt-row" style="display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px dashed #e6e6e6;font-size:13px;">
            <div class="receipt-label" style="color:#666;">Transaction ID</div>
            <div class="receipt-value" style="font-weight:800;text-align:right;font-family:ui-monospace,Consolas,monospace;word-break:break-all;">${esc(txRef)}</div>
          </div>
          <div class="receipt-row" style="display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px dashed #e6e6e6;font-size:13px;">
            <div class="receipt-label" style="color:#666;">Date & Time</div>
            <div class="receipt-value" style="font-weight:800;text-align:right;">${esc(dateTime)}</div>
          </div>
          <div class="receipt-row" style="display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px dashed #e6e6e6;font-size:13px;">
            <div class="receipt-label" style="color:#666;">Donor Name</div>
            <div class="receipt-value" style="font-weight:800;text-align:right;">${esc(donorName)}</div>
          </div>
          <div class="receipt-row" style="display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px dashed #e6e6e6;font-size:13px;">
            <div class="receipt-label" style="color:#666;">Payment Method</div>
            <div class="receipt-value" style="font-weight:800;text-align:right;">${esc(method)}</div>
          </div>
          <div class="receipt-row" style="display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px dashed #e6e6e6;font-size:13px;">
            <div class="receipt-label" style="color:#666;">Currency</div>
            <div class="receipt-value" style="font-weight:800;text-align:right;">${esc(String(currency).toUpperCase())}</div>
          </div>
          <div class="receipt-row" style="display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:0;font-size:13px;align-items:flex-start;">
            <div class="receipt-label" style="color:#666;min-width:170px;">Selected Recipient Category</div>
            <div class="receipt-value" style="font-weight:800;text-align:right;">${catsHtml}</div>
          </div>
          ${note ? `
            <div class="receipt-row" style="display:flex;justify-content:space-between;gap:10px;padding:10px 0;border-top:1px dashed #e6e6e6;font-size:13px;align-items:flex-start;">
              <div class="receipt-label" style="color:#666;">Note</div>
              <div class="receipt-value" style="font-weight:700;text-align:right;white-space:pre-wrap;max-width:240px;">${esc(note)}</div>
            </div>
          ` : ''}
        </div>
        <div class="receipt-amount" style="margin-top:12px;text-align:center;font-weight:900;font-size:22px;color:#1D6F42;">${esc(formatMoney(currency, amount))}</div>
      </div>
      <div class="receipt-footer" style="padding:14px 16px;background:#f6faf7;border-top:1px solid #e8efe9;text-align:center;">
        <div style="font-weight:700;color:#1D6F42;line-height:1.45;">${esc(footer)}</div>
        <div style="margin-top:8px;font-size:12px;color:#666;font-weight:700;">Generated by DeenLink</div>
      </div>
    `;
  }

  window.DeenlinkReceipt = { render, ROOT };
})();
