// DeenLink activity reward timer (10-minute reading rewards, etc.).
//
// Why:
// - Users asked for DeenPoints rewards when they spend time reading beneficial content.
// - We avoid heavy tracking: we count only visible time on the page.
// - Server enforces idempotency (once per day per activity key) to prevent abuse.
//
// How it works:
// - Counts "active time" only while `document.visibilityState === 'visible'`.
// - When threshold is reached, makes ONE POST to `/api/deenpoints/reward_activity.php`.
// - Shows a DeenLink reward modal only when the server confirms a new award.
(function () {
  'use strict';

  function getBasePath() {
    const p = String(window.location.pathname || '/');
    const parts = p.split('/').filter(Boolean);
    if (parts.length === 0) return '';
    if (String(parts[0]).toLowerCase() === 'api') return '';
    return '/' + parts[0];
  }

  const API_ROOT = getBasePath() + '/api';
  let _csrf = '';

  async function getCsrfToken() {
    if (_csrf) return _csrf;
    const res = await fetch(API_ROOT + '/auth/csrf.php', { credentials: 'include', headers: { Accept: 'application/json' } });
    const data = await res.json().catch(() => ({}));
    _csrf = String(data.csrf_token || '');
    return _csrf;
  }

  function notify(msg) {
    if (typeof window.showNotification === 'function') {
      try { window.showNotification(msg); return; } catch (_) {}
    }
    // Minimal fallback: non-blocking toast.
    let n = document.getElementById('dlActivityRewardToast');
    if (!n) {
      n = document.createElement('div');
      n.id = 'dlActivityRewardToast';
      n.style.cssText = 'position:fixed;bottom:92px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,.82);color:#fff;padding:10px 12px;border-radius:12px;font-size:13px;z-index:2600;display:none;max-width:min(92vw,520px);text-align:center;';
      document.body.appendChild(n);
    }
    n.textContent = String(msg || '');
    n.style.display = 'block';
    clearTimeout(n._t);
    n._t = setTimeout(() => { n.style.display = 'none'; }, 2500);
  }

  async function postReward(activityKey) {
    const token = await getCsrfToken();
    const res = await fetch(API_ROOT + '/deenpoints/reward_activity.php', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json', 'X-CSRF-Token': token },
      body: JSON.stringify({ activity: String(activityKey || '') })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(String(data.message || 'Request failed'));
    return data;
  }

  function start(opts) {
    const activity = String(opts && opts.activity || '').trim();
    if (!activity) return;

    const minutes = Math.max(1, Number(opts && opts.minutes || 10));
    const iconClass = String(opts && opts.iconClass || 'fas fa-book-open');
    const title = String(opts && opts.title || 'MashaAllah');
    const subtitle = String(opts && opts.subtitle || 'Keep reading and reflecting.');
    const text = String(opts && opts.text || 'You earned DeenPoints for spending time reading.');

    const targetMs = minutes * 60 * 1000;
    let activeMs = 0;
    let lastTs = Date.now();
    let fired = false;

    // Count only while the tab is visible (prevents awarding for background tabs).
    function tick() {
      if (fired) return;
      const now = Date.now();
      const delta = Math.max(0, now - lastTs);
      lastTs = now;
      if (document.visibilityState === 'visible') {
        activeMs += delta;
        if (activeMs >= targetMs) {
          fired = true;
          attemptAward();
        }
      }
    }

    async function attemptAward() {
      try {
        const r = await postReward(activity);
        if (r && r.status === 'success' && r.awarded === true) {
          if (window.DeenlinkRewardModal && typeof window.DeenlinkRewardModal.show === 'function') {
            window.DeenlinkRewardModal.show({
              points: Number(r.points || 0),
              title,
              subtitle,
              text,
              iconClass
            });
          } else {
            notify('DeenPoints rewarded: +' + String(r.points || 0));
          }
        } else if (r && r.status === 'success' && r.awarded === false) {
          // Make the behavior clear: we intentionally cap this reward (server-side) to prevent abuse.
          // Without this, users think the feature is broken when they test multiple times in a day.
          notify('You already received today\'s reading reward.');
        }
      } catch (e) {
        // Silent on network failures; this is optional reward.
      }
    }

    // Run fast enough to feel immediate when threshold is reached, but cheap.
    const interval = setInterval(tick, 1000);
    // On bfcache restore, avoid duplicate intervals.
    window.addEventListener('pagehide', () => clearInterval(interval), { once: true });
  }

  window.DeenlinkActivityRewards = { start };
})();
