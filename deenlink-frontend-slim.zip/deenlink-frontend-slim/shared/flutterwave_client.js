// shared/flutterwave_client.js
// Flutterwave + DeenLink payments helper (client-side).
//
// SECURITY NOTE:
// - Flutterwave SECRET KEY must NEVER be in frontend code.
// - Frontend calls our PHP endpoints which compute amounts and verify transactions server-side.
// - All POSTs require CSRF.
(function () {
  'use strict';

  function appRoot() {
    // Works for localhost + production; expects app lives under /deenLink/.
    const p = String(window.location.pathname || '').replace(/\\/g, '/');
    const idx = p.toLowerCase().indexOf('/deenlink/');
    if (idx >= 0) return p.slice(0, idx + '/deenLink/'.length);
    return '/';
  }

  const ROOT = appRoot();
  const API = ROOT + 'api';

  let csrfToken = '';
  let flwScriptPromise = null;

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  async function apiJson(url, opts) {
    const res = await fetch(url, Object.assign({ credentials: 'include' }, opts || {}));
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) { /* ignore */ }
    if (!res.ok) {
      const msg = (data && data.message) ? data.message : ('Server error (' + res.status + ')');
      const err = new Error(msg);
      err.status = res.status;
      err.data = data;
      throw err;
    }
    if (!data || typeof data !== 'object') {
      const err = new Error('Invalid server response');
      err.status = res.status;
      err.raw = text;
      throw err;
    }
    return data;
  }

  async function getCsrf() {
    if (csrfToken) return csrfToken;
    const d = await apiJson(API + '/auth/csrf.php', { headers: { Accept: 'application/json' } });
    csrfToken = String(d.csrf_token || '');
    return csrfToken;
  }

  async function apiPostJson(url, bodyObj) {
    const token = await getCsrf();
    return apiJson(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': token,
        Accept: 'application/json'
      },
      body: JSON.stringify(bodyObj || {})
    });
  }

  function ensureToastCss() {
    if (document.getElementById('dlToastCss')) return;
    const s = document.createElement('style');
    s.id = 'dlToastCss';
    s.textContent = `
.dl-toast{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);z-index:99999;max-width:min(520px,calc(100vw - 24px));padding:12px 14px;border-radius:12px;color:#fff;font:500 14px/1.25 system-ui,-apple-system,Segoe UI,Roboto,Arial;box-shadow:0 12px 30px rgba(0,0,0,.25);opacity:0;transition:opacity .18s ease,transform .18s ease}
.dl-toast.show{opacity:1;transform:translateX(-50%) translateY(-4px)}
.dl-toast.success{background:linear-gradient(135deg,#1d6f42,#2ecc71)}
.dl-toast.error{background:linear-gradient(135deg,#b71c1c,#e53935)}
.dl-toast.info{background:linear-gradient(135deg,#0d47a1,#3498db)}
`;
    document.head.appendChild(s);
  }

  function toast(msg, type) {
    // Prefer app's existing notification system if available.
    try {
      if (typeof window.showNotification === 'function') {
        // many pages: showNotification(message, type)
        window.showNotification(String(msg || ''), type || 'info');
        return;
      }
    } catch (_) { /* ignore */ }

    ensureToastCss();
    const el = document.createElement('div');
    el.className = 'dl-toast ' + (type || 'info');
    el.textContent = String(msg || '');
    document.body.appendChild(el);
    // force reflow
    void el.offsetHeight;
    el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 2600);
    setTimeout(() => el.remove(), 3200);
  }

  function formatMoney(currency, amount) {
    const c = String(currency || '').toUpperCase() || 'USD';
    const n = Number(amount || 0);
    // Prefer symbols where important for UX (NGN). Keep others as ISO code for consistency.
    if (c === 'NGN') {
      return '\u20A6' + n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    return c + ' ' + n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  async function loadFlutterwaveScript() {
    if (window.FlutterwaveCheckout) return;
    if (flwScriptPromise) return flwScriptPromise;
    flwScriptPromise = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://checkout.flutterwave.com/v3.js';
      s.async = true;
      s.onload = () => resolve();
      s.onerror = () => reject(new Error('Failed to load Flutterwave'));
      document.head.appendChild(s);
    });
    return flwScriptPromise;
  }

  async function quoteDeenpoints() {
    return apiJson(API + '/payments/flutterwave/quote_deenpoints.php', { headers: { Accept: 'application/json' } });
  }

  async function quotePremium() {
    return apiJson(API + '/payments/flutterwave/quote_premium.php', { headers: { Accept: 'application/json' } });
  }

  async function getBalance() {
    return apiJson(API + '/users/balance.php', { headers: { Accept: 'application/json' } });
  }

  async function initDeenpoints(points) {
    return apiPostJson(API + '/payments/flutterwave/init_deenpoints.php', {
      points: Number(points || 0),
      source_page: String(window.location.pathname || '')
    });
  }

  async function initDonation(payload) {
    return apiPostJson(API + '/payments/flutterwave/init_donation.php', payload || {});
  }

  async function initPremium(plan) {
    return apiPostJson(API + '/payments/flutterwave/init_premium.php', { plan: String(plan || 'monthly') });
  }

  async function verify(txRef, transactionId) {
    return apiPostJson(API + '/payments/flutterwave/verify.php', {
      tx_ref: String(txRef || ''),
      transaction_id: String(transactionId || '')
    });
  }

  async function reportPayment(txRef, transactionId, message) {
    return apiPostJson(API + '/payments/report_payment.php', {
      tx_ref: String(txRef || ''),
      transaction_id: String(transactionId || ''),
      message: String(message || '')
    });
  }

  async function openFlutterwaveCheckout(checkout) {
    await loadFlutterwaveScript();
    const cfg = Object.assign({}, checkout || {});
    return new Promise((resolve, reject) => {
      let closed = false;
      const timer = setTimeout(() => {
        // If user never completes, just keep UI responsive.
      }, 0);

      try {
        const pk = String(cfg.public_key || '').trim();
        if (!pk) throw new Error('Flutterwave public key is missing. Configure it in Admin > Donations & Monetization.');
        // Avoid Flutterwave throwing unclear errors like "There is no active transaction"
        // when keys are misconfigured.
        if (!/^FLWPUBK/i.test(pk)) {
          throw new Error('Flutterwave public key looks invalid. Please re-check your Flutterwave keys in admin settings.');
        }

        window.FlutterwaveCheckout({
          public_key: cfg.public_key,
          tx_ref: cfg.tx_ref,
          amount: cfg.amount,
          currency: cfg.currency,
          payment_options: cfg.payment_options || undefined,
          customer: cfg.customer || undefined,
          customizations: cfg.customizations || undefined,
          callback: function (data) {
            // data: { transaction_id, tx_ref, ... }
            if (closed) return;
            closed = true;
            clearTimeout(timer);
            resolve(data || {});
          },
          onclose: function () {
            if (closed) return;
            closed = true;
            clearTimeout(timer);
            const err = new Error('Payment closed');
            err.code = 'closed';
            reject(err);
          }
        });
      } catch (e) {
        clearTimeout(timer);
        reject(e);
      }
    });
  }

  // Expose minimal surface for pages.
  window.DeenlinkFlw = {
    ROOT,
    API,
    sleep,
    apiJson,
    apiPostJson,
    getCsrf,
    toast,
    formatMoney,
    quoteDeenpoints,
    quotePremium,
    getBalance,
    initDeenpoints,
    initDonation,
    initPremium,
    verify,
    reportPayment,
    openFlutterwaveCheckout
  };
})();
