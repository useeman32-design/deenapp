(function () {
  const STORAGE = {
    lastPrompt: 'dl_pwa_last_prompt_at',
    dismissedAt: 'dl_pwa_dismissed_at',
    installedAt: 'dl_pwa_installed_at'
  };
  const SHOW_AFTER_MS = 10 * 1000;
  const FLOATING_SHOW_AFTER_MS = 8 * 1000;
  const FLOATING_AUTO_HIDE_MS = 10 * 1000;
  const REMIND_AFTER_MS = 3 * 24 * 60 * 60 * 1000;
  let deferredPrompt = null;
  let readyToPrompt = false;
  let floatingTimer = null;
  let floatingHideTimer = null;
  let manualOnly = false;

  function now() {
    return Date.now();
  }

  function read(key) {
    try { return localStorage.getItem(key) || ''; } catch (_) { return ''; }
  }

  function write(key, value) {
    try { localStorage.setItem(key, String(value)); } catch (_) {}
  }

  function clearFloatingTimers() {
    if (floatingTimer) {
      window.clearTimeout(floatingTimer);
      floatingTimer = null;
    }
    if (floatingHideTimer) {
      window.clearTimeout(floatingHideTimer);
      floatingHideTimer = null;
    }
  }

  function isStandalone() {
    try {
      return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
    } catch (_) {
      return window.navigator.standalone === true;
    }
  }

  function isIosSafari() {
    const ua = navigator.userAgent || '';
    const isIOS = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    const isSafari = /Safari/i.test(ua) && !/CriOS|FxiOS|EdgiOS|OPiOS/i.test(ua);
    return isIOS && isSafari;
  }

  function canShowReminder() {
    const dismissedAt = Number(read(STORAGE.dismissedAt) || 0);
    if (!dismissedAt) return true;
    return (now() - dismissedAt) >= REMIND_AFTER_MS;
  }

  function canShowFloatingReminder() {
    return !isStandalone() && !!(deferredPrompt || isIosSafari());
  }

  function getEls() {
    return {
      modal: document.getElementById('pwaInstallModal'),
      card: document.getElementById('pwaInstallCard'),
      close: document.getElementById('pwaInstallClose'),
      primary: document.getElementById('pwaInstallPrimary'),
      secondary: document.getElementById('pwaInstallSecondary'),
      floating: document.getElementById('pwaFloatingInstall'),
      title: document.getElementById('pwaInstallTitle'),
      body: document.getElementById('pwaInstallBody'),
      hint: document.getElementById('pwaInstallHint'),
      steps: document.getElementById('pwaInstallSteps')
    };
  }

  function setMode(mode) {
    const els = getEls();
    if (!els.title) return;

    if (mode === 'android') {
      els.title.textContent = 'Install DeenLink';
      els.body.textContent = 'Keep DeenLink on your home screen for faster prayer tools, feed access, and a more app-like experience.';
      els.hint.innerHTML = '<i class="fas fa-download"></i><span>Android can show the real install prompt right here.</span>';
      els.primary.innerHTML = '<i class="fas fa-download"></i><span>Install App</span>';
      els.secondary.textContent = 'Maybe later';
      if (els.steps) els.steps.hidden = true;
      return;
    }

    els.title.textContent = 'Add DeenLink to Home Screen';
    els.body.textContent = 'On iPhone, Safari cannot install it for you automatically, but it only takes a few taps.';
    els.hint.innerHTML = '<i class="fas fa-arrow-up-from-bracket"></i><span>Use Safari: tap the Share icon, then choose "Add to Home Screen".</span>';
    els.primary.innerHTML = '<i class="fas fa-arrow-up-from-bracket"></i><span>Show Steps</span>';
    els.secondary.textContent = 'Not now';
    if (els.steps) els.steps.hidden = false;
  }

  function showModal(mode) {
    const els = getEls();
    if (!els.modal || isStandalone()) return;
    clearFloatingTimers();
    setMode(mode);
    els.modal.hidden = false;
    els.modal.classList.add('active');
    write(STORAGE.lastPrompt, now());
    toggleFloating(false);
  }

  function hideModal(markDismissed) {
    const els = getEls();
    if (!els.modal) return;
    els.modal.classList.remove('active');
    els.modal.hidden = true;
    if (markDismissed) write(STORAGE.dismissedAt, now());
    if (!isStandalone()) scheduleFloatingReminder();
  }

  function toggleFloating(visible) {
    const els = getEls();
    if (!els.floating) return;
    const shouldShow = !!visible && canShowFloatingReminder();
    els.floating.hidden = !shouldShow;
    els.floating.classList.toggle('active', shouldShow);
  }

  function scheduleFloatingReminder() {
    clearFloatingTimers();
    if (!canShowFloatingReminder()) return;
    floatingTimer = window.setTimeout(() => {
      toggleFloating(true);
      floatingHideTimer = window.setTimeout(() => {
        toggleFloating(false);
      }, FLOATING_AUTO_HIDE_MS);
    }, FLOATING_SHOW_AFTER_MS);
  }

  async function promptInstall() {
    if (!deferredPrompt) return false;
    deferredPrompt.prompt();
    const choice = await deferredPrompt.userChoice.catch(() => null);
    if (choice && choice.outcome === 'accepted') {
      write(STORAGE.installedAt, now());
      hideModal(false);
      toggleFloating(false);
      return true;
    }
    return false;
  }

  function registerServiceWorker() {
    if (window.DeenLinkAppUpdate && typeof window.DeenLinkAppUpdate.registerServiceWorker === 'function') {
      window.DeenLinkAppUpdate.registerServiceWorker().catch(() => {});
      return;
    }
    if (!('serviceWorker' in navigator)) return;
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    });
  }

  function bindUi() {
    const els = getEls();
    if (!els.modal) return;

    els.close?.addEventListener('click', () => hideModal(true));
    els.secondary?.addEventListener('click', () => hideModal(true));
    els.modal.addEventListener('click', (event) => {
      if (event.target === els.modal) hideModal(true);
    });
    els.primary?.addEventListener('click', async () => {
      if (deferredPrompt) {
        const installed = await promptInstall();
        if (!installed) hideModal(true);
        return;
      }
      const steps = els.steps;
      if (steps) {
        steps.hidden = false;
        steps.classList.add('active');
      }
    });
    els.floating?.addEventListener('click', () => {
      clearFloatingTimers();
      showModal(deferredPrompt ? 'android' : 'ios');
    });
  }

  function maybeShowPrompt() {
    if (isStandalone() || !readyToPrompt) return;
    if (!canShowReminder()) {
      scheduleFloatingReminder();
      return;
    }
    if (deferredPrompt) {
      showModal('android');
      return;
    }
    if (isIosSafari()) {
      showModal('ios');
    }
  }

  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    deferredPrompt = event;
    if (readyToPrompt) maybeShowPrompt();
  });

  window.addEventListener('appinstalled', () => {
    write(STORAGE.installedAt, now());
    hideModal(false);
    toggleFloating(false);
    deferredPrompt = null;
  });

  document.addEventListener('DOMContentLoaded', () => {
    manualOnly = document.body && document.body.dataset && document.body.dataset.pwaManualOnly === '1';
    registerServiceWorker();
    bindUi();
    toggleFloating(false);
    if (!manualOnly) {
      scheduleFloatingReminder();
      window.setTimeout(() => {
        readyToPrompt = true;
        maybeShowPrompt();
      }, SHOW_AFTER_MS);
    } else {
      readyToPrompt = true;
    }
  });

  window.DeenLinkPwaInstall = {
    open: () => showModal(deferredPrompt ? 'android' : 'ios')
  };
})();
