const API_BASE_URL = 'https://api.deenlink.org/api/v2';
const TOKEN_ENDPOINT = 'https://deenlink.org/api/auth/ai_token.php';
const AI_AVATAR_SRC = '../img/deenlink-ai.jpg';

const State = {
    activeConversationId: null,
    jwtToken: null,
    jwtExpiry: null,
    streamingActive: false,
    autoScroll: true,
    isUserScrolling: false,
    scrollTimeout: null,
    tokenQueue: [],
    rendering: false,
    streamController: null,
    lastUserPrompt: null,
    tokenFetchPromise: null,
    isLoadingConversation: false,
    sourcesShown: false,
    currentStreamingElement: null,
    editingMessageId: null,
    pendingFeedback: null,
    responseMode: 'auto',
    responseLang: 'en',
    userProfile: null,
    queryModule: null,
    modeLocked: false,
    modeLockedConversationId: null,
};

const Elements = {
    chatMessages: document.getElementById("chatMessages"),
    messageInput: document.getElementById("messageInput"),
    sendButton: document.getElementById("sendButton"),
    conversationList: document.getElementById("conversationList"),
    newChatBtn: document.getElementById("newChatBtn"),
    themeToggle: document.getElementById("themeToggle"),
    sidebar: document.getElementById("sidebar"),
    overlay: document.getElementById("sidebarOverlay"),
    menuToggle: document.getElementById("menuToggle"),
    errorToast: document.getElementById("error-toast"),
    quickPromptBtns: document.querySelectorAll(".quick-prompt-btn"),
    inputArea: document.querySelector(".input-area"),
    feedbackModal: document.getElementById("feedbackModal"),
    closeFeedbackModal: document.getElementById("closeFeedbackModal"),
    cancelFeedbackBtn: document.getElementById("cancelFeedbackBtn"),
    submitFeedbackBtn: document.getElementById("submitFeedbackBtn"),
    feedbackReasonInput: document.getElementById("feedbackReasonInput"),
    settingsBtn: document.getElementById("settingsBtn"),
    settingsModal: document.getElementById("settingsModal"),
    modeRadios: document.querySelectorAll("input[name='responseMode']"),
    scrollToBottomBtn: document.getElementById("scrollToBottomBtn"),
    micBtn: document.getElementById("micBtn"),
    modulesBtn: document.getElementById("modulesBtn"),
    modulesPopup: document.getElementById("modulesPopup")
};

const PurifyConfig = {
    ALLOWED_TAGS: [
        'p', 'br', 'strong', 'em', 'b', 'i', 'u',
        'div', 'span', 'blockquote',
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
        'ul', 'ol', 'li', 'a', 'code', 'pre'
    ],
    ALLOWED_ATTR: ['class', 'href', 'title', 'dir', 'target', 'rel'],
    FORBID_ATTR: ['onclick', 'onload', 'onerror'],
};

marked.setOptions({
    breaks: true,
    gfm: true,
    headerIds: false,
    mangle: false,
    sanitize: false,
    smartLists: true,
    smartypants: true,
    xhtml: false
});

const TAB_MODE_KEY = 'deen_active_mode';
const TAB_MODE_LOCK_KEY = 'deen_mode_lock';

function _readTabModeLock() {
    try {
        return JSON.parse(sessionStorage.getItem(TAB_MODE_LOCK_KEY) || 'null');
    } catch {
        return null;
    }
}

function _writeTabModeLock() {
    if (!State.queryModule || !State.modeLocked || !State.activeConversationId) return;
    sessionStorage.setItem(TAB_MODE_LOCK_KEY, JSON.stringify({
        module: State.queryModule,
        conversationId: State.activeConversationId
    }));
}

function _clearTabModeLock() {
    sessionStorage.removeItem(TAB_MODE_KEY);
    sessionStorage.removeItem(TAB_MODE_LOCK_KEY);
    State.modeLocked = false;
    State.modeLockedConversationId = null;
}

function createAiAvatarEl() {
    // Avatar removed per design request; return an empty transparent element
    const placeholder = document.createElement('span');
    placeholder.className = 'ai-avatar';
    placeholder.style.display = 'none';
    return placeholder;
}
async function getValidToken() {
    const now = Date.now();
    if (State.jwtToken && State.jwtExpiry && now < State.jwtExpiry - 60000) {
        return State.jwtToken;
    }
    if (State.tokenFetchPromise) return State.tokenFetchPromise;
    State.tokenFetchPromise = fetchToken();
    try {
        const token = await State.tokenFetchPromise;
        return token;
    } finally {
        State.tokenFetchPromise = null;
    }
}

async function fetchToken() {
    const now = Date.now();
    const csrfMeta = document.querySelector('meta[name="csrf-token"]') || document.querySelector('meta[name="csrf"]');
    let csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : (window.csrfToken || window.csrf_token || '');
    if (!csrfToken) {
        csrfToken = 'deenlink_ai_auto_csrf';
    }

    const formData = new FormData();
    formData.append('csrf_token', csrfToken);

    const res = await fetch(TOKEN_ENDPOINT, {
        method: "POST",
        credentials: "include",
        headers: {
            'X-CSRF-Token': csrfToken,
            'X-CSRF-TOKEN': csrfToken
        },
        body: formData
    });

    if (!res.ok) {
        console.error("Token server error", await res.text());
        throw new Error("Token fetch failed");
    }

    const contentType = res.headers.get("content-type");
    if (!contentType || !contentType.includes("application/json")) {
        console.error("Expected JSON but got:", await res.text());
        throw new Error("Invalid token response format");
    }

    const data = await res.json();
    State.jwtToken = data.ai_jwt || data.token;
    State.jwtExpiry = now + (5 * 60 * 1000);

    return State.jwtToken;
}

async function fetchUserProfile() {
    try {
        const token = await getValidToken();
        const res = await fetchWithRetry(`${API_BASE_URL}/user/me`, {
            headers: { "Authorization": `Bearer ${token}` }
        });
        if (!res.ok) return;

        const data = await res.json();

        const displayName = data.full_name || data.name || data.username || 'Guest';

        const userNameDisplay = document.getElementById("userNameDisplay");
        if (userNameDisplay) userNameDisplay.textContent = displayName;

        const settingsName = document.getElementById('settingsProfileName');
        if (settingsName) settingsName.textContent = displayName;

        const settingsSub = document.getElementById('settingsProfileSub');
        if (settingsSub) settingsSub.textContent = data.email || 'DeenLink Member';

        const rawAvatar = data.profile_image
            || data.avatar_url
            || data.profile_picture
            || data.photo
            || null;

        const avatarEl = document.getElementById('settingsProfileAvatar');
        if (avatarEl && rawAvatar) {
            let fullAvatarUrl;
            if (rawAvatar.startsWith('http://') || rawAvatar.startsWith('https://')) {
                fullAvatarUrl = rawAvatar;
            } else {
                const filename = rawAvatar.split('/').pop();
                fullAvatarUrl = `https://deenlink.org/uploads/profile/${filename}`;
            }

            const img = document.createElement('img');
            img.src = fullAvatarUrl;
            img.alt = displayName;
            img.style.cssText = 'width:100%;height:100%;border-radius:50%;object-fit:cover;';
            img.onerror = function () {
                avatarEl.innerHTML = '';
                const icon = document.createElement('i');
                icon.className = 'fas fa-user-circle';
                avatarEl.appendChild(icon);
            };
            avatarEl.innerHTML = '';
            avatarEl.appendChild(img);
        }

        State.userProfile = data;

    } catch (e) {
        console.warn("Could not fetch user profile", e);
    }
}

function showError(message, duration = 4000) {
    const toast = Elements.errorToast;
    toast.textContent = message;
    toast.classList.remove("hidden");
    setTimeout(() => {
        toast.classList.add("hidden");
    }, duration);
}

function showSuccessToast(message) {
    const toast = document.createElement('div');
    toast.className = 'success-toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.remove();
    }, 2000);
}

function showAINotificationToast(title, body) {
    const toast = document.createElement('div');
    toast.className = 'ai-status-toast';
    const cleanBody = String(body || '').replace(/[#*`]/g, '').trim();
    toast.innerHTML = `
        <div class="ai-status-toast-icon"><i class="fas fa-bell"></i></div>
        <div class="ai-status-toast-copy">
            <strong>${escapeHtml(title || 'DeenLink AI')}</strong>
            <span>${escapeHtml(cleanBody || 'Your answer is ready.')}</span>
        </div>
    `;
    document.body.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add('visible'));
    setTimeout(() => {
        toast.classList.remove('visible');
        setTimeout(() => toast.remove(), 220);
    }, 3600);
}

function getUserFriendlyError(rawMessage) {
    if (!rawMessage || typeof rawMessage !== 'string') {
        return "Something went wrong. Please try again.";
    }

    const msg = rawMessage.toLowerCase();

    if (msg.includes("collection") && (msg.includes("doesn't exist") || msg.includes("does not exist") || msg.includes("not found"))) {
        return "The knowledge base is temporarily unavailable. Please try again in a moment.";
    }

    if (/b'[\s\S]*'/.test(rawMessage) || /b"[\s\S]*"/.test(rawMessage)) {
        return "The server returned an unexpected response. Please try again.";
    }

    if (msg.includes("message not found") || msg.includes("message_not_found")) {
        return null;
    }

    if (msg.includes("404") || msg.includes("not found")) {
        return "The requested resource was not found. Please try a different question.";
    }
    if (msg.includes("401") || msg.includes("403") || msg.includes("unauthorized") || msg.includes("forbidden")) {
        return "Session expired. Please refresh the page and try again.";
    }
    if (msg.includes("500") || msg.includes("internal server")) {
        return "The server encountered an error. Please try again shortly.";
    }
    if (msg.includes("503") || msg.includes("unavailable")) {
        return "The service is temporarily unavailable. Please try again later.";
    }

    if (msg.includes("timeout") || msg.includes("timed out") || msg.includes("network") || msg.includes("failed to fetch")) {
        return "A network error occurred. Please check your connection and try again.";
    }

    if (msg.includes("abort") || msg.includes("aborted") || msg.includes("cancelled")) {
        return "Request was cancelled.";
    }

    const firstLine = rawMessage.split(/\n|Raw response/i)[0].trim();
    if (firstLine.length > 0 && firstLine.length <= 120) {
        return firstLine;
    }

    return "Something went wrong. Please try again.";
}

function updateSendButtonIcon(type = 'send') {
    const icon = type === 'stop' ? 'fa-stop' : 'fa-paper-plane';
    Elements.sendButton.innerHTML = `<i class="fas ${icon}"></i>`;
}

function createMessageActionButton(iconClass, label, action, extraClass = '') {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `message-action-btn ${extraClass}`.trim();
    btn.setAttribute('aria-label', label);
    btn.title = label;
    btn.dataset.action = action;
    btn.innerHTML = `<i class="fas ${iconClass}"></i>`;
    return btn;
}

function createUserMessageActions(messageEl, promptText, messageId = '') {
    const actions = document.createElement('div');
    actions.className = 'message-actions user-actions';

    const copyBtn = createMessageActionButton('fa-copy', 'Copy prompt', 'copy-prompt');
    const editBtn = createMessageActionButton('fa-pen', 'Edit prompt', 'edit-prompt');

    editBtn.dataset.prompt = promptText;
    copyBtn.dataset.prompt = promptText;

    if (messageId) {
        editBtn.dataset.messageId = messageId;
    }

    copyBtn.addEventListener('click', async () => {
        try {
            await navigator.clipboard.writeText(promptText);
            copyBtn.innerHTML = '<i class="fas fa-check"></i>';
            setTimeout(() => {
                copyBtn.innerHTML = '<i class="far fa-copy"></i>';
            }, 2000);
        } catch (err) {
            console.error('Failed to copy', err);
        }
    });

    actions.appendChild(copyBtn);
    actions.appendChild(editBtn);

    const contentDiv = messageEl.querySelector('.message-content');
    if (contentDiv) {
        contentDiv.appendChild(actions);
    } else {
        messageEl.appendChild(actions);
    }

    return actions;
}

function createErrorRetryAction(messageEl, promptText) {
    const actions = document.createElement('div');
    actions.className = 'message-actions ai-actions';
    const retryBtn = createMessageActionButton('fa-rotate-right', 'Retry response', 'retry-prompt', 'retry-error-btn');
    retryBtn.dataset.prompt = promptText;
    actions.appendChild(retryBtn);
    messageEl.appendChild(actions);
    return actions;
}

function isNearBottom(el, threshold = 200) {
    return el.scrollHeight - el.scrollTop - el.clientHeight < threshold;
}

function isHTMLContent(str) {
    if (!str || typeof str !== 'string') return false;
    const trimmed = str.trim();
    return trimmed.startsWith('<') && trimmed.includes('</');
}

function cleanMarkdownOutput(rawContent) {
    return rawContent
        .replace(/^[ \t]+(?=[^\s])/gm, '')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

function renderContent(element, rawContent) {
    const cleaned = rawContent
        .replace(/>\s+</g, '><')
        .replace(/\n\s*\n/g, '\n')
        .trim();

    let html;
    if (isHTMLContent(cleaned)) {
        html = DOMPurify.sanitize(cleaned, PurifyConfig);
    } else {
        try {
            const cleanedForMd = cleanMarkdownOutput(rawContent);
            html = DOMPurify.sanitize(marked.parse(cleanedForMd, { async: false }), PurifyConfig);
        } catch (e) {
            html = DOMPurify.sanitize(rawContent.replace(/\n/g, '<br>'), PurifyConfig);
        }
    }

    element.innerHTML = html;

    const paragraphs = element.querySelectorAll('p');
    paragraphs.forEach(p => {
        p.style.textIndent = '0';
        p.style.paddingLeft = '0';
        p.style.marginLeft = '0';
    });

    element.querySelectorAll('a').forEach(link => {
        if (link.hostname !== window.location.hostname) {
            link.setAttribute('target', '_blank');
            link.setAttribute('rel', 'noopener noreferrer');
        }
    });
}

async function streamTokenToElement(element, token) {
    if (!element) return;
    const chars = token.split('');
    for (let i = 0; i < chars.length; i++) {
        if (!State.streamingActive) break;
        element.textContent += chars[i];
        let delay = 8;
        if (chars[i] === '.' || chars[i] === '!' || chars[i] === '?') delay = 60;
        else if (chars[i] === ',' || chars[i] === ';') delay = 25;
        else if (chars[i] === ' ') delay = 4;
        await new Promise(resolve => setTimeout(resolve, delay));
        if (State.autoScroll && !State.isUserScrolling) {
            Elements.chatMessages.scrollTo({
                top: Elements.chatMessages.scrollHeight,
                behavior: 'auto'
            });
        }
    }
}

function showSearchIndicator(text = "Searching knowledge base...", iconType = "database") {
    removeSearchIndicator();
    removeTypingIndicator();
    const indicator = document.createElement('div');
    indicator.className = 'search-indicator';
    indicator.id = 'searchIndicator';

    let iconHtml = '<div class="search-spinner"></div>';
    if (iconType === "web") {
        iconHtml = '<i class="fas fa-globe search-spinner-icon" style="animation: spin 2s linear infinite; margin-right: 8px;"></i>';
    }

    indicator.innerHTML = `
        <div class="search-indicator-content">
            ${iconHtml}
            <span class="search-text">${text}</span>
        </div>
    `;
    Elements.chatMessages.appendChild(indicator);
    if (State.autoScroll) {
        Elements.chatMessages.scrollTo({
            top: Elements.chatMessages.scrollHeight,
            behavior: 'smooth'
        });
    }
    return indicator;
}

function showTypingIndicator() {
    removeSearchIndicator();
    removeTypingIndicator();
    const indicator = document.createElement('div');
    indicator.className = 'message ai typing-indicator-message';
    indicator.id = 'typingIndicator';
    indicator.innerHTML = `
        <div class="typing-dots">
            <div class="typing-dot-small"></div>
            <div class="typing-dot-small"></div>
            <div class="typing-dot-small"></div>
        </div>
    `;
    Elements.chatMessages.appendChild(indicator);
    if (State.autoScroll) {
        Elements.chatMessages.scrollTo({
            top: Elements.chatMessages.scrollHeight,
            behavior: 'smooth'
        });
    }
    return indicator;
}

function removeSearchIndicator() {
    const indicator = document.getElementById('searchIndicator');
    if (indicator) {
        if (indicator.dataset.intervalId) {
            clearInterval(parseInt(indicator.dataset.intervalId));
        }
        indicator.remove();
    }
}

function removeTypingIndicator() {
    const indicator = document.getElementById('typingIndicator');
    if (indicator) indicator.remove();
}

function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function filterBestSources(sources, rawContent) {
    if (!sources || sources.length === 0) return sources;
    // If rawContent contains inline citations like [1] keep all sources
    if (rawContent && /\[\d+\]/.test(rawContent)) {
        return sources.filter(s => s && s.payload);
    }
    // Otherwise, return the most relevant source (first with payload)
    const first = sources.find(s => s && s.payload);
    return first ? [first] : [];
}

function _sourcesKey(messageId) { return `deen_sources_${messageId}`; }

function persistSources(messageId, sources) {
    if (!messageId || !sources || !sources.length) return;
    try {
        localStorage.setItem(_sourcesKey(messageId), JSON.stringify(sources));
    } catch {}
}

function restoreSources(messageId) {
    try {
        const raw = localStorage.getItem(_sourcesKey(messageId));
        return raw ? JSON.parse(raw) : null;
    } catch { return null; }
}

function createSourcesPanel(sources) {
    const panel = document.createElement('div');
    panel.className = 'sources-panel';
    const validSources = sources.filter(s => s && s.payload);
    if (!validSources.length) return panel;

    const pillBtn = document.createElement('button');
    pillBtn.className = 'sources-pill-btn';

    const pillIcons = document.createElement('span');
    pillIcons.className = 'sources-pill-icons';
    validSources.slice(0, 3).forEach(src => {
        const wrap = document.createElement('span');
        wrap.className = 'sources-pill-icon';
        if (src.source_type === 'web' && src.payload?.url) {
            let h = '';
            try { h = new URL(src.payload.url).hostname; } catch {}
            const img = document.createElement('img');
            img.src = `https://www.google.com/s2/favicons?domain=${h}&sz=32`;
            img.alt = '';
            img.onerror = function () {
                const i = document.createElement('i');
                i.className = 'fas fa-globe';
                this.parentElement.replaceChildren(i);
            };
            wrap.appendChild(img);
        } else {
            const i = document.createElement('i');
            i.className = src.source_type === 'hadith' ? 'fas fa-book' : 'fas fa-quran';
            wrap.appendChild(i);
        }
        pillIcons.appendChild(wrap);
    });

    const pillLabel = document.createElement('span');
    pillLabel.textContent = `${validSources.length} source${validSources.length > 1 ? 's' : ''}`;

    const chevron = document.createElement('i');
    chevron.className = 'fas fa-chevron-down';
    chevron.style.cssText = 'font-size:10px;margin-left:4px;opacity:0.6;';

    pillBtn.appendChild(pillIcons);
    pillBtn.appendChild(pillLabel);
    pillBtn.appendChild(chevron);

    const expandedList = document.createElement('div');
    expandedList.className = 'sources-expanded-list';

    validSources.forEach(src => {
        const payload = src.payload || {};
        const isHadith = src.source_type === 'hadith';
        const isWeb = src.source_type === 'web';

        let title = '', meta = '', preview = '', hostname = '';

        if (isWeb) {
            try { hostname = new URL(payload.url || '').hostname.replace('www.', ''); } catch {}
            title   = payload.title || hostname || 'Web Source';
            meta    = hostname;
            preview = payload.snippet || '';
        } else if (src.display_reference) {
            title   = src.display_reference;
            preview = payload.english || '';
        } else if (isHadith) {
            title   = `${payload.collection || 'Hadith'} ${payload.hadith_number_display || ''}`.trim();
            meta    = payload.collection || '';
            preview = payload.english || '';
        } else {
            title   = (payload.surah_name && payload.ayah) ? `${payload.surah_name} — Ayah ${payload.ayah}` : "Qur'an";
            meta    = payload.surah_name || '';
            preview = payload.english || '';
        }

        const item = (isWeb && payload.url) ? document.createElement('a') : document.createElement('div');
        item.className = 'source-list-item';
        if (isWeb && payload.url) { item.href = payload.url; item.target = '_blank'; item.rel = 'noopener noreferrer'; }

        const iconBox = document.createElement('div');
        iconBox.className = 'source-list-icon';
        if (isWeb) {
            const img = document.createElement('img');
            img.src = `https://www.google.com/s2/favicons?domain=${hostname}&sz=32`;
            img.alt = '';
            img.onerror = function () {
                const i = document.createElement('i'); i.className = 'fas fa-globe';
                this.parentElement.replaceChildren(i);
            };
            iconBox.appendChild(img);
        } else {
            const i = document.createElement('i');
            i.className = isHadith ? 'fas fa-book' : 'fas fa-quran';
            iconBox.appendChild(i);
        }

        const body = document.createElement('div');
        body.className = 'source-list-body';

        const titleEl = document.createElement('div');
        titleEl.className = 'source-list-title';
        titleEl.textContent = title;
        body.appendChild(titleEl);

        if (meta) {
            const metaEl = document.createElement('div');
            metaEl.className = 'source-list-meta';
            metaEl.textContent = meta;
            body.appendChild(metaEl);
        }

        if (payload.arabic && !isWeb) {
            const ar = document.createElement('div');
            ar.className = 'rag-arabic';
            ar.dir = 'rtl';
            ar.style.cssText = 'font-size:13px;margin-top:6px;white-space:normal;word-break:break-word;line-height:1.9;';
            ar.textContent = payload.arabic;
            body.appendChild(ar);
        }

        if (preview) {
            const prev = document.createElement('div');
            prev.className = 'source-list-preview';
            prev.textContent = preview;
            body.appendChild(prev);
        }

        item.appendChild(iconBox);
        item.appendChild(body);
        expandedList.appendChild(item);
    });

    pillBtn.addEventListener('click', () => {
        const open = expandedList.classList.toggle('visible');
        chevron.className = open ? 'fas fa-chevron-up' : 'fas fa-chevron-down';
        chevron.style.cssText = 'font-size:10px;margin-left:4px;opacity:0.6;';
    });

    panel.appendChild(pillBtn);
    panel.appendChild(expandedList);
    return panel;
}

function createStreamingMessage() {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message ai streaming';
    messageDiv.dataset.messageId = Date.now().toString(36) + Math.random().toString(36).substr(2);

    messageDiv.appendChild(createAiAvatarEl());

    messageDiv.innerHTML += `
        <div class="message-content">
            <div class="message-text"></div>
            <div class="message-feedback" style="display: none;">
                <button class="feedback-btn like-btn" title="Helpful response">
                    <i class="far fa-thumbs-up"></i>
                    <span>Helpful</span>
                </button>
                <button class="feedback-btn dislike-btn" title="Not helpful">
                    <i class="far fa-thumbs-down"></i>
                    <span>Not helpful</span>
                </button>
                <button class="feedback-btn copy-btn" title="Copy response">
                    <i class="far fa-copy"></i>
                    <span>Copy</span>
                </button>
            </div>
        </div>
    `;
    Elements.chatMessages.appendChild(messageDiv);
    if (State.autoScroll) {
        Elements.chatMessages.scrollTo({
            top: Elements.chatMessages.scrollHeight,
            behavior: 'smooth'
        });
    }
    return {
        container: messageDiv,
        textEl: messageDiv.querySelector('.message-text'),
        feedbackDiv: messageDiv.querySelector('.message-feedback')
    };
}

function finalizeStreamingMessage(messageObj, rawContent, sources = null) {
    const { container, textEl } = messageObj;
    let feedbackDiv = messageObj.feedbackDiv || container.querySelector('.message-feedback');

    container.classList.remove('streaming', 'loading');
    const streamingText = textEl.querySelector('.streaming-text');
    if (streamingText) {
        streamingText.remove();
    }

    const indicator = container.querySelector('.typing-indicator');
    if (indicator) indicator.remove();

    renderContent(textEl, rawContent);
    textEl.classList.add('message-text');
    void textEl.offsetHeight;

    if (textEl.querySelector('.rag-source')) {
        styleRAGSources(textEl);
    }

    const contentDiv = container.querySelector('.message-content');

    if (sources && sources.length > 0) {
        const validSources = filterBestSources(sources);
        const existingPanel = container.querySelector('.sources-panel');
        if (existingPanel) existingPanel.remove();
        const sourcesPanel = createSourcesPanel(validSources);
        contentDiv.appendChild(sourcesPanel);
        const msgId = container.dataset.messageId || container.dataset.aiMessageId;
        if (msgId) persistSources(msgId, validSources);
    }

    if (feedbackDiv) {
        feedbackDiv.style.display = 'flex';
        setupFeedbackButtons(feedbackDiv, textEl, container.dataset.prompt);
    } else {
        feedbackDiv = createFeedbackButtons(contentDiv);
        feedbackDiv.style.display = 'flex';
        contentDiv.appendChild(feedbackDiv);
    }

    _notifyAIDone(textEl?.innerText || '');

    setTimeout(() => {
        const scrollable = Elements.chatMessages.closest('.messages-area') || Elements.chatMessages.parentElement;
        const target = scrollable || Elements.chatMessages;
        const distFromBottom = target.scrollHeight - target.scrollTop - target.clientHeight;

        if (distFromBottom <= 80) {
            target.scrollTo({ top: target.scrollHeight, behavior: 'smooth' });
        } else {
            container.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 80);
}

function setupFeedbackButtons(feedbackDiv, textEl, prompt) {
    const likeBtn = feedbackDiv.querySelector('.like-btn');
    const dislikeBtn = feedbackDiv.querySelector('.dislike-btn');
    const copyBtn = feedbackDiv.querySelector('.copy-btn');

    likeBtn.addEventListener('click', async () => {
        const response = textEl?.innerText || '';
        likeBtn.classList.add('active');
        likeBtn.innerHTML = '<i class="fas fa-thumbs-up"></i><span>Helpful</span>';
        dislikeBtn.disabled = true;
        await sendFeedback('like', prompt, response);
        showSuccessToast('Thanks for your feedback!');
    });

    dislikeBtn.addEventListener('click', async () => {
        const response = textEl?.innerText || '';
        dislikeBtn.classList.add('active');
        dislikeBtn.innerHTML = '<i class="fas fa-thumbs-down"></i><span>Not helpful</span>';
        likeBtn.disabled = true;
        await sendFeedback('dislike', prompt, response);
        showSuccessToast('Thanks for your feedback!');
    });

    copyBtn.addEventListener('click', async () => {
        const text = textEl?.innerText || '';
        try {
            await navigator.clipboard.writeText(text);
            copyBtn.innerHTML = '<i class="fas fa-check"></i><span>Copied!</span>';
            setTimeout(() => {
                copyBtn.innerHTML = '<i class="far fa-copy"></i><span>Copy</span>';
            }, 2000);
        } catch (err) {
            showError('Failed to copy');
        }
    });
}

function createMessageElement(sender, text = "", incomplete = false, prompt = null, messageId = null) {
    const el = document.createElement("div");
    el.className = `message ${sender}`;
    if (incomplete) el.classList.add('error');
    if (prompt) el.dataset.prompt = prompt;
    el.dataset.incomplete = incomplete ? "true" : "false";
    el.dataset.raw = text || "";
    el.dataset.messageId = messageId || Date.now().toString(36) + Math.random().toString(36).substr(2);

    if (sender === 'ai') {
        el.appendChild(createAiAvatarEl());
    }

    const contentDiv = document.createElement("div");
    contentDiv.className = "message-content";

    const textDiv = document.createElement("div");
    textDiv.className = "message-text";

    if (sender === "user") {
        textDiv.textContent = text;
    } else {
        if (isHTMLContent(text)) {
            textDiv.innerHTML = DOMPurify.sanitize(text, PurifyConfig);
            setTimeout(() => styleRAGSources(textDiv), 10);
        } else {
            const cleanedText = cleanMarkdownOutput(text);
            textDiv.innerHTML = DOMPurify.sanitize(marked.parse(cleanedText, { async: false }), PurifyConfig);
        }
    }

    contentDiv.appendChild(textDiv);
    if (sender === "ai" && !incomplete) {
        const feedbackButtons = createFeedbackButtons(contentDiv);
        contentDiv.appendChild(feedbackButtons);
    }

    el.appendChild(contentDiv);
    if (sender === "user") {
        createUserMessageActions(el, text || prompt || "", el.dataset.messageId);
    } else if (sender === "ai" && incomplete) {
        createErrorRetryAction(el, prompt || "");
    }
    Elements.chatMessages.appendChild(el);

    if (State.autoScroll) {
        requestAnimationFrame(() => {
            Elements.chatMessages.scrollTop = Elements.chatMessages.scrollHeight;
        });
    }
    return textDiv;
}

function appendLoadingMessage() {
    const el = document.createElement("div");
    el.className = "message ai loading";

    el.appendChild(createAiAvatarEl());

    const contentDiv = document.createElement("div");
    contentDiv.className = "message-content";
    contentDiv.innerHTML = `
        <div class="message-text"></div>
        <div class="typing-indicator">
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
        </div>
    `;
    el.appendChild(contentDiv);

    Elements.chatMessages.appendChild(el);
    requestAnimationFrame(() => {
        Elements.chatMessages.scrollTop = Elements.chatMessages.scrollHeight;
    });
    return {
        container: el,
        textEl: el.querySelector(".message-text"),
        remove: () => el.remove()
    };
}

function replaceLoadingWithAIMessage(loadingObj, incomplete = false) {
    const { container } = loadingObj;
    container.classList.remove("loading");
    const indicator = container.querySelector(".typing-indicator");
    if (indicator) indicator.remove();
    if (incomplete) {
        container.dataset.incomplete = "true";
        const retry = document.createElement("span");
        retry.className = "retry-icon";
        retry.title = "Retry";
        retry.innerHTML = "&#x21bb;";
        retry.onclick = () => retryMessage(container.dataset.prompt);
        container.querySelector(".message-content").appendChild(retry);
    }
    const contentDiv = container.querySelector(".message-content");
    const textEl = container.querySelector(".message-text");
    if (contentDiv && !contentDiv.querySelector('.message-feedback')) {
        const feedbackButtons = createFeedbackButtons(contentDiv);
        contentDiv.appendChild(feedbackButtons);
    }
    return textEl;
}

function updateEmptyStateVisibility() {
    const emptyGreeting = document.getElementById("emptyChatGreeting");
    const quickPrompts = document.getElementById("quickPrompts");

    const hasMessages = Array.from(Elements.chatMessages.children).some(
        child => !child.classList.contains("loading-state") && !child.id.includes("Indicator")
    );

    if (hasMessages) {
        if (emptyGreeting) emptyGreeting.style.display = 'none';
        if (quickPrompts) quickPrompts.style.display = 'none';
    } else {
        if (emptyGreeting) emptyGreeting.style.display = 'flex';
        if (quickPrompts) quickPrompts.style.display = 'flex';
    }
}

function appendMessage(sender, text, options = {}) {
    const { messageId = null, sources = null } = options;
    const shouldScroll = isNearBottom(Elements.chatMessages);
    const el = document.createElement("div");
    el.className = `message ${sender}`;
    const mid = messageId || Date.now().toString(36) + Math.random().toString(36).substr(2);
    el.dataset.messageId = mid;

    if (sender === 'ai') el.appendChild(createAiAvatarEl());

    const contentDiv = document.createElement("div");
    contentDiv.className = "message-content";
    const textDiv = document.createElement("div");
    textDiv.className = "message-text";
    textDiv.dataset.raw = text;

    if (sender === 'user') {
        textDiv.textContent = text;
    } else {
        renderContent(textDiv, text);
        void textDiv.offsetHeight;
        setTimeout(() => { styleRAGSources(textDiv); }, 10);
    }

    contentDiv.appendChild(textDiv);

    if (sender === 'ai') {
        const savedSources = sources || restoreSources(mid);
        if (savedSources && savedSources.length > 0) {
            contentDiv.appendChild(createSourcesPanel(savedSources));
        }
        contentDiv.appendChild(createFeedbackButtons(contentDiv));
    }
    el.appendChild(contentDiv);
    if (sender === 'user') createUserMessageActions(el, text, mid);

    Elements.chatMessages.appendChild(el);
    if (shouldScroll) Elements.chatMessages.scrollTop = Elements.chatMessages.scrollHeight;
    updateEmptyStateVisibility();
}

function createFeedbackButtons(messageContent) {
    const feedbackDiv = document.createElement('div');
    feedbackDiv.className = 'message-feedback';
    feedbackDiv.innerHTML = `
        <button class="feedback-btn like-btn" title="Helpful response">
            <i class="far fa-thumbs-up"></i>
            <span>Helpful</span>
        </button>
        <button class="feedback-btn dislike-btn" title="Not helpful">
            <i class="far fa-thumbs-down"></i>
            <span>Not helpful</span>
        </button>
        <button class="feedback-btn copy-btn" title="Copy response">
            <i class="far fa-copy"></i>
            <span>Copy</span>
        </button>
    `;
    const likeBtn = feedbackDiv.querySelector('.like-btn');
    const dislikeBtn = feedbackDiv.querySelector('.dislike-btn');
    const copyBtn = feedbackDiv.querySelector('.copy-btn');
    const textEl = messageContent.querySelector('.message-text');

    likeBtn.addEventListener('click', async () => {
        const msgContainer = messageContent.closest('.message');
        const prompt = msgContainer?.dataset.prompt || msgContainer?.previousElementSibling?.querySelector('.message-text')?.innerText || '';
        const response = textEl?.innerText || '';
        likeBtn.classList.add('active');
        likeBtn.innerHTML = '<i class="fas fa-thumbs-up"></i><span>Helpful</span>';
        dislikeBtn.disabled = true;
        await sendFeedback('like', prompt, response);
        showSuccessToast('Thanks for your feedback!');
    });

    dislikeBtn.addEventListener('click', async () => {
        const msgContainer = messageContent.closest('.message');
        const promptStr = msgContainer?.dataset.prompt || msgContainer?.previousElementSibling?.querySelector('.message-text')?.innerText || '';
        const response = textEl?.innerText || '';

        State.pendingFeedback = { prompt: promptStr, response: response, dislikeBtn: dislikeBtn, likeBtn: likeBtn };

        if (Elements.feedbackReasonInput) Elements.feedbackReasonInput.value = '';
        if (Elements.feedbackModal) Elements.feedbackModal.classList.remove('hidden');
    });

    copyBtn.addEventListener('click', async () => {
        const text = textEl?.innerText || '';
        try {
            await navigator.clipboard.writeText(text);
            copyBtn.innerHTML = '<i class="fas fa-check"></i><span>Copied!</span>';
            setTimeout(() => {
                copyBtn.innerHTML = '<i class="far fa-copy"></i><span>Copy</span>';
            }, 2000);
        } catch (err) {
            showError('Failed to copy');
        }
    });
    return feedbackDiv;
}

async function sendFeedback(type, prompt, response, reason = null) {
    try {
        const token = await getValidToken();
        const feedbackData = {
            type,
            prompt,
            response,
            reason,
            conversationId: State.activeConversationId,
            timestamp: new Date().toISOString(),
            url: window.location.href
        };
        const res = await fetch(`${API_BASE_URL}/feedback`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(feedbackData)
        });
        if (!res.ok) throw new Error('Failed to submit feedback');
        console.log('Feedback sent successfully');
    } catch (err) {
        console.error('Failed to send feedback:', err);
    }
}

function stopGeneration() {
    if (State.streamController) {
        State.streamController.abort();
    }
    State.streamingActive = false;
    State.streamController = null;
    State.rendering = false;
    State.tokenQueue = [];
    const loadingEl = document.querySelector('.message.ai.loading');
    if (loadingEl) loadingEl.remove();
    const searchIndicator = document.getElementById('searchIndicator');
    if (searchIndicator) searchIndicator.remove();
    updateSendButtonIcon('send');
    Elements.messageInput.disabled = false;
    Elements.sendButton.disabled = false;
    showError("Generation stopped");
}

async function fetchWithRetry(url, options, maxRetries = 3) {
    let lastError;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 30000);
            const res = await fetch(url, {
                ...options,
                signal: controller.signal,
            });
            clearTimeout(timeoutId);
            return res;
        } catch (error) {
            lastError = error;
            if (attempt === maxRetries) break;
            await new Promise(r => setTimeout(r, 1000 * attempt));
        }
    }
    throw lastError;
}

async function loadConversations() {
    try {
        const token = await getValidToken();
        const res = await fetchWithRetry(`${API_BASE_URL}/conversations`, {
            headers: { "Authorization": `Bearer ${token}` }
        });
        if (!res.ok) {
            if (res.status === 401 || res.status === 403) {
                State.jwtToken = null;
                State.jwtExpiry = null;
                throw new Error("Session expired");
            }
            throw new Error("Failed to load conversations");
        }
        const data = await res.json();
        if (!Array.isArray(data)) throw new Error("Invalid data format");
        renderConversationTabs(data);
    } catch (err) {
        showError(err.message || "Failed to load conversations");
    }
}

function renderConversationTabs(conversations) {
    if (!Array.isArray(conversations)) {
        showError("Invalid conversations data");
        return;
    }
    Elements.conversationList.innerHTML = "";
    conversations.forEach(conv => {
        const card = document.createElement("div");
        card.className = "conversation-card";
        if (conv.id === State.activeConversationId) card.classList.add("active");
        card.dataset.id = conv.id;
        const titleSpan = document.createElement("span");
        titleSpan.className = "conversation-title";
        titleSpan.textContent = conv.title || "New Chat";
        card.appendChild(titleSpan);
        card.onclick = async () => {
            if (State.isLoadingConversation) return;
            await switchToConversation(conv.id);
        };
        const deleteBtn = document.createElement("button");
        deleteBtn.className = "delete-btn";
        deleteBtn.setAttribute("aria-label", "Delete conversation");
        deleteBtn.innerHTML = '<i class="fas fa-trash-alt"></i>';
        deleteBtn.onclick = async (e) => {
            e.stopPropagation();
            if (!confirm("Delete this conversation?")) return;
            try {
                await deleteConversation(conv.id);
            } catch (err) {
                showError("Failed to delete conversation");
            }
        };
        card.appendChild(deleteBtn);
        Elements.conversationList.appendChild(card);
    });
}

async function switchToConversation(id) {
    if (State.isLoadingConversation || id === State.activeConversationId) return;
    State.isLoadingConversation = true;
    closeSidebar();
    Elements.chatMessages.innerHTML = '<div class="loading-state">Loading...</div>';
    try {
        await loadConversation(id);
        State.activeConversationId = id;
        _syncModeLockForConversation(id);
        reapplyWallpaperPalette();
        document.querySelectorAll('.conversation-card').forEach(card => {
            card.classList.toggle('active', card.dataset.id === id);
        });
    } catch (err) {
        showError("Failed to load conversation");
        Elements.chatMessages.innerHTML = '';
    } finally {
        State.isLoadingConversation = false;
    }
}

async function loadConversation(id) {
    const token = await getValidToken();
    const res = await fetchWithRetry(`${API_BASE_URL}/conversations/${id}`, {
        headers: { "Authorization": `Bearer ${token}` }
    });
    if (!res.ok) throw new Error("Conversation not found");
    const data = await res.json();
    Elements.chatMessages.innerHTML = "";
    if (!data.messages || !Array.isArray(data.messages)) {
        throw new Error("Invalid conversation data");
    }
    data.messages.forEach(msg => {
        appendMessage(
            msg.role === "user" ? "user" : "ai",
            msg.content,
            { messageId: msg.id || null, sources: msg.sources || null }
        );
    });

    updateEmptyStateVisibility();

    const scrollToBottom = () => {
        const messagesArea = Elements.chatMessages.closest('.messages-area') || Elements.chatMessages.parentElement;
        const target = messagesArea || Elements.chatMessages;
        target.scrollTop = target.scrollHeight;
        Elements.chatMessages.scrollTop = Elements.chatMessages.scrollHeight;
    };

    scrollToBottom();
    requestAnimationFrame(() => {
        scrollToBottom();
        setTimeout(scrollToBottom, 100);
        setTimeout(scrollToBottom, 300);
    });
}

async function editConversationFromMessage(conversationId, messageId, editedText) {
    const token = await getValidToken();
    const res = await fetchWithRetry(`${API_BASE_URL}/conversations/${conversationId}/edit`, {
        method: "POST",
        headers: {
            "Authorization": `Bearer ${token}`,
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            message_id: messageId,
            message: editedText
        })
    });
    if (!res.ok) {
        let detail = "Failed to edit conversation";
        try {
            const errorData = await res.json();
            detail = errorData?.detail || detail;
        } catch (_) {}
        throw new Error(detail);
    }
    return res.json();
}

async function deleteConversation(conversationId) {
    const token = await getValidToken();
    const res = await fetchWithRetry(
        `${API_BASE_URL}/conversations/${conversationId}`,
        {
            method: "DELETE",
            headers: { "Authorization": `Bearer ${token}` },
        }
    );
    if (!res.ok) throw new Error("Delete failed");
    if (conversationId === State.activeConversationId) {
        State.activeConversationId = null;
        Elements.chatMessages.innerHTML = '';
    }
    await loadConversations();
}

async function createNewConversation() {
    const token = await getValidToken();
    const res = await fetchWithRetry(`${API_BASE_URL}/conversations/new`, {
        method: "POST",
        headers: {
            "Authorization": `Bearer ${token}`,
            "Content-Type": "application/json"
        }
    });
    if (!res.ok) throw new Error("Failed to create conversation");
    const jsonRes = await res.json();
    updateEmptyStateVisibility();
    return jsonRes;
}

function styleRAGSources(el) {
    if (!el) return;
    const sources = el.querySelectorAll('.rag-source');
    const totalSources = sources.length;

    sources.forEach((source, index) => {
        if (totalSources > 1) {
            let badge = source.querySelector('.source-badge');
            if (!badge) {
                badge = document.createElement('div');
                badge.className = 'source-badge';
                source.insertBefore(badge, source.firstChild);
            }
            badge.textContent = `${index + 1}/${totalSources}`;
        }
        source.style.cssText = '';
    });
}

function showRAGLoadingIndicator(el) {
    const existing = el.querySelector('.rag-loading-indicator');
    if (existing) return;
    const indicator = document.createElement('div');
    indicator.className = 'rag-loading-indicator';
    indicator.innerHTML = `
        <div class="spinner"></div>
        <span>Retrieving Islamic sources...</span>
    `;
    el.innerHTML = '';
    el.appendChild(indicator);
}

async function sendMessage(retryData = null) {
    if (State.streamingActive) {
        showError("Already processing a message");
        return;
    }

    State.streamingActive = true;
    updateSendButtonIcon('stop');
    Elements.messageInput.disabled = true;

    let text = "";
    let isCallbackResend = false;
    if (typeof retryData === 'string') {
        text = retryData;
    } else {
        text = retryData?.message ?? Elements.messageInput.value.trim();
        isCallbackResend = retryData?.isCallbackResend || false;
    }
    if (!text) {
        resetInputState();
        return;
    }
    const editingMessageId = retryData?.editMessageId || State.editingMessageId;

    if (!retryData) State.lastUserPrompt = text;

    if (!State.activeConversationId) {
        try {
            const newConv = await createNewConversation();
            State.activeConversationId = newConv.id;
        } catch (err) {
            resetInputState();
            showError("Failed to create conversation");
            return;
        }
    }

    if (State.queryModule && (!State.modeLocked || State.modeLockedConversationId !== State.activeConversationId)) {
        State.modeLocked = true;
        State.modeLockedConversationId = State.activeConversationId;
        _writeTabModeLock();
        _renderActiveModuleChip();
    }

    if (!retryData) {
        Elements.messageInput.value = "";
        Elements.messageInput.style.height = "auto";
    }

    if (editingMessageId && State.activeConversationId) {
        try {
            await editConversationFromMessage(State.activeConversationId, editingMessageId, text);
        } catch (err) {
            const friendlyErr = getUserFriendlyError(err?.message);
            if (friendlyErr !== null) {
                State.editingMessageId = null;
                resetInputState();
                showError(friendlyErr || "Failed to edit message");
                return;
            }
            console.warn('Edit: message not found, sending as new message');
        }
        State.editingMessageId = null;
    }

    // Avoid duplicate user message when this is a callback resend (e.g., after intent/modal selection)
    if (!isCallbackResend) {
        // Ensure we don't add the same user message twice
        const lastMsg = Elements.chatMessages.lastElementChild;
        if (!lastMsg?.dataset?.sender || lastMsg.dataset.sender !== 'user' || lastMsg.textContent.trim() !== text.trim()) {
            appendMessage('user', text);
        }
    }
    const streamingMsg = appendLoadingMessage();
    streamingMsg.container.dataset.prompt = text;
    streamingMsg.container.style.display = 'none';

    let collectedSources = null;
    let fullContent = '';
    let aiMessageEl = streamingMsg.textEl;
    let isHTML = false;
    let hasDetectedType = false;
    let hasReceivedContent = false;

    try {
        const token = await getValidToken();
        State.streamController = new AbortController();

        const res = await fetch(`${API_BASE_URL}/ask/stream`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            },
            body: JSON.stringify({
                message: State.queryModule && MODULE_CONFIG[State.queryModule]?.prefix
                    ? MODULE_CONFIG[State.queryModule].prefix + text
                    : text,
                conversation_id: State.activeConversationId,
                mode: State.queryModule === 'chat' ? 'chat'
                    : State.queryModule === 'books' ? 'rag'
                    : State.responseMode,
                response_language: State.responseLang || localStorage.getItem('deenLang') || 'en',
                client_datetime: new Date().toLocaleString('en-GB', {
                    weekday:'long', year:'numeric', month:'long',
                    day:'numeric', hour:'2-digit', minute:'2-digit', second:'2-digit', hour12: true
                }),
                client_timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || ""
            }),
            signal: State.streamController.signal
        });

        if (!res.ok || !res.body) {
            throw new Error(`Request failed: ${res.status}`);
        }

        const reader = res.body.getReader();
        const decoder = new TextDecoder("utf-8");
        let buffer = "";

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const parts = buffer.split("\n\n");
            buffer = parts.pop();

            for (const part of parts) {
                const trimmed = part.trim();
                if (!trimmed.startsWith("data:")) continue;

                const dataStr = trimmed.replace(/^data:\s*/, "");
                let data;
                try {
                    data = JSON.parse(dataStr);
                } catch {
                    continue;
                }

                switch (data.type) {
                    case 'intent_selection':
                        removeSearchIndicator();
                        removeTypingIndicator();

                        const bubbleTypingIndicator = streamingMsg.container.querySelector('.typing-indicator');
                        if (bubbleTypingIndicator) {
                            bubbleTypingIndicator.remove();
                        }

                        const selectionContainer = document.createElement('div');
                        selectionContainer.className = 'intent-selection-container';
                        selectionContainer.style.cssText = 'display:flex;flex-direction:column;gap:12px;margin:12px 0;width:100%;';

                        const promptText = document.createElement('p');
                        promptText.textContent = 'Please choose a category to receive the response from:';
                        promptText.style.cssText = 'margin:0;font-weight:600;font-size:14px;color:var(--text-dark);';
                        selectionContainer.appendChild(promptText);

                        const choiceRow = document.createElement('div');
                        choiceRow.className = 'intent-select-row';
                        choiceRow.style.cssText = 'display:flex;gap:8px;width:100%;align-items:center;';

                        const intentSelect = document.createElement('select');
                        intentSelect.className = 'intent-select';
                        intentSelect.style.cssText = 'flex:1;min-width:0;padding:12px 14px;border-radius:12px;border:1px solid var(--glass-border);background:var(--glass-bg);color:var(--text-dark);font:inherit;';

                        data.options.forEach(opt => {
                            const option = document.createElement('option');
                            option.value = opt.id;
                            option.textContent = opt.label;
                            intentSelect.appendChild(option);
                        });

                        const confirmIntentBtn = document.createElement('button');
                        confirmIntentBtn.type = 'button';
                        confirmIntentBtn.className = 'intent-confirm-btn';
                        confirmIntentBtn.style.cssText = 'height:44px;padding:0 14px;border-radius:12px;border:0;background:var(--primary-green);color:#fff;font-weight:700;cursor:pointer;';
                        confirmIntentBtn.textContent = 'Use mode';

                        confirmIntentBtn.addEventListener('click', () => {
                            const promptTextVal = streamingMsg.container.dataset.prompt;
                            _applyModule(intentSelect.value, { lock: true });
                            streamingMsg.container.remove();
                            sendMessage({
                                message: promptTextVal,
                                isCallbackResend: true
                            });
                        });

                        choiceRow.appendChild(intentSelect);
                        choiceRow.appendChild(confirmIntentBtn);
                        selectionContainer.appendChild(choiceRow);

                        streamingMsg.container.style.display = 'flex';
                        aiMessageEl.innerHTML = '';
                        aiMessageEl.appendChild(selectionContainer);
                        _notifyAIStatus(
                            'DeenLink AI needs your choice',
                            'Choose a response mode so I can continue.'
                        );

                        completed = true;
                        return;

                    case 'search_start':
                        showSearchIndicator();
                        break;

                    case 'web_search_start':
                        showSearchIndicator("Getting info from the internet...", "web");
                        break;

                    case 'chat_start':
                        showTypingIndicator();
                        break;

                    case 'sources':
                        collectedSources = data.sources;
                        break;

                    case 'token':
                        if (!hasDetectedType) {
                            hasDetectedType = true;
                            removeSearchIndicator();
                            removeTypingIndicator();
                            streamingMsg.container.style.display = 'flex';

                            if (data.content.trim().startsWith('<')) {
                                isHTML = true;
                            }
                        }

                        const content = data.content;
                        hasReceivedContent = true;

                        if (isHTML) {
                            fullContent += content;
                            aiMessageEl.innerHTML = DOMPurify.sanitize(fullContent, PurifyConfig);
                            styleRAGSources(aiMessageEl);
                        } else {
                            fullContent += content;
                            await streamTokenWithTypingEffect(aiMessageEl, content);
                        }
                        break;

                    case 'error':
                        throw new Error(getUserFriendlyError(data.message || "Stream error"));

                    case 'done':
                        break;

                    case 'memory_updated':
                        if (data.action === "add" || data.action === "update") {
                            showMemoryUpdatedInline(data.fact);
                        }
                        break;
                }
            }
        }

        let rawFinalContent = fullContent;
        if (!rawFinalContent || !hasReceivedContent) {
            rawFinalContent = "I'm sorry, I couldn't generate a response. Please try again.";
        }

        finalizeStreamingMessage(streamingMsg, rawFinalContent, collectedSources);
        await loadConversations();

    } catch (err) {
        removeSearchIndicator();
        removeTypingIndicator();

        if (err.name === 'AbortError') {
            streamingMsg.container.remove();
        } else {
            streamingMsg.container.remove();
            const safeError = getUserFriendlyError(err?.message);
            if (safeError) {
                createMessageElement("ai", safeError, true, text);
            }
        }
    } finally {
        resetInputState();
    }
}

async function streamTokenWithTypingEffect(element, token) {
    if (!element) return;

    const chars = token.split('');

    for (let i = 0; i < chars.length; i++) {
        if (!State.streamingActive) break;

        element.textContent += chars[i];

        let delay = 5;
        if (chars[i] === '.' || chars[i] === '!' || chars[i] === '?') delay = 40;
        else if (chars[i] === ',' || chars[i] === ';') delay = 15;
        else if (chars[i] === ' ') delay = 2;

        await new Promise(resolve => setTimeout(resolve, delay));

        if (State.autoScroll && !State.isUserScrolling) {
            Elements.chatMessages.scrollTo({
                top: Elements.chatMessages.scrollHeight,
                behavior: 'auto'
            });
        }
    }
}

function resetInputState() {
    State.streamingActive = false;
    State.streamController = null;
    State.tokenQueue = [];
    State.rendering = false;
    State.currentStreamingElement = null;

    updateSendButtonIcon('send');
    Elements.messageInput.disabled = false;
    Elements.sendButton.disabled = false;
}

function retryMessage(prompt) {
    if (!prompt) return;
    sendMessage({ message: prompt });
}

function initSidebar() {
    Elements.menuToggle.addEventListener("click", toggleSidebar);
    Elements.overlay.addEventListener("click", closeSidebar);

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && Elements.sidebar.classList.contains('open')) {
            closeSidebar();
        }
    });

    let startX = 0;
    let startY = 0;

    document.addEventListener("touchstart", e => {
        startX = e.changedTouches[0].screenX;
        startY = e.changedTouches[0].screenY;
    }, { passive: true });

    document.addEventListener("touchend", e => {
        const endX = e.changedTouches[0].screenX;
        const endY = e.changedTouches[0].screenY;
        const diffX = endX - startX;
        const diffY = endY - startY;

        if (Math.abs(diffX) > Math.abs(diffY)) {
            if (diffX > 80) openSidebar();
            if (diffX < -80) closeSidebar();
        }
    }, { passive: true });
}

function openSidebar()  { Elements.sidebar.classList.add("open");    Elements.overlay.classList.add("show"); }
function closeSidebar() { Elements.sidebar.classList.remove("open"); Elements.overlay.classList.remove("show"); }
function toggleSidebar() { Elements.sidebar.classList.contains("open") ? closeSidebar() : openSidebar(); }

async function clearDeprecatedAIShellCache() {
    try {
        if (!window.caches?.keys) return;
        const keys = await caches.keys();
        await Promise.all(
            keys
                .filter(key => key === 'deenlink-v1' || key.startsWith('deenlink-ai-'))
                .map(key => caches.delete(key))
        );
    } catch (_) {}
}

function scrollEditIntoView(editContainer) {
    setTimeout(() => {
        const messagesArea = Elements.chatMessages.closest('.messages-area')
            || Elements.chatMessages.parentElement;
        if (!messagesArea) return;

        const containerRect = editContainer.getBoundingClientRect();
        const areaRect = messagesArea.getBoundingClientRect();

        if (containerRect.bottom > areaRect.bottom - 60) {
            messagesArea.scrollTop += (containerRect.bottom - areaRect.bottom + 80);
        }
    }, 400);
}

function initEventListeners() {
    Elements.sendButton.addEventListener("click", () => {
        if (State.streamingActive && State.streamController) {
            stopGeneration();
        } else {
            sendMessage();
        }
    });

    Elements.modulesBtn?.addEventListener('click', (e) => {
        if (e.target.closest('.module-pill-close')) return;
        e.stopPropagation();
        Elements.modulesPopup?.classList.toggle('hidden');
    });

    document.querySelectorAll('.module-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            if (State.modeLocked) {
                showSuccessToast('Mode is locked for this chat.');
                Elements.modulesPopup?.classList.add('hidden');
                return;
            }
            _applyModule(btn.dataset.module);
        });
    });

    document.addEventListener('click', (e) => {
        if (!Elements.modulesPopup || Elements.modulesPopup.classList.contains('hidden')) return;
        if (!Elements.modulesPopup.contains(e.target) && e.target !== Elements.modulesBtn && !Elements.modulesBtn?.contains(e.target)) {
            Elements.modulesPopup.classList.add('hidden');
        }
    });

    const inputContainer = document.querySelector('.input-container');
    if (inputContainer) {
        inputContainer.addEventListener('touchmove', (e) => {
            const onTextarea = e.target === Elements.messageInput;
            const textareaScrollable = onTextarea &&
                Elements.messageInput.scrollHeight > Elements.messageInput.clientHeight;
            if (!textareaScrollable) {
                e.preventDefault();
            }
        }, { passive: false });
    }

    Elements.messageInput.addEventListener("input", () => {
        Elements.messageInput.style.height = "auto";
        const newHeight = Math.min(Elements.messageInput.scrollHeight, 200);
        Elements.messageInput.style.height = newHeight + "px";
        Elements.messageInput.style.overflowY = Elements.messageInput.scrollHeight > 200 ? "auto" : "hidden";
    });

    Elements.messageInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            if (!State.streamingActive) sendMessage();
        }
    });

    const messagesArea = Elements.chatMessages.closest('.messages-area') || Elements.chatMessages.parentElement;
    const scrollContainer = messagesArea || Elements.chatMessages;

    const updateScrollButton = () => {
        if (!Elements.scrollToBottomBtn) return;
        const distanceFromBottom = scrollContainer.scrollHeight -
            scrollContainer.scrollTop -
            scrollContainer.clientHeight;

        if (distanceFromBottom > 250) {
            Elements.scrollToBottomBtn.classList.remove('hidden');
            Elements.scrollToBottomBtn.classList.add('visible');
        } else {
            Elements.scrollToBottomBtn.classList.add('hidden');
            Elements.scrollToBottomBtn.classList.remove('visible');
        }
    };

    scrollContainer.addEventListener("scroll", () => {
        if (State.scrollTimeout) clearTimeout(State.scrollTimeout);

        updateScrollButton();

        const distanceFromBottom = scrollContainer.scrollHeight -
            scrollContainer.scrollTop -
            scrollContainer.clientHeight;

        if (State.streamingActive) {
            if (distanceFromBottom > 300) {
                State.isUserScrolling = true;
                State.autoScroll = false;
            } else {
                State.autoScroll = true;
                State.isUserScrolling = false;
            }
        } else {
            State.autoScroll = distanceFromBottom < 100;
        }

        State.scrollTimeout = setTimeout(() => {
            State.isUserScrolling = false;
        }, 150);
    });

    if (scrollContainer !== Elements.chatMessages) {
        Elements.chatMessages.addEventListener("scroll", () => {
            updateScrollButton();
        });
    }

    if (Elements.scrollToBottomBtn) {
        Elements.scrollToBottomBtn.addEventListener('click', () => {
            scrollContainer.scrollTo({ top: scrollContainer.scrollHeight, behavior: 'smooth' });
            Elements.chatMessages.scrollTo({ top: Elements.chatMessages.scrollHeight, behavior: 'smooth' });
        });
    }

    Elements.themeToggle?.addEventListener("click", () => {
        setAppThemePreference(!isAppDarkMode());
    });

    Elements.quickPromptBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            Elements.messageInput.value = btn.dataset.prompt;
            Elements.messageInput.focus();
            Elements.messageInput.dispatchEvent(new Event('input'));
        });
    });

    Elements.newChatBtn.addEventListener("click", async () => {
        if (State.streamingActive) return;
        try {
            const newConv = await createNewConversation();
            State.activeConversationId = newConv.id;
            Elements.chatMessages.innerHTML = "";
            _clearModule({ force: true });
            updateEmptyStateVisibility();
            closeSidebar();
            reapplyWallpaperPalette();
            await loadConversations();
        } catch (err) {
            showError("Failed to create new chat");
        }
    });

    if (window.visualViewport) {
        let _vpRafId = null;

        const updateInputPosition = () => {
            if (!Elements.inputArea) return;
            const vv = window.visualViewport;
            const keyboardHeight = window.innerHeight - vv.height - (vv.offsetTop || 0);

            if (keyboardHeight > 50) {
                const maxBottom = Math.floor(vv.height * 0.45);
                const targetBottom = Math.min(keyboardHeight + 4, maxBottom);
                Elements.inputArea.style.bottom = targetBottom + 'px';
            } else {
                Elements.inputArea.style.bottom = 'calc(16px + env(safe-area-inset-bottom))';
            }
        };

        const scheduleVpUpdate = () => {
            if (_vpRafId) cancelAnimationFrame(_vpRafId);
            _vpRafId = requestAnimationFrame(updateInputPosition);
        };

        window.visualViewport.addEventListener('resize', scheduleVpUpdate);
        window.visualViewport.addEventListener('scroll', scheduleVpUpdate);
    }

    Elements.chatMessages.addEventListener('click', async (e) => {
        const actionBtn = e.target.closest('.message-action-btn');
        if (!actionBtn) return;

        const prompt = actionBtn.dataset.prompt || '';
        const action = actionBtn.dataset.action;
        if (!prompt) return;

        if (action === 'edit-prompt') {
            const messageId = actionBtn.dataset.messageId || '';
            if (!messageId || !State.activeConversationId) {
                showError("Cannot edit this message");
                return;
            }

            const messageEl = actionBtn.closest('.message');
            const messageTextEl = messageEl.querySelector('.message-text');
            const actionsEl = messageEl.querySelector('.message-actions');

            const originalHTML = messageTextEl.innerHTML;

            actionsEl.style.display = 'none';

            const editContainer = document.createElement('div');
            editContainer.className = 'edit-container';

            const textarea = document.createElement('textarea');
            textarea.className = 'edit-textarea';
            textarea.value = prompt;

            textarea.addEventListener("input", () => {
                textarea.style.height = "auto";
                textarea.style.height = Math.min(textarea.scrollHeight, 200) + "px";
            });

            const btnContainer = document.createElement('div');
            btnContainer.className = 'edit-btn-container';

            const cancelBtn = document.createElement('button');
            cancelBtn.className = 'cancel-edit-btn';
            cancelBtn.textContent = 'Cancel';

            const sendBtn = document.createElement('button');
            sendBtn.className = 'send-edit-btn';
            sendBtn.textContent = 'Send';

            btnContainer.appendChild(cancelBtn);
            btnContainer.appendChild(sendBtn);

            editContainer.appendChild(textarea);
            editContainer.appendChild(btnContainer);

            messageTextEl.innerHTML = '';
            messageTextEl.appendChild(editContainer);
            messageTextEl.classList.add('editing');

            textarea.style.height = "auto";
            textarea.style.height = Math.min(textarea.scrollHeight, 200) + "px";
            textarea.focus();

            scrollEditIntoView(editContainer);

            cancelBtn.addEventListener('click', () => {
                messageTextEl.innerHTML = originalHTML;
                messageTextEl.classList.remove('editing');
                actionsEl.style.display = 'flex';
            });

            sendBtn.addEventListener('click', () => {
                const newText = textarea.value.trim();
                if (!newText) return;

                messageTextEl.innerHTML = originalHTML;
                messageTextEl.classList.remove('editing');
                actionsEl.style.display = 'flex';

                State.editingMessageId = messageId;
                sendMessage({ message: newText, editMessageId: messageId });
            });

            return;
        }

        if (action === 'retry-prompt') {
            if (State.streamingActive) return;

            const messageEl = actionBtn.closest('.message');
            if (messageEl && messageEl.classList.contains('error')) {
                messageEl.remove();
            }

            sendMessage({ message: prompt });
            return;
        }
    });

    const closeFeedback = () => {
        if (Elements.feedbackModal) Elements.feedbackModal.classList.add('hidden');
        State.pendingFeedback = null;
    };

    Elements.closeFeedbackModal?.addEventListener('click', closeFeedback);
    Elements.cancelFeedbackBtn?.addEventListener('click', closeFeedback);

    Elements.submitFeedbackBtn?.addEventListener('click', async () => {
        if (!State.pendingFeedback) return;
        const { prompt, response, dislikeBtn, likeBtn } = State.pendingFeedback;
        const reason = Elements.feedbackReasonInput?.value.trim() || null;
        closeFeedback();
        dislikeBtn.classList.add('active');
        dislikeBtn.innerHTML = '<i class="fas fa-thumbs-down"></i><span>Not helpful</span>';
        likeBtn.disabled = true;
        await sendFeedback('dislike', prompt, response, reason);
        showSuccessToast('Thanks for your feedback!');
    });

    const settingsModal = Elements.settingsModal;

    function showSettingsPage(pageId) {
        settingsModal?.querySelectorAll('.settings-page').forEach(p => p.classList.add('hidden'));
        document.getElementById(pageId)?.classList.remove('hidden');
    }

    function closeSettings() {
        settingsModal?.classList.add('hidden');
        showSettingsPage('settingsPageMain');
    }

    Elements.settingsBtn?.addEventListener('click', () => {
        Elements.modeRadios?.forEach(r => { r.checked = (r.value === State.responseMode); });

        const profile = State.userProfile || {};
        const displayName = profile.full_name || profile.name || profile.username
            || document.getElementById('userNameDisplay')?.textContent || 'Guest';

        const nameEl = document.getElementById('settingsProfileName');
        if (nameEl) nameEl.textContent = displayName;

        const subEl = document.getElementById('settingsProfileSub');
        if (subEl) subEl.textContent = profile.email || 'DeenLink Member';

        const avatarEl = document.getElementById('settingsProfileAvatar');
        const rawAvatar = profile.profile_image || profile.avatar_url
            || profile.profile_picture || profile.photo || null;

        if (avatarEl && rawAvatar) {
            let fullAvatarUrl;
            if (rawAvatar.startsWith('http://') || rawAvatar.startsWith('https://')) {
                fullAvatarUrl = rawAvatar;
            } else {
                const filename = rawAvatar.split('/').pop();
                fullAvatarUrl = `https://deenlink.org/uploads/profile/${filename}`;
            }
            const img = document.createElement('img');
            img.src = fullAvatarUrl;
            img.alt = displayName;
            img.style.cssText = 'width:100%;height:100%;border-radius:50%;object-fit:cover;';
            img.onerror = function () {
                avatarEl.innerHTML = '';
                const icon = document.createElement('i');
                icon.className = 'fas fa-user-circle';
                avatarEl.appendChild(icon);
            };
            avatarEl.innerHTML = '';
            avatarEl.appendChild(img);
        }

        const toggle = document.getElementById('toggleAINotif');
        if (toggle) toggle.checked = (localStorage.getItem('deen_notif_ai_done') === 'true');

        settingsModal?.classList.remove('hidden');
        showSettingsPage('settingsPageMain');
        closeSidebar();
    });

    ['closeSettingsModal','closeSettingsFromPersonalization','closeSettingsFromMemory','closeSettingsFromManageMemory','closeSettingsFromMode'].forEach(id => {
        document.getElementById(id)?.addEventListener('click', closeSettings);
    });

    document.getElementById('saveSettingsBtn')?.addEventListener('click', () => {
        let selectedMode = 'auto';
        Elements.modeRadios?.forEach(r => { if (r.checked) selectedMode = r.value; });
        State.responseMode = selectedMode;
        sessionStorage.setItem('responseMode', selectedMode);
        closeSettings();
        showSuccessToast('Settings saved!');
    });

    document.getElementById('saveSettingsModeBtn')?.addEventListener('click', () => {
        let selectedMode = 'auto';
        Elements.modeRadios?.forEach(r => { if (r.checked) selectedMode = r.value; });
        State.responseMode = selectedMode;
        sessionStorage.setItem('responseMode', selectedMode);
        showSuccessToast('Response mode saved!');
        showSettingsPage('settingsPageMain');
    });

    document.getElementById('navToPersonalization')?.addEventListener('click', () => showSettingsPage('settingsPagePersonalization'));
    document.getElementById('navToMode')?.addEventListener('click', () => showSettingsPage('settingsPageMode'));
    document.getElementById('navToMemory')?.addEventListener('click', () => showSettingsPage('settingsPageMemory'));
    document.getElementById('navToManageMemory')?.addEventListener('click', () => {
        showSettingsPage('settingsPageManageMemory');
        loadMemoriesIntoPage();
    });
    document.getElementById('navToAppearance')?.addEventListener('click', () => {
        applyAIAppearanceSettings();
        showSettingsPage('settingsPageAppearance');
    });
    document.getElementById('navToLanguage')?.addEventListener('click', () => {
        const lang = localStorage.getItem('deenLang') || 'en';
        const tr = localStorage.getItem('deenQuranTr') || 'sahih';
        const langSel = document.getElementById('responseLangSelect');
        const trSel = document.getElementById('quranTranslationSelect');
        if (langSel) langSel.value = lang;
        if (trSel) trSel.value = tr;
        showSettingsPage('settingsPageLanguage');
    });
    document.getElementById('navToNotifications')?.addEventListener('click', () => showSettingsPage('settingsPageNotifications'));

    document.getElementById('fontSizeSlider')?.addEventListener('input', (e) => {
        const sz = applyChatFontSize(e.target.value);
        const preview = document.getElementById('fontSizePreview');
        if (preview) preview.textContent = sz + 'px';
    });

    document.getElementById('fontFamilySelect')?.addEventListener('change', (e) => {
        applyChatFontFamily(e.target.value);
    });

    document.getElementById('backgroundSelect')?.addEventListener('change', (e) => {
        localStorage.setItem('deenChatWallpaper', e.target.value || '');
        applyWallpaperValue(e.target.value);
    });

    document.getElementById('backgroundUpload')?.addEventListener('change', (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        if (!file.type.startsWith('image/')) {
            showError('Please choose an image file.');
            e.target.value = '';
            return;
        }
        if (file.size > 2.5 * 1024 * 1024) {
            showError('Please choose a wallpaper under 2.5MB.');
            e.target.value = '';
            return;
        }
        const reader = new FileReader();
        reader.onload = () => {
            const dataUrl = String(reader.result || '');
            if (!dataUrl) return;
            localStorage.setItem('deenChatWallpaperUpload', dataUrl);
            localStorage.setItem('deenChatWallpaper', dataUrl);
            const select = document.getElementById('backgroundSelect');
            if (select) select.value = '';
            const title = document.getElementById('wallpaperUploadTitle');
            const hint = document.getElementById('wallpaperUploadHint');
            if (title) title.textContent = 'Wallpaper selected';
            if (hint) hint.textContent = file.name;
            applyWallpaperValue(dataUrl);
            showSuccessToast('Wallpaper preview updated.');
        };
        reader.onerror = () => showError('Could not read that wallpaper image.');
        reader.readAsDataURL(file);
    });

    document.getElementById('saveAppearanceBtn')?.addEventListener('click', () => {
        const sz = document.getElementById('fontSizeSlider')?.value || '15';
        const fontFamily = document.getElementById('fontFamilySelect')?.value || DEFAULT_AI_FONT;
        const wallpaper = localStorage.getItem('deenChatWallpaper') || document.getElementById('backgroundSelect')?.value || '';
        localStorage.setItem('deenFontSize', String(applyChatFontSize(sz)));
        localStorage.setItem('deenFontFamily', normalizeFontFamily(fontFamily));
        localStorage.setItem('deenChatWallpaper', wallpaper);
        applyChatFontFamily(fontFamily);
        applyWallpaperValue(wallpaper);
        showSuccessToast('Appearance saved!');
        closeSettings();
    });

    document.getElementById('themeLight')?.addEventListener('click', () => {
        setAppThemePreference(false, 'light');
        applyAIAppearanceSettings();
    });
    document.getElementById('themeDark')?.addEventListener('click', () => {
        setAppThemePreference(true, 'dark');
        applyAIAppearanceSettings();
    });
    document.getElementById('themeSystem')?.addEventListener('click', () => {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        setAppThemePreference(prefersDark, 'system');
        applyAIAppearanceSettings();
    });

    document.getElementById('saveLanguageBtn')?.addEventListener('click', () => {
        const lang = document.getElementById('responseLangSelect')?.value || 'en';
        const tr = document.getElementById('quranTranslationSelect')?.value || 'sahih';
        localStorage.setItem('deenLang', lang);
        localStorage.setItem('deenQuranTr', tr);
        State.responseLang = lang;
        showSuccessToast('Language preferences saved!');
        closeSettings();
    });

    document.getElementById('saveNotificationsBtn')?.addEventListener('click', async () => {
        const aiNotif = document.getElementById('toggleAINotif')?.checked || false;
        localStorage.setItem('deen_notif_ai_done', aiNotif ? 'true' : 'false');

        if (aiNotif) {
            const result = await ensureAINotificationRoute(true);
            if (!result?.ok) {
                const note = document.getElementById('notifPermissionNote');
                if (note) {
                    note.style.display = 'block';
                    note.textContent = result?.reason === 'disabled'
                        ? 'Notifications are disabled in the main app settings.'
                        : 'Browser notification permission is required. Please allow notifications when prompted.';
                }
            }
        }
        showSuccessToast('Notification preferences saved!');
        closeSettings();
    });

    document.getElementById('backFromPersonalization')?.addEventListener('click', () => showSettingsPage('settingsPageMain'));
    document.getElementById('backFromMemory')?.addEventListener('click', () => showSettingsPage('settingsPagePersonalization'));
    document.getElementById('backFromManageMemory')?.addEventListener('click', () => showSettingsPage('settingsPageMemory'));
    document.getElementById('backFromMode')?.addEventListener('click', () => showSettingsPage('settingsPageMain'));
    document.getElementById('backFromAppearance')?.addEventListener('click', () => showSettingsPage('settingsPagePersonalization'));
    document.getElementById('backFromLanguage')?.addEventListener('click', () => showSettingsPage('settingsPagePersonalization'));
    document.getElementById('backFromNotifications')?.addEventListener('click', () => showSettingsPage('settingsPagePersonalization'));

    ['closeSettingsModal','closeSettingsFromPersonalization','closeSettingsFromMemory',
     'closeSettingsFromManageMemory','closeSettingsFromMode','closeSettingsFromAppearance',
     'closeSettingsFromLanguage','closeSettingsFromNotifications'].forEach(id => {
        document.getElementById(id)?.addEventListener('click', closeSettings);
    });

    document.getElementById('settingsOverlay')?.addEventListener('click', closeSettings);

    document.getElementById('clearMemoriesBtn')?.addEventListener('click', async () => {
        if (!confirm("Clear all your memories? This cannot be undone.")) return;
        try {
            const token = await getValidToken();
            const res = await fetch(`${API_BASE_URL}/user/memories`, { method: 'DELETE', headers: { "Authorization": `Bearer ${token}` } });
            if (res.ok) {
                Object.keys(localStorage).filter(k => k.startsWith('deen_memory_notices_')).forEach(k => localStorage.removeItem(k));
                showSuccessToast("All memories cleared.");
                showSettingsPage('settingsPageMemory');
            }
        } catch { showError("Failed to clear memories"); }
    });
}

async function loadMemoriesIntoPage() {
    const loading = document.getElementById('memoriesListLoading');
    const ul = document.getElementById('memoriesList');
    const empty = document.getElementById('memoriesEmpty');
    if (!ul) return;

    ul.innerHTML = '';
    if (empty) empty.classList.add('hidden');
    if (loading) { loading.style.display = 'block'; }

    try {
        const token = await getValidToken();
        const res = await fetch(`${API_BASE_URL}/user/memories`, { headers: { "Authorization": `Bearer ${token}` } });
        if (!res.ok) throw new Error("Failed to fetch memories");
        const memories = await res.json();

        if (loading) loading.style.display = 'none';

        if (!memories.length) {
            if (empty) empty.classList.remove('hidden');
            return;
        }

        memories.forEach(m => {
            const li = document.createElement('li');
            li.className = 'memory-item-gpt';
            li.dataset.memoryId = m.id;

            const convId = m.conversation_id || m.conv_id || null;
            const chatLinkHtml = convId
                ? `Saved from a <a class="memory-chat-link" data-conv-id="${convId}" href="#">chat</a>`
                : `Saved by DeenLink AI`;

            li.innerHTML = `
                <div class="memory-item-gpt-body">
                    <div class="memory-item-gpt-fact">${escapeHtml(m.fact)}</div>
                    <div class="memory-item-gpt-meta">${chatLinkHtml}</div>
                </div>
                <button class="memory-item-menu-btn" title="Options">⋯</button>
            `;

            li.querySelector('.memory-chat-link')?.addEventListener('click', async (e) => {
                e.preventDefault();
                const cid = e.currentTarget.dataset.convId;
                if (!cid) return;
                document.getElementById('settingsModal')?.classList.add('hidden');
                await switchToConversation(cid);
            });

            const menuBtn = li.querySelector('.memory-item-menu-btn');
            menuBtn?.addEventListener('click', (e) => {
                e.stopPropagation();
                document.querySelectorAll('.memory-item-popover').forEach(p => p.remove());

                const popover = document.createElement('div');
                popover.className = 'memory-item-popover';
                popover.innerHTML = `
                    <button class="memory-popover-item danger"><i class="fas fa-trash"></i> Delete</button>
                `;
                popover.querySelector('.memory-popover-item')?.addEventListener('click', async () => {
                    popover.remove();
                    try {
                        const token = await getValidToken();
                        const del = await fetch(`${API_BASE_URL}/user/memories/${m.id}`, { method: 'DELETE', headers: { "Authorization": `Bearer ${token}` } });
                        if (del.ok) {
                            li.remove();
                            if (!document.querySelectorAll('.memory-item-gpt').length) {
                                if (empty) empty.classList.remove('hidden');
                            }
                        }
                    } catch { showError("Failed to delete memory"); }
                });
                li.style.position = 'relative';
                li.appendChild(popover);

                const outsideClick = (ev) => {
                    if (!popover.contains(ev.target)) { popover.remove(); document.removeEventListener('click', outsideClick); }
                };
                setTimeout(() => document.addEventListener('click', outsideClick), 0);
            });

            ul.appendChild(li);
        });
    } catch {
        if (loading) loading.style.display = 'none';
        if (empty) { empty.classList.remove('hidden'); empty.textContent = "Failed to load memories."; }
    }
}

/* ============================================================
   MODULES & SPEECH
   ── Only change from original: icon values use FA HTML strings
      instead of emoji, so the active chip renders a proper icon.
   ============================================================ */
const MODULE_CONFIG = {
    books:      { label: 'Books',      icon: '<i class="fas fa-book-open"></i>',      placeholder: 'Search Hadith, Surah or Ayah...', prefix: 'search_sources: ' },
    motivation: { label: 'Motivation', icon: '<i class="fas fa-lightbulb"></i>',      placeholder: 'Need some Islamic encouragement?', prefix: 'topic_motivation: ' },
    fatwa:      { label: 'Fatwa',      icon: '<i class="fas fa-scale-balanced"></i>', placeholder: 'Ask an Islamic jurisprudence question...', prefix: 'topic_fatwa: ' },
    general:    { label: 'General',    icon: '<i class="fas fa-comments"></i>',       placeholder: 'Ask anything Islamic...', prefix: '' },
    chat:       { label: 'Chat',       icon: '<i class="fas fa-message"></i>',        placeholder: 'Casual conversation...', prefix: '' }
};

function _applyModule(moduleId, options = {}) {
    const config = MODULE_CONFIG[moduleId];
    if (!config) return;
    if (State.modeLocked && !options.force && moduleId !== State.queryModule) {
        showSuccessToast('Mode is locked for this chat.');
        return;
    }
    State.queryModule = moduleId;
    if (options.lock) {
        State.modeLocked = true;
        State.modeLockedConversationId = State.activeConversationId;
    }
    sessionStorage.setItem(TAB_MODE_KEY, moduleId);
    _writeTabModeLock();
    if (Elements.messageInput) Elements.messageInput.placeholder = config.placeholder;

    _renderActiveModuleChip();
    Elements.modulesPopup?.classList.add('hidden');
    Elements.messageInput?.focus();
}

function isAppDarkMode() {
    if (localStorage.getItem('theme') === 'system') {
        return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return localStorage.getItem('isDarkMode') === 'true';
}

function applyAppThemePreference(isDark = isAppDarkMode()) {
    document.documentElement.classList.toggle('dark-theme', isDark);
    document.documentElement.classList.toggle('light-theme', !isDark);
    document.documentElement.classList.toggle('dark-mode', isDark);
    document.documentElement.classList.toggle('light-mode', !isDark);
    document.documentElement.style.colorScheme = isDark ? 'dark' : 'light';
    document.body.classList.toggle('dark-theme', isDark);
    document.body.classList.toggle('light-theme', !isDark);
    document.body.classList.toggle('dark-mode', isDark);
    document.body.classList.toggle('light-mode', !isDark);
    if (Elements.themeToggle) {
        const icon = Elements.themeToggle.querySelector('i');
        if (icon) icon.className = isDark ? 'fas fa-sun' : 'fas fa-moon';
    }
    if (document.body) applyWallpaperValue(localStorage.getItem('deenChatWallpaper') || '');
    requestAnimationFrame(() => applyWallpaperValue(localStorage.getItem('deenChatWallpaper') || ''));
}

function setAppThemePreference(isDark, mode = 'manual') {
    localStorage.setItem('isDarkMode', isDark ? 'true' : 'false');
    localStorage.setItem('theme', mode === 'system' ? 'system' : (isDark ? 'dark' : 'light'));
    applyAppThemePreference(isDark);
    document.dispatchEvent(new CustomEvent('themeChanged', { detail: { isDarkMode: isDark } }));
}

const DEFAULT_AI_FONT = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif";
const AI_WALLPAPER_PALETTES = {
    '': { rgb: '29, 111, 66', color: '#1D6F42' },
    'https://picsum.photos/seed/bg1/800/600': { rgb: '33, 113, 125', color: '#21717d' },
    'https://picsum.photos/seed/bg2/800/600': { rgb: '116, 91, 45', color: '#745b2d' }
};

function normalizeFontFamily(value) {
    const font = String(value || '').trim();
    return font || DEFAULT_AI_FONT;
}

function applyChatFontSize(size) {
    const safe = Math.max(13, Math.min(20, parseInt(size || '15', 10) || 15));
    document.documentElement.style.setProperty('--chat-font-size', safe + 'px');
    return safe;
}

function applyChatFontFamily(fontFamily) {
    document.documentElement.style.setProperty('--app-font-family', normalizeFontFamily(fontFamily));
}

function setAccentPalette(rgb, color) {
    if (!rgb) return;
    document.documentElement.style.setProperty('--primary-green-rgb', rgb);
    document.documentElement.style.setProperty('--primary-green', color || `rgb(${rgb})`);
    document.documentElement.style.setProperty('--user-bg', color || `rgb(${rgb})`);
    document.documentElement.style.setProperty('--ai-accent-rgb', rgb);
    document.documentElement.style.setProperty('--ai-accent', color || `rgb(${rgb})`);
}

function resetAccentPalette() {
    const isDark = isAppDarkMode();
    setAccentPalette(isDark ? '46, 204, 113' : '29, 111, 66', isDark ? '#2ecc71' : '#1D6F42');
}

function applyWallpaperValue(wallpaper) {
    const value = String(wallpaper || '').trim();
    document.body.classList.toggle('has-chat-wallpaper', !!value);
    document.body.classList.toggle('wallpaper-accent-active', !!value);
    if (value) {
        document.documentElement.style.setProperty('--chat-wallpaper-image', `url("${value.replace(/"/g, '%22')}")`);
        const known = AI_WALLPAPER_PALETTES[value];
        if (known) setAccentPalette(known.rgb, known.color);
        else extractAccentFromImage(value);
    } else {
        document.documentElement.style.setProperty('--chat-wallpaper-image', 'none');
        resetAccentPalette();
    }
}

function reapplyWallpaperPalette() {
    applyWallpaperValue(localStorage.getItem('deenChatWallpaper') || '');
}

function extractAccentFromImage(src) {
    if (!src) return;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
        try {
            const canvas = document.createElement('canvas');
            const size = 24;
            canvas.width = size;
            canvas.height = size;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, size, size);
            const data = ctx.getImageData(0, 0, size, size).data;
            let r = 0, g = 0, b = 0, count = 0;
            for (let i = 0; i < data.length; i += 4) {
                if (data[i + 3] < 80) continue;
                const lightness = (data[i] + data[i + 1] + data[i + 2]) / 3;
                if (lightness < 35 || lightness > 225) continue;
                r += data[i]; g += data[i + 1]; b += data[i + 2]; count++;
            }
            if (!count) return;
            r = Math.round(r / count);
            g = Math.round(g / count);
            b = Math.round(b / count);
            setAccentPalette(`${r}, ${g}, ${b}`, `rgb(${r}, ${g}, ${b})`);
        } catch (_) {}
    };
    img.src = src;
}

function applyAIAppearanceSettings() {
    const fontSize = applyChatFontSize(localStorage.getItem('deenFontSize') || '15');
    const fontFamily = localStorage.getItem('deenFontFamily') || DEFAULT_AI_FONT;
    const wallpaper = localStorage.getItem('deenChatWallpaper') || '';
    applyChatFontFamily(fontFamily);
    applyWallpaperValue(wallpaper);
    requestAnimationFrame(() => {
        applyChatFontFamily(localStorage.getItem('deenFontFamily') || DEFAULT_AI_FONT);
        reapplyWallpaperPalette();
    });

    const slider = document.getElementById('fontSizeSlider');
    const preview = document.getElementById('fontSizePreview');
    const fontSelect = document.getElementById('fontFamilySelect');
    const bgSelect = document.getElementById('backgroundSelect');
    const uploadTitle = document.getElementById('wallpaperUploadTitle');
    const uploadHint = document.getElementById('wallpaperUploadHint');
    if (slider) slider.value = String(fontSize);
    if (preview) preview.textContent = fontSize + 'px';
    if (fontSelect) fontSelect.value = fontFamily;
    if (bgSelect) bgSelect.value = AI_WALLPAPER_PALETTES[wallpaper] ? wallpaper : '';
    if (uploadTitle) uploadTitle.textContent = wallpaper && !AI_WALLPAPER_PALETTES[wallpaper] ? 'Wallpaper selected' : 'Upload wallpaper';
    if (uploadHint) uploadHint.textContent = wallpaper && !AI_WALLPAPER_PALETTES[wallpaper] ? 'Custom image is active' : 'Choose an image from your device';

    document.querySelectorAll('.appearance-opt-btn').forEach(btn => btn.classList.remove('active'));
    const themeMode = localStorage.getItem('theme') || (isAppDarkMode() ? 'dark' : 'light');
    const activeThemeBtn = themeMode === 'system'
        ? document.getElementById('themeSystem')
        : (isAppDarkMode() ? document.getElementById('themeDark') : document.getElementById('themeLight'));
    activeThemeBtn?.classList.add('active');
}

function appBasePath() {
    const path = String(window.location.pathname || '');
    const idx = path.toLowerCase().indexOf('/deenlink/');
    return idx >= 0 ? path.slice(0, idx + '/deenlink'.length) : '';
}

function appUrl(path) {
    const clean = String(path || '').startsWith('/') ? String(path || '') : '/' + String(path || '');
    return appBasePath() + clean;
}

function urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) outputArray[i] = rawData.charCodeAt(i);
    return outputArray;
}

async function ensureAppWebPushFallback(promptUser = false) {
    if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) {
        return { ok: false, reason: 'unsupported' };
    }
    if (Notification.permission === 'denied') return { ok: false, reason: 'permission_denied' };

    const keyRes = await fetch(appUrl('/api/notifications/web_push_public_key.php'), { credentials: 'include' });
    const keyData = await keyRes.json().catch(() => null);
    const publicKey = keyRes.ok && keyData?.enabled ? String(keyData.public_key || '') : '';
    if (!publicKey) return { ok: false, reason: 'public_key_missing' };

    const registrations = await navigator.serviceWorker.getRegistrations();
    const registration = registrations.find((reg) => {
        try {
            return String(reg.scope || '').includes('/deenlink/');
        } catch (_) {
            return false;
        }
    }) || registrations[0] || null;
    if (!registration) return { ok: false, reason: 'service_worker_missing' };
    if (Notification.permission === 'default') {
        if (!promptUser) return { ok: false, reason: 'permission_default' };
        const permission = await Notification.requestPermission();
        if (permission !== 'granted') return { ok: false, reason: 'permission_denied' };
    }
    if (Notification.permission !== 'granted') return { ok: false, reason: 'permission_denied' };

    const existing = await registration.pushManager.getSubscription();
    const subscription = existing || await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(publicKey)
    });
    const saveRes = await fetch(appUrl('/api/notifications/web_push_subscribe.php'), {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subscription })
    });
    if (!saveRes.ok) return { ok: false, reason: 'subscribe_failed' };
    localStorage.setItem('dl_webpush_enabled_v1', '1');
    return { ok: true };
}

async function ensureAINotificationRoute(promptUser = false) {
    if (!('Notification' in window)) return { ok: false, reason: 'unsupported' };
    if (localStorage.getItem('notificationsEnabled') === 'false') return { ok: false, reason: 'disabled' };
    if (window.DeenLinkWebPush?.request || window.DeenLinkWebPush?.ensure) {
        const fn = promptUser ? window.DeenLinkWebPush.request : window.DeenLinkWebPush.ensure;
        const result = await fn().catch((err) => ({ ok: false, reason: err?.message || 'web_push_failed' }));
        if (result?.ok) return result;
        if (!promptUser && Notification.permission === 'granted') return { ok: true, localOnly: true };
        return result || { ok: false, reason: 'web_push_failed' };
    }
    const fallback = await ensureAppWebPushFallback(promptUser).catch((err) => ({ ok: false, reason: err?.message || 'web_push_failed' }));
    if (fallback?.ok) return fallback;
    if (Notification.permission === 'default' && promptUser) {
        const permission = await Notification.requestPermission();
        return { ok: permission === 'granted', reason: permission === 'granted' ? '' : 'permission_denied', localOnly: true };
    }
    return { ok: Notification.permission === 'granted', reason: Notification.permission === 'granted' ? '' : 'permission_denied', localOnly: true };
}

async function showAINotification(title, body) {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    const cleanBody = String(body || '').replace(/[#*`]/g, '').trim().substring(0, 140);
    try {
        const registration = await navigator.serviceWorker?.getRegistration('./')
            || await navigator.serviceWorker?.getRegistration('../')
            || await navigator.serviceWorker?.ready;
        if (registration?.showNotification) {
            await registration.showNotification(title || 'DeenLink AI', {
                body: cleanBody,
                icon: '../img/deenlink-ai.png',
                badge: '../img/icon-192.png',
                data: { url: window.location.href }
            });
            return;
        }
    } catch (_) {}
    try {
        new Notification(title || 'DeenLink AI', { body: cleanBody, icon: '../img/deenlink-ai.png' });
    } catch (_) {}
}

function _renderActiveModuleChip() {
    const config = MODULE_CONFIG[State.queryModule];
    if (!config) {
        _clearModuleChip();
        return;
    }

    const inputContainer = document.querySelector('.input-container');
    if (!inputContainer) return;

    _clearModuleChip();

    const chip = document.createElement('div');
    chip.id = 'activeModuleChip';
    chip.className = 'active-module-chip';
    if (State.modeLocked) chip.classList.add('locked');

    // icon rendered as HTML; label as safe text node
    const iconSpan = document.createElement('span');
    iconSpan.innerHTML = config.icon;   // safe — only our own FA strings
    chip.appendChild(iconSpan);

    const labelSpan = document.createElement('span');
    labelSpan.textContent = config.label;
    chip.appendChild(labelSpan);

    if (State.modeLocked) {
        const lockIcon = document.createElement('span');
        lockIcon.className = 'module-lock-icon';
        lockIcon.innerHTML = '<i class="fas fa-lock"></i>';
        lockIcon.title = 'Locked for this chat';
        chip.appendChild(lockIcon);
    } else {
        const closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.setAttribute('aria-label', 'Clear mode');
        closeBtn.innerHTML = '<i class="fas fa-xmark"></i>';
        closeBtn.addEventListener('click', (e) => { e.stopPropagation(); _clearModule(); });
        chip.appendChild(closeBtn);
    }

    inputContainer.insertBefore(chip, inputContainer.firstChild);
    Elements.modulesPopup?.classList.add('hidden');
    Elements.messageInput?.focus();
}

function _clearModule(options = {}) {
    if (State.modeLocked && !options.force) {
        showSuccessToast('Mode is locked for this chat.');
        return;
    }
    State.queryModule = null;
    State.modeLocked = false;
    State.modeLockedConversationId = null;
    if (!options.preserveStorage) _clearTabModeLock();
    if (Elements.messageInput) {
        Elements.messageInput.placeholder = 'Ask your Islamic question...';
    }
    if (Elements.modulesBtn) {
        Elements.modulesBtn.innerHTML = '<i class="fas fa-plus"></i>';
        Elements.modulesBtn.className = 'input-action-btn';
    }
    _clearModuleChip();
}

function _clearModuleChip() {
    document.getElementById('activeModuleChip')?.remove();
}

function _restoreTabMode() {
    const savedModule = sessionStorage.getItem(TAB_MODE_KEY);
    const savedLock = _readTabModeLock();
    if (savedModule && MODULE_CONFIG[savedModule]) {
        State.queryModule = savedModule;
        if (Elements.messageInput) Elements.messageInput.placeholder = MODULE_CONFIG[savedModule].placeholder;
    }
    if (savedLock?.module && MODULE_CONFIG[savedLock.module]) {
        State.queryModule = savedLock.module;
        State.modeLocked = Boolean(State.activeConversationId && State.activeConversationId === savedLock.conversationId);
        State.modeLockedConversationId = savedLock.conversationId || null;
        if (Elements.messageInput) Elements.messageInput.placeholder = MODULE_CONFIG[savedLock.module].placeholder;
    }
    _renderActiveModuleChip();
}

function _syncModeLockForConversation(conversationId) {
    const savedLock = _readTabModeLock();
    if (savedLock?.conversationId === conversationId && MODULE_CONFIG[savedLock.module]) {
        State.queryModule = savedLock.module;
        State.modeLocked = true;
        State.modeLockedConversationId = conversationId;
        if (Elements.messageInput) Elements.messageInput.placeholder = MODULE_CONFIG[savedLock.module].placeholder;
        _renderActiveModuleChip();
        return;
    }

    _clearModule({ force: true, preserveStorage: true });
}

function initSpeechToText() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition || !Elements.micBtn) {
        if (Elements.micBtn) {
            Elements.micBtn.style.opacity = '0.35';
            Elements.micBtn.title = 'Voice input not supported in this browser';
            Elements.micBtn.disabled = true;
        }
        return;
    }

    const recognition = new SpeechRecognition();
    recognition.interimResults = false;
    recognition.continuous = false;
    let isListening = false;

    Elements.micBtn.addEventListener('click', () => {
        if (isListening) {
            recognition.stop();
            return;
        }
        recognition.lang = localStorage.getItem('deenLang') === 'ar' ? 'ar-SA' : 'en-US';
        try { recognition.start(); } catch (e) { console.warn('Speech start error:', e); }
    });

    recognition.onstart = () => {
        isListening = true;
        Elements.micBtn.classList.add('listening');
        Elements.micBtn.innerHTML = '<i class="fas fa-microphone-slash"></i>';
    };

    recognition.onresult = (event) => {
        const transcript = Array.from(event.results)
            .map(r => r[0].transcript)
            .join('');
        if (Elements.messageInput) {
            Elements.messageInput.value = transcript;
            Elements.messageInput.dispatchEvent(new Event('input'));
        }
    };

    recognition.onend = () => {
        isListening = false;
        Elements.micBtn.classList.remove('listening');
        Elements.micBtn.innerHTML = '<i class="fas fa-microphone"></i>';
    };

    recognition.onerror = (event) => {
        isListening = false;
        Elements.micBtn.classList.remove('listening');
        Elements.micBtn.innerHTML = '<i class="fas fa-microphone"></i>';
        if (event.error === 'not-allowed') {
            showError('Microphone access denied. Please allow it in browser settings.');
        }
    };
}

async function _notifyAIStatus(title, bodyText) {
    if (localStorage.getItem('deen_notif_ai_done') !== 'true') return;
    if (document.visibilityState === 'visible') {
        return;
    }
    const route = await ensureAINotificationRoute(false);
    if (route?.ok) {
        await showAINotification(title, bodyText);
        return;
    }
}

function _notifyAIDone(bodyText) {
    void _notifyAIStatus('DeenLink AI response is ready', bodyText || 'Your answer is ready.');
}

window.addEventListener("load", async () => {
    clearDeprecatedAIShellCache();
    initSidebar();
    initEventListeners();

    applyAppThemePreference();
    window.addEventListener('storage', (event) => {
        if (event.key === 'isDarkMode' || event.key === 'theme') {
            applyAppThemePreference();
            applyAIAppearanceSettings();
            reapplyWallpaperPalette();
        }
    });
    window.matchMedia?.('(prefers-color-scheme: dark)')?.addEventListener?.('change', (event) => {
        if (localStorage.getItem('theme') !== 'system') return;
        setAppThemePreference(event.matches, 'system');
        applyAIAppearanceSettings();
        reapplyWallpaperPalette();
    });

    const savedMode = sessionStorage.getItem("responseMode") || localStorage.getItem("responseMode");
    if (savedMode) State.responseMode = savedMode;

    applyAIAppearanceSettings();
    reapplyWallpaperPalette();

    const savedLang = localStorage.getItem('deenLang');
    if (savedLang) State.responseLang = savedLang;

    _restoreTabMode();

    fetchUserProfile();
    await loadConversations();
    updateEmptyStateVisibility();

    initSpeechToText();

});

const backBtn = document.getElementById('backBtn');

if (backBtn) {
    backBtn.addEventListener('click', function(event) {
        event.preventDefault();
        window.location.assign(new URL('../index.html', window.location.href).toString());
    });
}

function _memoryStorageKey(convId) { return `deen_memory_notices_${convId}`; }

function persistMemoryNotice(fact) {
    const convId = State.activeConversationId;
    if (!convId) return;
    try {
        const key = _memoryStorageKey(convId);
        const existing = JSON.parse(localStorage.getItem(key) || '[]');
        if (!existing.includes(fact)) { existing.push(fact); localStorage.setItem(key, JSON.stringify(existing)); }
    } catch {}
}

function restoreMemoryNotices(convId) {
    try {
        const key = _memoryStorageKey(convId);
        const facts = JSON.parse(localStorage.getItem(key) || '[]');
        facts.forEach(fact => _renderMemoryNotice(fact, false));
    } catch {}
}

function _renderMemoryNotice(fact, persist = true) {
    if (persist) persistMemoryNotice(fact);
    const notice = document.createElement('div');
    notice.className = 'memory-inline-notice';
    notice.dataset.fact = fact;
    notice.innerHTML = `
        <i class="fas fa-brain"></i>
        <span><strong>Memory updated:</strong> ${escapeHtml(fact)}</span>
        <button class="memory-inline-manage"><i class="fas fa-cog"></i> Manage</button>
    `;
    notice.querySelector('.memory-inline-manage')?.addEventListener('click', () => {
        Elements.settingsModal?.classList.remove('hidden');
        document.querySelectorAll('.settings-page').forEach(p => p.classList.add('hidden'));
        document.getElementById('settingsPageManageMemory')?.classList.remove('hidden');
        loadMemoriesIntoPage();
    });
    Elements.chatMessages.appendChild(notice);
    if (State.autoScroll) Elements.chatMessages.scrollTo({ top: Elements.chatMessages.scrollHeight, behavior: 'smooth' });
}

function showMemoryUpdatedInline(fact) { _renderMemoryNotice(fact, true); }
function showMemoryUpdatedToast(fact)  { showMemoryUpdatedInline(fact); }
