let csrfToken = '';
const STORAGE_KEY = 'deenai_local_conversations_v1';

const chatMessages = document.getElementById('chatMessages');
const messagesArea = document.getElementById('messagesArea');
const messageInput = document.getElementById('messageInput');
const sendButton = document.getElementById('sendButton');
const conversationList = document.getElementById('conversationList');
const newChatBtn = document.getElementById('newChatBtn');
const themeToggle = document.getElementById('themeToggle');
const quickPromptBtns = document.querySelectorAll('.quick-prompt-btn');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('sidebarOverlay');
const menuToggle = document.getElementById('menuToggle');

const state = {
    conversations: [],
    activeConversationId: null,
    isSending: false
};

const WELCOME_MESSAGE = {
    sender: 'ai',
    kind: 'plain',
    text: 'Assalamu Alaikum. Ask about Quran, Hadith, fiqh, aqeedah, fatwa, books/stories, or FAQ available in local datasets.',
    time: new Date().toISOString()
};

window.addEventListener('load', () => {
    initSidebar();
    initTheme();
    initComposer();
    initQuickPrompts();
    loadState();
    ensureConversation();
    renderConversationTabs();
    renderActiveConversation();
});

function initSidebar() {
    if (menuToggle) {
        menuToggle.addEventListener('click', toggleSidebar);
    }
    if (overlay) {
        overlay.addEventListener('click', closeSidebar);
    }
    let startX = 0;
    document.addEventListener('touchstart', (e) => { startX = e.changedTouches[0].screenX; });
    document.addEventListener('touchend', (e) => {
        const diff = e.changedTouches[0].screenX - startX;
        if (diff > 80) openSidebar();
        if (diff < -80) closeSidebar();
    });
}

function initTheme() {
    if (!themeToggle) return;
    const savedDark = localStorage.getItem('deenai_dark') === '1';
    if (savedDark) document.body.classList.add('dark-theme');
    themeToggle.innerHTML = savedDark ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
    themeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark-theme');
        const isDark = document.body.classList.contains('dark-theme');
        localStorage.setItem('deenai_dark', isDark ? '1' : '0');
        themeToggle.innerHTML = isDark ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
    });
}

function initComposer() {
    if (!messageInput || !sendButton) return;
    messageInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    messageInput.addEventListener('input', () => {
        messageInput.style.height = 'auto';
        messageInput.style.height = `${Math.min(messageInput.scrollHeight, 140)}px`;
        sendButton.disabled = messageInput.value.trim() === '' || state.isSending;
    });
    sendButton.addEventListener('click', sendMessage);

    if (newChatBtn) {
        newChatBtn.addEventListener('click', () => {
            createConversation('New Chat');
            renderConversationTabs();
            renderActiveConversation();
            closeSidebar();
        });
    }
}

function initQuickPrompts() {
    quickPromptBtns.forEach((btn) => {
        btn.addEventListener('click', () => {
            messageInput.value = btn.dataset.prompt || '';
            messageInput.dispatchEvent(new Event('input'));
            messageInput.focus();
        });
    });
}

function scrollMessagesToBottom() {
    const scroller = messagesArea || chatMessages;
    if (!scroller) return;
    scroller.scrollTop = scroller.scrollHeight;
}

function getCsrfToken() {
    if (csrfToken) return Promise.resolve(csrfToken);
    return fetch('../api/auth/csrf.php', { credentials: 'include' })
        .then((res) => res.json())
        .then((data) => {
            csrfToken = data.csrf_token || '';
            return csrfToken;
        });
}

async function askDeenAI(question, context = []) {
    const token = await getCsrfToken();
    const res = await fetch('../api/deenai/ask.php', {
        method: 'POST',
        credentials: 'include',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-CSRF-Token': token
        },
        body: JSON.stringify({ question, context })
    });
    const data = await res.json().catch(() => ({ status: 'error', message: 'Invalid server response' }));
    if (!res.ok || data.status === 'error') {
        throw new Error(data.message || 'Failed to get AI response');
    }
    return data;
}

async function sendDeenAIFeedback(queryLogId, helpful, correction = '') {
    const token = await getCsrfToken();
    const res = await fetch('../api/deenai/feedback.php', {
        method: 'POST',
        credentials: 'include',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-CSRF-Token': token
        },
        body: JSON.stringify({
            query_log_id: queryLogId,
            helpful: !!helpful,
            correction: correction || ''
        })
    });
    const data = await res.json().catch(() => ({ status: 'error', message: 'Invalid server response' }));
    if (!res.ok || data.status === 'error') {
        throw new Error(data.message || 'Failed to save feedback');
    }
    return data;
}

function getRecentUserContext(conv, maxItems = 4) {
    if (!conv || !Array.isArray(conv.messages)) return [];
    const userMessages = conv.messages
        .filter((m) => m && m.sender === 'user' && typeof m.text === 'string')
        .map((m) => m.text.trim())
        .filter(Boolean);
    if (!userMessages.length) return [];
    return userMessages.slice(Math.max(0, userMessages.length - maxItems));
}

async function sendMessage() {
    const text = (messageInput?.value || '').trim();
    if (!text || state.isSending) return;

    const conv = getActiveConversation();
    if (!conv) return;
    const contextLines = getRecentUserContext(conv, 4);

    conv.messages.push({
        sender: 'user',
        kind: 'plain',
        text,
        time: new Date().toISOString()
    });
    if (!conv.title || conv.title === 'New Chat') {
        conv.title = text.slice(0, 40);
    }

    messageInput.value = '';
    messageInput.style.height = 'auto';
    state.isSending = true;
    if (sendButton) sendButton.disabled = true;
    renderConversationTabs();
    renderActiveConversation();
    const loadingEl = appendLoadingMessage();
    closeSidebar();

    try {
        const response = await askDeenAI(text, contextLines);
        if (loadingEl && loadingEl.parentNode) loadingEl.parentNode.removeChild(loadingEl);

        const aiMsg = {
            sender: 'ai',
            kind: 'rag',
            text: response.ai_explanation || '',
            payload: response,
            time: new Date().toISOString()
        };
        conv.messages.push(aiMsg);
        persistState();
        renderActiveConversation();
    } catch (err) {
        if (loadingEl && loadingEl.parentNode) loadingEl.parentNode.removeChild(loadingEl);
        conv.messages.push({
            sender: 'ai',
            kind: 'plain',
            text: err?.message || 'Unable to process request',
            time: new Date().toISOString()
        });
        persistState();
        renderActiveConversation();
        showError(err?.message || 'Unable to process request');
    } finally {
        state.isSending = false;
        if (sendButton) sendButton.disabled = (messageInput?.value || '').trim() === '';
    }
}

function appendLoadingMessage() {
    const wrapper = document.createElement('div');
    wrapper.className = 'message ai';
    wrapper.innerHTML = `
        <div class="message-content">
            <div class="typing-indicator">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        </div>
    `;
    chatMessages.appendChild(wrapper);
    scrollMessagesToBottom();
    return wrapper;
}

function getActiveConversation() {
    return state.conversations.find((c) => c.id === state.activeConversationId) || null;
}

function createConversation(title = 'New Chat') {
    const id = `c_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const conv = {
        id,
        title,
        createdAt: new Date().toISOString(),
        messages: [{ ...WELCOME_MESSAGE }]
    };
    state.conversations.unshift(conv);
    state.activeConversationId = id;
    persistState();
    return conv;
}

function ensureConversation() {
    if (!state.conversations.length) {
        createConversation('New Chat');
        return;
    }
    if (!state.activeConversationId || !getActiveConversation()) {
        state.activeConversationId = state.conversations[0].id;
    }
}

function renderConversationTabs() {
    if (!conversationList) return;
    conversationList.innerHTML = '';
    state.conversations.forEach((conv) => {
        const card = document.createElement('div');
        card.className = `conversation-card ${conv.id === state.activeConversationId ? 'active' : ''}`;

        const title = document.createElement('span');
        title.textContent = conv.title || 'New Chat';
        title.style.display = 'inline-block';
        title.style.maxWidth = '80%';
        title.style.whiteSpace = 'nowrap';
        title.style.overflow = 'hidden';
        title.style.textOverflow = 'ellipsis';
        card.appendChild(title);

        const del = document.createElement('button');
        del.textContent = 'Delete';
        del.className = 'delete-btn';
        del.style.marginLeft = '8px';
        del.style.border = 'none';
        del.style.background = 'transparent';
        del.style.color = 'inherit';
        del.style.cursor = 'pointer';
        del.style.fontSize = '11px';
        del.addEventListener('click', (e) => {
            e.stopPropagation();
            removeConversation(conv.id);
        });
        card.appendChild(del);

        card.addEventListener('click', () => {
            state.activeConversationId = conv.id;
            persistState();
            renderConversationTabs();
            renderActiveConversation();
            closeSidebar();
        });
        conversationList.appendChild(card);
    });
}

function removeConversation(id) {
    state.conversations = state.conversations.filter((c) => c.id !== id);
    if (!state.conversations.length) {
        createConversation('New Chat');
    } else if (state.activeConversationId === id) {
        state.activeConversationId = state.conversations[0].id;
    }
    persistState();
    renderConversationTabs();
    renderActiveConversation();
}

function renderActiveConversation() {
    const conv = getActiveConversation();
    if (!conv || !chatMessages) return;
    chatMessages.innerHTML = '';
    conv.messages.forEach((msg) => {
        if (msg.sender === 'ai' && msg.kind === 'rag') {
            appendRagMessage(msg);
        } else {
            appendPlainMessage(msg.sender, msg.text, msg.time);
        }
    });
    scrollMessagesToBottom();
    persistState();
}

function appendPlainMessage(sender, text, timeIso) {
    const el = document.createElement('div');
    el.className = `message ${sender}`;
    el.innerHTML = `
        <div class="message-content">
            <div class="message-text"></div>
            <div class="message-time">${sender === 'user' ? 'You' : 'DeenLink AI'} • ${formatTime(timeIso)}</div>
        </div>
    `;
    el.querySelector('.message-text').textContent = text || '';
    chatMessages.appendChild(el);
    scrollMessagesToBottom();
}

function appendRagMessage(msg) {
    const payload = msg.payload || {};
    const sources = Array.isArray(payload.original_items) ? payload.original_items : [];
    const dataset = payload.dataset || {};
    const wrapper = document.createElement('div');
    wrapper.className = 'message ai';

    const itemsHtml = sources.map((item) => {
        const arabic = escapeHtml(item.arabic || '');
        const english = escapeHtml(item.english || '');
        const question = escapeHtml(item.question || '');
        const text = escapeHtml(item.text || '');
        const reference = escapeHtml(item.reference || '');
        const relatedClass = payload.related_scholar_answer ? ' related' : '';

        return `
            <div class="rag-source${relatedClass}">
                ${arabic ? `<div class="rag-arabic">${arabic}</div>` : ''}
                ${question ? `<div class="rag-meta"><strong>Matched Question:</strong> ${question}</div>` : ''}
                ${english ? `<div class="rag-english">${english}</div>` : ''}
                ${!english && text ? `<div class="rag-explanation">${text}</div>` : ''}
                ${reference ? `<div class="rag-meta">${reference}</div>` : ''}
            </div>
        `;
    }).join('');

    const datasetLabel = `${escapeHtml(dataset.name || 'Dataset')} (${escapeHtml(dataset.type || 'unknown')})`;
    const explanation = escapeHtml(msg.text || payload.ai_explanation || '');
    const outOfScope = !!payload.out_of_scope;

    const queryLogId = Number(payload.query_log_id || 0);
    const helpfulLabel = msg.helpful === true ? 'Helpful ✓' : 'Helpful';
    wrapper.innerHTML = `
        <div class="message-content">
            <div class="message-text">
                <div class="rag-answer">
                    ${payload.related_scholar_answer ? `<div class="rag-meta"><strong>Related Scholar Answer</strong></div>` : ''}
                    <div class="rag-explanation">${explanation}</div>
                    ${outOfScope ? '' : `<div class="rag-meta">Source: ${datasetLabel}</div>`}
                    ${outOfScope ? '' : itemsHtml}
                </div>
            </div>
            <div class="message-actions">
                <button class="message-action copy-response-btn" type="button"><i class="fas fa-copy"></i> Copy</button>
                <button class="message-action helpful-response-btn" type="button" ${queryLogId > 0 ? '' : 'disabled'}><i class="fas fa-thumbs-up"></i> ${helpfulLabel}</button>
            </div>
            <div class="message-time">DeenLink AI • ${formatTime(msg.time)}</div>
        </div>
    `;
    chatMessages.appendChild(wrapper);

    const copyBtn = wrapper.querySelector('.copy-response-btn');
    if (copyBtn) {
        copyBtn.addEventListener('click', async () => {
            try {
                await navigator.clipboard.writeText(msg.text || payload.ai_explanation || '');
                copyBtn.innerHTML = '<i class="fas fa-check"></i> Copied';
                setTimeout(() => {
                    copyBtn.innerHTML = '<i class="fas fa-copy"></i> Copy';
                }, 1200);
            } catch {
                showError('Unable to copy response');
            }
        });
    }

    const helpfulBtn = wrapper.querySelector('.helpful-response-btn');
    if (helpfulBtn && queryLogId > 0) {
        helpfulBtn.addEventListener('click', async () => {
            try {
                await sendDeenAIFeedback(queryLogId, true, '');
                msg.helpful = true;
                persistState();
                helpfulBtn.innerHTML = '<i class="fas fa-thumbs-up"></i> Helpful ✓';
            } catch (err) {
                showError(err?.message || 'Unable to save feedback');
            }
        });
    }
    scrollMessagesToBottom();
}

function formatTime(iso) {
    try {
        const d = new Date(iso);
        return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    } catch {
        return '';
    }
}

function escapeHtml(value) {
    return String(value || '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function loadState() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return;
        const parsed = JSON.parse(raw);
        if (!parsed || !Array.isArray(parsed.conversations)) return;
        state.conversations = parsed.conversations;
        state.activeConversationId = parsed.activeConversationId || (parsed.conversations[0]?.id ?? null);
    } catch {
        // ignore storage errors
    }
}

function persistState() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
            conversations: state.conversations,
            activeConversationId: state.activeConversationId
        }));
    } catch {
        // ignore storage errors
    }
}

function openSidebar() {
    if (sidebar) sidebar.classList.add('open');
    if (overlay) overlay.classList.add('show');
}

function closeSidebar() {
    if (sidebar) sidebar.classList.remove('open');
    if (overlay) overlay.classList.remove('show');
}

function toggleSidebar() {
    if (!sidebar) return;
    if (sidebar.classList.contains('open')) closeSidebar(); else openSidebar();
}

function showError(message) {
    const toast = document.getElementById('error-toast');
    if (!toast) return;
    toast.textContent = message || 'Something went wrong';
    toast.classList.remove('hidden');
    setTimeout(() => toast.classList.add('hidden'), 3800);
}
