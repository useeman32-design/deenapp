(() => {
  // ---------------------------------------------------------------------------
  // Admin auth guard (separate admin login)
  // ---------------------------------------------------------------------------
  // Goal: admin pages should not sit on "Server error" when session expires.
  // Instead, redirect to admin/login.html (which also handles first-time bootstrap).
  function redirectToAdminLogin() {
    try {
      const path = (location.pathname || '').toLowerCase();
      if (path.endsWith('/admin/login.html')) return;
      const next = encodeURIComponent(location.pathname + location.search + location.hash);
      location.replace('./login.html?next=' + next);
    } catch (_) { /* ignore */ }
  }

  // Patch fetch so any admin API call that returns 401 triggers redirect.
  // We only redirect on 401 (Not logged in). 403 can be "Permission denied".
  const _origFetch = window.fetch ? window.fetch.bind(window) : null;
  if (_origFetch) {
    window.fetch = async function patchedFetch(input, init) {
      const res = await _origFetch(input, init);
      try {
        const url = (input && typeof input === 'object' && 'url' in input) ? String(input.url) : String(input || '');
        if (res && res.status === 401 && url.includes('/api/admin/')) {
          redirectToAdminLogin();
        }
      } catch (_) { /* ignore */ }
      return res;
    };
  }

  const STYLE_ID = 'admin-report-bell-style';
  const AUTH_STYLE_ID = 'admin-auth-guard-style';
  const BELL_ID = 'adminReportBell';
  const MOBILE_BELL_ID = 'adminReportBellMobile';
  const PROFILE_MODAL_ID = 'adminProfileEditModalV1';
  const PASS_MODAL_ID = 'adminPasswordChangeModalV1';

  function initAuthGuard() {
    try {
      const path = (location.pathname || '').toLowerCase();
      if (path.endsWith('/admin/login.html')) return;
      if (!document.getElementById(AUTH_STYLE_ID)) {
        const style = document.createElement('style');
        style.id = AUTH_STYLE_ID;
        style.textContent = 'body.admin-auth-pending{opacity:0;pointer-events:none;transition:opacity .18s ease} body.admin-auth-ready{opacity:1}';
        document.head.appendChild(style);
      }
      if (document.body) {
        document.body.classList.add('admin-auth-pending');
      } else {
        document.addEventListener('DOMContentLoaded', () => {
          document.body.classList.add('admin-auth-pending');
        }, { once: true });
      }
    } catch (_) { /* ignore */ }
  }

  function revealAdminPage() {
    try {
      document.body.classList.remove('admin-auth-pending');
      document.body.classList.add('admin-auth-ready');
    } catch (_) { /* ignore */ }
  }

  initAuthGuard();

  const MENU_PERM_BY_PAGE = {
    'index.html': 'dashboard',
    'admin-activity.html': 'dashboard',
    'user-management.html': 'users',
    'scholar-management.html': 'scholars',
    'quran.html': 'quran',
    'hadith-management.html': 'quran',
    'video-management.html': 'videos',
    'wallpapers.html': 'wallpapers',
    'course-management.html': 'dashboard',
    'quiz-management.html': 'dashboard',
    'deenpoints.html': 'deenpoints',
    'reports.html': 'reports',
    'backup.html': 'backup',
    'settings.html': 'settings',
    'roles.html': 'roles',
    'verification.html': 'settings',
    // These pages are admin-level controls; gate them by settings unless you add finer permissions later.
    'donation-monetization.html': 'settings',
    'announcement.html': 'settings',
    'deenlinkai.html': 'settings',
    'poster.html': 'settings'
  };

  function roleLabel(role) {
    const r = String(role || '').toLowerCase();
    if (r === 'super_admin') return 'Super Admin';
    if (r === 'content_manager') return 'Content Manager';
    if (r === 'moderator') return 'Moderator';
    return 'Viewer';
  }

  function roleIcon(role) {
    const r = String(role || '').toLowerCase();
    if (r === 'super_admin') return 'fa-crown';
    if (r === 'content_manager') return 'fa-pen-ruler';
    if (r === 'moderator') return 'fa-shield-halved';
    return 'fa-eye';
  }

  function toast(message, type = 'success') {
    const id = 'adminGlobalToastV1';
    let el = document.getElementById(id);
    if (!el) {
      el = document.createElement('div');
      el.id = id;
      el.style.cssText = 'position:fixed;top:16px;right:16px;z-index:99999;background:#1d6f42;color:#fff;padding:12px 14px;border-radius:12px;box-shadow:0 10px 24px rgba(0,0,0,.25);max-width:360px;font-size:14px;display:none;';
      document.body.appendChild(el);
    }
    el.style.background = (type === 'error') ? '#b91c1c' : 'var(--primary-green)';
    el.textContent = String(message || 'Done');
    el.style.display = 'block';
    clearTimeout(el._t);
    el._t = setTimeout(() => { el.style.display = 'none'; }, 2600);
  }

  async function fetchAdminMe() {
    const res = await fetch('../api/admin/auth/me.php?ts=' + Date.now(), {
      credentials: 'include',
      cache: 'no-store',
      headers: { Accept: 'application/json', 'Cache-Control': 'no-store' }
    });
    if (res.status === 401) {
      redirectToAdminLogin();
      throw new Error('Not logged in');
    }
    const data = await res.json().catch(() => null);
    if (!res.ok || !data || data.status !== 'success') {
      throw new Error((data && data.message) ? data.message : 'Failed to load admin');
    }
    const admin = data.admin || {};
    admin.permissions = Array.isArray(admin.permissions) ? admin.permissions : [];
    return admin;
  }

  function applyAdminIdentity(admin) {
    const name = String(admin.full_name || admin.username || 'Admin');
    const email = String(admin.email || '');
    const role = roleLabel(admin.role);

    // Sidebar profile tag
    const nameEl = document.querySelector('.admin-profile-tag .admin-info h4');
    const emailEl = document.querySelector('.admin-profile-tag .admin-info p');
    if (nameEl) nameEl.textContent = name;
    if (emailEl) emailEl.textContent = email;

    const infoWrap = document.querySelector('.admin-profile-tag .admin-info');
    if (infoWrap) {
      let rankEl = infoWrap.querySelector('.admin-rank-line');
      if (!rankEl) {
        rankEl = document.createElement('div');
        rankEl.className = 'admin-rank-line';
        rankEl.style.cssText = 'display:inline-flex;align-items:center;gap:6px;width:fit-content;max-width:100%;font-size:10px;font-weight:800;color:var(--accent-gold);margin-top:6px;padding:4px 9px;border-radius:999px;letter-spacing:.04em;text-transform:uppercase;background:rgba(212,175,55,.14);border:1px solid rgba(212,175,55,.26);box-shadow:inset 0 1px 0 rgba(255,255,255,.08);';
        if (emailEl && emailEl.parentNode === infoWrap) {
          infoWrap.insertBefore(rankEl, emailEl);
        } else {
          infoWrap.appendChild(rankEl);
        }
      }
      rankEl.innerHTML = '<i class="fas ' + roleIcon(admin.role) + '"></i><span>' + role + '</span>';
    }

    // Welcome text (Dashboard page).
    document.querySelectorAll('.welcome-text span').forEach((sp) => {
      sp.textContent = role + ' ' + name;
    });
  }

  function currentPageKey() {
    try {
      const parts = String(location.pathname || '').split('/');
      return String(parts[parts.length - 1] || '').toLowerCase();
    } catch (_) {
      return '';
    }
  }

  function applyMenuVisibility(admin) {
    const perms = new Set((admin.permissions || []).map((p) => String(p)));
    const isSuper = String(admin.role || '').toLowerCase() === 'super_admin';

    const links = Array.from(document.querySelectorAll('.sidebar-nav a'));
    links.forEach((a) => {
      const href = (a.getAttribute('href') || '').trim();
      const li = a.closest('li');
      if (!li) return;
      if (!href || href === '#') {
        // Hide placeholder links for non-super admins (keeps UI clean).
        if (!isSuper) li.style.display = 'none';
        return;
      }
      const file = href.split('?')[0].split('#')[0].split('/').pop().toLowerCase();
      const need = MENU_PERM_BY_PAGE[file] || null;
      if (!need) {
        if (!isSuper) li.style.display = 'none';
        return;
      }
      if (!isSuper && !perms.has(need)) {
        li.style.display = 'none';
      }
    });

    // If the current page is not allowed, redirect to dashboard.
    const page = currentPageKey();
    const need = MENU_PERM_BY_PAGE[page] || 'dashboard';
    if (!isSuper && need && !perms.has(need)) {
      toast('Permission denied for this page.', 'error');
      setTimeout(() => { location.href = './index.html'; }, 900);
    }
  }

  function ensureProfileModals() {
    if (document.getElementById(PROFILE_MODAL_ID)) return;

    const style = document.createElement('style');
    style.textContent = `
      .adm-modal-wrap{position:fixed;inset:0;background:rgba(0,0,0,.55);display:none;align-items:center;justify-content:center;z-index:99999;padding:16px;}
      .adm-modal-wrap.active{display:flex;}
      .adm-modal{width:min(520px,100%);max-height:86vh;overflow:auto;background:var(--white);border:1px solid var(--medium-gray);border-radius:16px;box-shadow:0 18px 40px rgba(0,0,0,.25);padding:16px;}
      .adm-modal-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px;}
      .adm-modal-title{font-weight:800;color:var(--text-dark);display:inline-flex;align-items:center;gap:10px;}
      .adm-close{width:40px;height:40px;border-radius:12px;border:1px solid var(--medium-gray);background:var(--white);cursor:pointer;}
      .adm-grid{display:grid;gap:12px;}
      .adm-row{display:grid;gap:8px;}
      .adm-row label{font-size:12px;font-weight:800;color:var(--dark-gray);}
      .adm-row input,.adm-row select{width:100%;padding:11px 12px;border-radius:12px;border:1px solid var(--medium-gray);background:var(--white);color:var(--text-dark);}
      .adm-actions{display:flex;gap:10px;justify-content:flex-end;margin-top:12px;flex-wrap:wrap;}
      .adm-btn{border:0;border-radius:12px;padding:10px 14px;font-weight:800;cursor:pointer;display:inline-flex;align-items:center;gap:8px;}
      .adm-btn.primary{background:var(--primary-green);color:#fff;}
      .adm-btn.secondary{background:var(--light-gray);color:var(--text-dark);border:1px solid var(--medium-gray);}
      .adm-hint{font-size:12px;color:var(--dark-gray);line-height:1.4;background:var(--light-gray);border:1px dashed var(--medium-gray);border-radius:12px;padding:10px;}
      .adm-pw-wrap{position:relative;}
      .adm-pw-wrap input{padding-right:44px;}
      .adm-pw-toggle{position:absolute;right:10px;top:50%;transform:translateY(-50%);width:36px;height:36px;border-radius:12px;border:1px solid var(--medium-gray);background:var(--white);color:var(--dark-gray);cursor:pointer;display:flex;align-items:center;justify-content:center;}
    `;
    document.head.appendChild(style);

    const profileWrap = document.createElement('div');
    profileWrap.className = 'adm-modal-wrap';
    profileWrap.id = PROFILE_MODAL_ID;
    profileWrap.innerHTML = `
      <div class="adm-modal" role="dialog" aria-modal="true" aria-label="Admin profile">
        <div class="adm-modal-head">
          <div class="adm-modal-title"><i class="fas fa-user-shield"></i><span>Admin Profile</span></div>
          <button class="adm-close" type="button" data-adm-close="${PROFILE_MODAL_ID}"><i class="fas fa-times"></i></button>
        </div>
        <div class="adm-grid">
          <div class="adm-row">
            <label>Full Name</label>
            <input id="admFullName" type="text" autocomplete="name">
          </div>
          <div class="adm-row" data-super-only="1">
            <label>Username</label>
            <input id="admUsername" type="text" autocomplete="username">
          </div>
          <div class="adm-row">
            <label>Email</label>
            <input id="admEmail" type="email" autocomplete="email">
          </div>
          <div class="adm-hint" data-super-only="1">
            You can update your security questions below. (Both questions and both answers are required to change them.)
          </div>
          <div class="adm-row" data-super-only="1">
            <label>Security Question 1</label>
            <select id="admQ1">
              <option value="">Leave unchanged</option>
              <option>What is the name of your first school?</option>
              <option>What is the name of your childhood best friend?</option>
              <option>What is the city you were born in?</option>
              <option>What is your favorite teacher's name?</option>
              <option>What is the name of your first pet?</option>
            </select>
          </div>
          <div class="adm-row" data-super-only="1">
            <label>Answer 1</label>
            <input id="admA1" type="text" autocomplete="off" placeholder="Required if changing questions">
          </div>
          <div class="adm-row" data-super-only="1">
            <label>Security Question 2</label>
            <select id="admQ2">
              <option value="">Leave unchanged</option>
              <option>What is your mother's maiden name?</option>
              <option>What is the name of the street you grew up on?</option>
              <option>What is your favorite book?</option>
              <option>What is your favorite food?</option>
              <option>What is the name of your first job?</option>
            </select>
          </div>
          <div class="adm-row" data-super-only="1">
            <label>Answer 2</label>
            <input id="admA2" type="text" autocomplete="off" placeholder="Required if changing questions">
          </div>
        </div>
        <div class="adm-actions">
          <button class="adm-btn secondary" type="button" id="admOpenPass"><i class="fas fa-key"></i> Change Password</button>
          <button class="adm-btn primary" type="button" id="admSaveProfile"><i class="fas fa-save"></i> Save</button>
        </div>
      </div>
    `;
    document.body.appendChild(profileWrap);

    const passWrap = document.createElement('div');
    passWrap.className = 'adm-modal-wrap';
    passWrap.id = PASS_MODAL_ID;
    passWrap.innerHTML = `
      <div class="adm-modal" role="dialog" aria-modal="true" aria-label="Change password">
        <div class="adm-modal-head">
          <div class="adm-modal-title"><i class="fas fa-key"></i><span>Change Password</span></div>
          <button class="adm-close" type="button" data-adm-close="${PASS_MODAL_ID}"><i class="fas fa-times"></i></button>
        </div>
        <div class="adm-grid">
          <div class="adm-hint">
            We will send a verification code to your admin email. The code expires in 3 minutes.
          </div>
          <div class="adm-row">
            <label>Verification Code</label>
            <input id="admCode" type="text" inputmode="numeric" placeholder="Enter code from email">
          </div>
          <div class="adm-row">
            <label>New Password</label>
            <div class="adm-pw-wrap">
              <input id="admNewPass" type="password" minlength="8" autocomplete="new-password">
              <button class="adm-pw-toggle" type="button" data-toggle-password="admNewPass" aria-label="Show password"><i class="fas fa-eye"></i></button>
            </div>
          </div>
        </div>
        <div class="adm-actions">
          <button class="adm-btn secondary" type="button" id="admSendCode"><i class="fas fa-paper-plane"></i> Send Code</button>
          <button class="adm-btn primary" type="button" id="admConfirmPass"><i class="fas fa-check"></i> Confirm</button>
        </div>
      </div>
    `;
    document.body.appendChild(passWrap);

    // Close on backdrop click
    [profileWrap, passWrap].forEach((wrap) => {
      wrap.addEventListener('click', (e) => { if (e.target === wrap) wrap.classList.remove('active'); });
    });
  }

  async function ensureCsrf() {
    const r = await fetch('../api/auth/csrf.php', { credentials: 'include' });
    const d = await r.json().catch(() => ({}));
    return String(d?.csrf_token || '');
  }

  function openModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.add('active');
  }
  function closeModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove('active');
  }

  function bindProfileActions(admin) {
    ensureProfileModals();
    const isSuper = String(admin.role || '').toLowerCase() === 'super_admin';

    // Non-super admins should not manage username/security questions here.
    if (!isSuper) {
      document.querySelectorAll('#' + PROFILE_MODAL_ID + ' [data-super-only=\"1\"]').forEach((el) => {
        el.style.display = 'none';
      });
    }

    // Fill fields
    const name = String(admin.full_name || '');
    const username = String(admin.username || '');
    const email = String(admin.email || '');
    const qFull = document.getElementById('admFullName');
    const qUser = document.getElementById('admUsername');
    const qEmail = document.getElementById('admEmail');
    if (qFull) qFull.value = name;
    if (qUser) qUser.value = username;
    if (qEmail) qEmail.value = email;

    // Buttons
    document.getElementById('admOpenPass')?.addEventListener('click', () => {
      closeModal(PROFILE_MODAL_ID);
      openModal(PASS_MODAL_ID);
    });

    document.getElementById('admSaveProfile')?.addEventListener('click', async () => {
      try {
        const payload = {
          full_name: String(document.getElementById('admFullName')?.value || '').trim(),
          email: String(document.getElementById('admEmail')?.value || '').trim(),
        };
        if (isSuper) {
          payload.username = String(document.getElementById('admUsername')?.value || '').trim();
          payload.security_q1 = String(document.getElementById('admQ1')?.value || '').trim();
          payload.security_a1 = String(document.getElementById('admA1')?.value || '').trim();
          payload.security_q2 = String(document.getElementById('admQ2')?.value || '').trim();
          payload.security_a2 = String(document.getElementById('admA2')?.value || '').trim();
        }
        const token = await ensureCsrf();
        const res = await fetch('../api/admin/auth/update_profile.php', {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': token },
          body: JSON.stringify(payload)
        });
        const data = await res.json().catch(() => null);
        if (!res.ok || !data || data.status !== 'success') {
          throw new Error((data && data.message) ? data.message : 'Save failed');
        }
        toast('Profile updated');
        // Refresh identity on page
        applyAdminIdentity(data.admin || admin);
        closeModal(PROFILE_MODAL_ID);
      } catch (e) {
        toast(e && e.message ? e.message : 'Save failed', 'error');
      }
    });

    document.getElementById('admSendCode')?.addEventListener('click', async () => {
      try {
        const token = await ensureCsrf();
        const res = await fetch('../api/admin/auth/request_password_change.php', {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': token },
          body: JSON.stringify({})
        });
        const data = await res.json().catch(() => null);
        if (!res.ok || !data || data.status !== 'success') {
          throw new Error((data && data.message) ? data.message : 'Failed to send code');
        }
        toast('Verification code sent to email');
      } catch (e) {
        toast(e && e.message ? e.message : 'Failed to send code', 'error');
      }
    });

    document.getElementById('admConfirmPass')?.addEventListener('click', async () => {
      try {
        const code = String(document.getElementById('admCode')?.value || '').trim();
        const new_password = String(document.getElementById('admNewPass')?.value || '');
        if (!code || !new_password) {
          throw new Error('Code and new password are required');
        }
        const token = await ensureCsrf();
        const res = await fetch('../api/admin/auth/confirm_password_change.php', {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': token },
          body: JSON.stringify({ code, new_password })
        });
        const data = await res.json().catch(() => null);
        if (!res.ok || !data || data.status !== 'success') {
          throw new Error((data && data.message) ? data.message : 'Failed to change password');
        }
        toast('Password updated. Please log in again.');
        closeModal(PASS_MODAL_ID);
        // Force to login page (server cleared session)
        setTimeout(() => redirectToAdminLogin(), 700);
      } catch (e) {
        toast(e && e.message ? e.message : 'Failed to change password', 'error');
      }
    });

    // Generic close buttons
    document.addEventListener('click', (e) => {
      const btn = e.target && e.target.closest ? e.target.closest('[data-adm-close]') : null;
      if (!btn) return;
      const id = btn.getAttribute('data-adm-close');
      if (id) closeModal(id);
    });

    // Password visibility toggles inside modals
    document.addEventListener('click', (e) => {
      const btn = e.target && e.target.closest ? e.target.closest('[data-toggle-password]') : null;
      if (!btn) return;
      const id = btn.getAttribute('data-toggle-password');
      const input = document.getElementById(id);
      if (!input) return;
      const toText = input.type === 'password';
      input.type = toText ? 'text' : 'password';
      const icon = btn.querySelector('i');
      if (icon) icon.className = toText ? 'fas fa-eye-slash' : 'fas fa-eye';
    });

    // Bind clicks from dropdown items (Profile / Change password)
    document.addEventListener('click', (e) => {
      const item = e.target && e.target.closest ? e.target.closest('.profile-modal .modal-item') : null;
      if (!item) return;
      const txt = (item.textContent || '').toLowerCase();
      if (txt.includes('profile')) {
        openModal(PROFILE_MODAL_ID);
      } else if (txt.includes('change password')) {
        openModal(PASS_MODAL_ID);
      }
    });
  }

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
      .page-header-actions {
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .admin-bell-wrap {
        position: relative;
        display: inline-flex;
        align-items: center;
      }
      .admin-notify-bell {
        position: relative;
        width: 40px;
        height: 40px;
        border-radius: 12px;
        border: 1px solid var(--medium-gray);
        background: var(--white);
        color: var(--primary-green);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
        cursor: pointer;
      }
      .admin-notify-bell:hover {
        background: var(--light-green);
      }
      .admin-notify-bell .bell-badge {
        position: absolute;
        top: -6px;
        right: -6px;
        min-width: 18px;
        height: 18px;
        padding: 0 4px;
        border-radius: 999px;
        background: #e74c3c;
        color: #fff;
        font-size: 11px;
        font-weight: 700;
        display: none;
        align-items: center;
        justify-content: center;
        line-height: 1;
      }
      .admin-notify-bell.has-count .bell-badge {
        display: inline-flex;
      }
      .admin-report-dropdown {
        position: absolute;
        top: 48px;
        right: 0;
        width: 320px;
        max-width: min(88vw, 360px);
        background: var(--white);
        border: 1px solid var(--medium-gray);
        border-radius: 14px;
        box-shadow: 0 14px 30px rgba(0,0,0,.18);
        padding: 10px;
        display: none;
        z-index: 9999;
      }
      .admin-report-dropdown.open { display: block; }
      .admin-report-dropdown .dropdown-title {
        font-size: 13px;
        font-weight: 600;
        color: var(--text-dark);
        margin-bottom: 8px;
      }
      .admin-report-item {
        display: grid;
        gap: 4px;
        padding: 8px;
        border-radius: 10px;
        background: var(--light-gray);
        margin-bottom: 8px;
      }
      .admin-report-item:last-child { margin-bottom: 0; }
      .admin-report-item .reason {
        font-size: 12px;
        font-weight: 600;
        color: var(--text-dark);
      }
      .admin-report-item .meta {
        font-size: 11px;
        color: var(--dark-gray);
      }
      .admin-report-item .type {
        font-size: 11px;
        color: var(--primary-green);
        font-weight: 600;
      }
      .admin-report-actions {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 8px;
      }
      .admin-report-actions a {
        font-size: 12px;
        color: var(--primary-green);
        text-decoration: none;
        font-weight: 600;
      }
      .admin-report-actions a:hover { text-decoration: underline; }
    `;
    document.head.appendChild(style);
  }

  function createBell(id) {
    const wrap = document.createElement('div');
    wrap.className = 'admin-bell-wrap';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'admin-notify-bell';
    btn.id = id;
    btn.title = 'Reports & Moderation';
    btn.innerHTML = '<i class="fas fa-bell"></i><span class="bell-badge">0</span>';

    const panel = document.createElement('div');
    panel.className = 'admin-report-dropdown';
    panel.innerHTML = '<div class="dropdown-title">Recent reports</div><div class="dropdown-body">Loading...</div>';

    wrap.appendChild(btn);
    wrap.appendChild(panel);
    return wrap;
  }

  function ensureBell() {
    const header = document.querySelector('.page-header') || document.querySelector('.admin-header');
    if (header && !document.getElementById(BELL_ID)) {
      const themeToggle = header.querySelector('#themeToggle');
      if (themeToggle && themeToggle.parentElement) {
        themeToggle.parentElement.insertBefore(createBell(BELL_ID), themeToggle);
      } else {
        let actions = header.querySelector('.page-header-actions');
        if (!actions) {
          actions = document.createElement('div');
          actions.className = 'page-header-actions';
          header.appendChild(actions);
        }
        actions.appendChild(createBell(BELL_ID));
      }
    }

    if (!document.getElementById(BELL_ID)) {
      const themeToggle = document.querySelector('#themeToggle');
      if (themeToggle && themeToggle.parentElement) {
        themeToggle.parentElement.insertBefore(createBell(BELL_ID), themeToggle);
      }
    }

    const mobileActions = document.querySelector('.mobile-actions');
    if (mobileActions && !document.getElementById(MOBILE_BELL_ID)) {
      const mobileToggle = mobileActions.querySelector('#mobileThemeToggle');
      if (mobileToggle) {
        mobileActions.insertBefore(createBell(MOBILE_BELL_ID), mobileToggle);
      } else {
        mobileActions.prepend(createBell(MOBILE_BELL_ID));
      }
    }
  }

  async function refreshCount() {
    const bell = document.getElementById(BELL_ID);
    const bellMobile = document.getElementById(MOBILE_BELL_ID);
    if (!bell && !bellMobile) return;
    try {
      const res = await fetch('../api/admin/reports/count.php', { credentials: 'include' });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data || data.status !== 'success') return;
      let count = Number(data.pending_total || 0);
      // If the list endpoint returns no pending reports, clear the badge
      if (count > 0) {
        const listRes = await fetch('../api/admin/reports/list.php?type=all&status=pending&limit=1', { credentials: 'include' });
        const listData = await listRes.json().catch(() => null);
        if (listRes.ok && listData && listData.status === 'success') {
          const items = Array.isArray(listData.reports) ? listData.reports : [];
          if (items.length === 0) count = 0;
        }
      }
      [bell, bellMobile].forEach((el) => {
        if (!el) return;
        const badge = el.querySelector('.bell-badge');
        if (!badge) return;
        badge.textContent = count > 99 ? '99+' : String(count);
        el.classList.toggle('has-count', count > 0);
      });
    } catch (_) {
      // silent
    }
  }

  async function loadReportPreview(panel) {
    if (!panel) return;
    const body = panel.querySelector('.dropdown-body');
    if (!body) return;
    body.textContent = 'Loading...';
    try {
      const res = await fetch('../api/admin/reports/list.php?type=all&status=pending&limit=5', { credentials: 'include' });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data || data.status !== 'success') {
        body.textContent = 'Unable to load reports.';
        return;
      }
      const list = Array.isArray(data.reports) ? data.reports : [];
      if (!list.length) {
        body.innerHTML = '<div class="admin-report-item"><div class="reason">No pending reports</div><div class="meta">You are all caught up.</div></div>';
      } else {
        body.innerHTML = list.map((r) => `
          <div class="admin-report-item">
            <div class="reason">${escapeHtml(r.reason || 'Report')}</div>
            <div class="meta">${escapeHtml(r.reporter || 'Reporter')} -> ${escapeHtml(r.reported_display || r.reported || '')}</div>
            <div class="type">${escapeHtml(r.type || 'report')}</div>
          </div>
        `).join('');
      }
      const actions = document.createElement('div');
      actions.className = 'admin-report-actions';
      actions.innerHTML = `<a href="reports.html">Show more</a>`;
      body.appendChild(actions);
    } catch (_) {
      body.textContent = 'Unable to load reports.';
    }
  }

  function escapeHtml(v) {
    return String(v ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
  }

  function bindDropdown(id) {
    const wrap = document.getElementById(id)?.closest('.admin-bell-wrap');
    if (!wrap) return;
    const btn = wrap.querySelector('.admin-notify-bell');
    const panel = wrap.querySelector('.admin-report-dropdown');
    if (!btn || !panel) return;
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      const isOpen = panel.classList.contains('open');
      document.querySelectorAll('.admin-report-dropdown.open').forEach((el) => el.classList.remove('open'));
      if (!isOpen) {
        panel.classList.add('open');
        await loadReportPreview(panel);
      }
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    // Load admin identity + permissions once, then:
    // - update sidebar profile info
    // - hide menu items that the admin isn't allowed to access
    // - bind profile/password actions
    fetchAdminMe()
      .then((admin) => {
        applyAdminIdentity(admin);
        applyMenuVisibility(admin);
        bindProfileActions(admin);
        revealAdminPage();
        // Unhide menu only after permissions are applied (prevents "flash of unauthorized menu").
        document.body.classList.add('admin-menus-ready');
      })
      .catch(() => { /* handled by fetchAdminMe redirect */ });

    // Logout should log out admin session only (not the whole app).
    // Capture phase: override per-page dummy handlers.
    document.addEventListener('click', async (e) => {
      const btn = e.target && e.target.closest ? e.target.closest('#logoutBtn') : null;
      if (!btn) return;
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      try {
        const csrfRes = await fetch('../api/auth/csrf.php', { credentials: 'include' });
        const csrfData = await csrfRes.json().catch(() => ({}));
        const token = String(csrfData?.csrf_token || '');
        await fetch('../api/admin/auth/logout.php', {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': token },
          body: JSON.stringify({})
        });
      } catch (_) { /* ignore */ }
      redirectToAdminLogin();
    }, true);

    injectStyles();
    ensureBell();
    refreshCount();
    bindDropdown(BELL_ID);
    bindDropdown(MOBILE_BELL_ID);
    document.addEventListener('click', (e) => {
      const target = e.target;
      if (!target) return;
      const open = document.querySelector('.admin-report-dropdown.open');
      if (open && !open.closest('.admin-bell-wrap')?.contains(target)) {
        open.classList.remove('open');
      }
    });
    setInterval(refreshCount, 60000);
  });
})();

