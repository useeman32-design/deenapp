(function () {
    const API = {
        csrf: '../api/auth/csrf.php',
        overview: '../api/deenai/admin/overview.php',
        datasets: '../api/deenai/admin/datasets.php',
        upload: '../api/deenai/admin/upload_dataset_file.php',
        providers: '../api/deenai/admin/provider_keys.php'
    };

    let csrfToken = '';
    let datasetsCache = [];
    let providersCache = [];

    const toastHost = document.createElement('div');
    toastHost.style.cssText = 'position:fixed;top:16px;right:16px;display:flex;flex-direction:column;gap:8px;z-index:120000;';
    document.body.appendChild(toastHost);

    function notify(message, kind = 'info') {
        const bg = kind === 'error' ? '#c0392b' : kind === 'success' ? '#1D6F42' : '#2c3e50';
        const node = document.createElement('div');
        node.style.cssText = `background:${bg};color:#fff;padding:10px 12px;border-radius:10px;font-size:13px;box-shadow:0 8px 20px rgba(0,0,0,.2);max-width:340px;`;
        node.textContent = String(message || '');
        toastHost.appendChild(node);
        setTimeout(() => {
            node.style.transition = 'opacity .2s ease';
            node.style.opacity = '0';
            setTimeout(() => node.remove(), 240);
        }, 2600);
    }

    function q(id) {
        return document.getElementById(id);
    }

    async function getCsrfToken() {
        if (csrfToken) return csrfToken;
        const res = await fetch(API.csrf, { credentials: 'include' });
        const data = await res.json();
        csrfToken = data.csrf_token || '';
        return csrfToken;
    }

    async function apiJson(url, method = 'GET', body = null) {
        const headers = { Accept: 'application/json' };
        if (method !== 'GET') {
            headers['Content-Type'] = 'application/json';
            headers['X-CSRF-Token'] = await getCsrfToken();
        }
        const res = await fetch(url, {
            method,
            credentials: 'include',
            headers,
            body: body ? JSON.stringify(body) : null
        });
        const data = await res.json().catch(() => ({ status: 'error', message: 'Invalid server response' }));
        if (!res.ok || data.status === 'error') {
            throw new Error(data.message || `Request failed (${res.status})`);
        }
        return data;
    }

    async function apiUpload(file, datasetType) {
        const token = await getCsrfToken();
        const fd = new FormData();
        fd.append('dataset_file', file);
        fd.append('dataset_type', String(datasetType || '').trim().toLowerCase());
        const res = await fetch(API.upload, {
            method: 'POST',
            credentials: 'include',
            headers: { 'X-CSRF-Token': token },
            body: fd
        });
        const data = await res.json().catch(() => ({ status: 'error', message: 'Invalid upload response' }));
        if (!res.ok || data.status === 'error') {
            throw new Error(data.message || 'Upload failed');
        }
        return data;
    }

    function sectionRowTemplate(section = { section_title: '', start_marker: '', end_marker: '' }) {
        const row = document.createElement('div');
        row.className = 'ai-section-row';
        row.style.cssText = 'display:grid;grid-template-columns:1fr 1fr 1fr auto;gap:8px;';
        row.innerHTML = `
            <input class="limit-input ai-section-title" placeholder="Section title" value="${escapeHtml(section.section_title || '')}" />
            <input class="limit-input ai-section-start" placeholder="Start marker" value="${escapeHtml(section.start_marker || '')}" />
            <input class="limit-input ai-section-end" placeholder="End marker" value="${escapeHtml(section.end_marker || '')}" />
            <button class="action-btn danger ai-remove-section"><i class="fas fa-times"></i></button>
        `;
        row.querySelector('.ai-remove-section').addEventListener('click', () => row.remove());
        return row;
    }

    function collectSections() {
        return Array.from(document.querySelectorAll('#aiDatasetSections .ai-section-row')).map((row) => ({
            section_title: row.querySelector('.ai-section-title')?.value?.trim() || '',
            start_marker: row.querySelector('.ai-section-start')?.value?.trim() || '',
            end_marker: row.querySelector('.ai-section-end')?.value?.trim() || ''
        })).filter((x) => x.section_title !== '');
    }

    function clearDatasetForm() {
        q('aiDatasetId').value = '';
        q('aiDatasetName').value = '';
        q('aiDatasetKind').value = 'quran';
        q('aiStorageType').value = 'json';
        q('aiDatasetPath').value = '';
        q('aiDatasetKeywords').value = '';
        q('aiDatasetDescription').value = '';
        q('aiDatasetActive').checked = true;
        q('aiDatasetSections').innerHTML = '';
        if (q('aiUploadedPath')) q('aiUploadedPath').textContent = '';
        if (q('aiDatasetUploadFile')) q('aiDatasetUploadFile').value = '';
        updateDatasetPathHint();
    }

    function fillDatasetForm(item) {
        q('aiDatasetId').value = String(item.id || '');
        q('aiDatasetName').value = item.name || '';
        q('aiDatasetKind').value = item.type || 'quran';
        q('aiStorageType').value = item.storage_type || 'json';
        q('aiDatasetPath').value = item.file_path || '';
        q('aiDatasetKeywords').value = item.keywords || '';
        q('aiDatasetDescription').value = item.description || '';
        q('aiDatasetActive').checked = !!item.active;
        q('aiDatasetSections').innerHTML = '';
        (item.sections || []).forEach((section) => q('aiDatasetSections').appendChild(sectionRowTemplate(section)));
        if (q('aiUploadedPath')) q('aiUploadedPath').textContent = item.file_path ? `Dataset path: ${item.file_path}` : '';
        updateDatasetPathHint();
    }

    function updateDatasetPathHint() {
        const type = (q('aiDatasetKind')?.value || 'quran').trim().toLowerCase();
        const node = q('aiDatasetBasePath');
        if (!node) return;
        node.textContent = `Upload destination: datasets_import/${type}/`;
    }

    function renderDatasetsTable() {
        const body = q('aiDatasetsTableBody');
        if (!body) return;
        const locationFilter = (q('aiDatasetLocationFilter')?.value || 'all').toLowerCase();
        const rows = datasetsCache.filter((d) => {
            if (locationFilter === 'centralized') return isDatasetCentralizedPath(d.file_path || '');
            if (locationFilter === 'legacy') return !isDatasetCentralizedPath(d.file_path || '');
            return true;
        });

        body.innerHTML = rows.map((d) => `
            <tr>
                <td>${escapeHtml(d.name || '')}</td>
                <td><span class="badge">${escapeHtml(d.type || '')}</span></td>
                <td>${escapeHtml(d.storage_type || '')}</td>
                <td title="${escapeHtml(d.file_path || '')}">${escapeHtml((d.file_path || '').slice(0, 44))}</td>
                <td>${renderKeywordsCell(d.keywords || '')}</td>
                <td>${renderDatasetLocationBadge(d.file_path || '')}</td>
                <td>${d.active ? 'Yes' : 'No'}</td>
                <td style="display:flex;gap:6px;flex-wrap:wrap;">
                    <button class="action-btn" data-action="edit" data-id="${d.id}"><i class="fas fa-pen"></i> Edit</button>
                    <button class="action-btn primary" data-action="add-keyword" data-id="${d.id}"><i class="fas fa-tags"></i> +Keyword</button>
                    <button class="action-btn ${d.active ? 'warning' : 'success'}" data-action="toggle" data-id="${d.id}">
                        <i class="fas ${d.active ? 'fa-toggle-on' : 'fa-toggle-off'}"></i> ${d.active ? 'Disable' : 'Enable'}
                    </button>
                    <button class="action-btn danger" data-action="delete" data-id="${d.id}"><i class="fas fa-trash"></i> Delete</button>
                </td>
            </tr>
        `).join('');

        body.querySelectorAll('button[data-action]').forEach((btn) => {
            btn.addEventListener('click', async () => {
                const id = Number(btn.dataset.id || 0);
                const action = btn.dataset.action || '';
                const item = datasetsCache.find((x) => Number(x.id) === id);
                if (!item) return;
                try {
                    if (action === 'edit') {
                        fillDatasetForm(item);
                        window.scrollTo({ top: q('aiDatasetManager').offsetTop - 70, behavior: 'smooth' });
                        return;
                    }
                    if (action === 'toggle') {
                        await apiJson(API.datasets, 'POST', { action: 'toggle', id, active: !item.active });
                        notify('Dataset status updated', 'success');
                        await loadDatasets();
                        return;
                    }
                    if (action === 'add-keyword') {
                        const incoming = prompt('Add keyword(s), comma-separated', '');
                        if (incoming === null) return;
                        const mergedKeywords = mergeKeywords(item.keywords || '', incoming);
                        if (!mergedKeywords) {
                            notify('No valid keyword entered', 'error');
                            return;
                        }
                        await apiJson(API.datasets, 'POST', {
                            action: 'save',
                            id: Number(item.id || 0),
                            name: item.name || '',
                            type: item.type || 'faq',
                            storage_type: item.storage_type || 'json',
                            file_path: item.file_path || '',
                            keywords: mergedKeywords,
                            description: item.description || '',
                            active: !!item.active,
                            sections: Array.isArray(item.sections) ? item.sections : []
                        });
                        notify('Keywords updated', 'success');
                        await loadDatasets();
                        return;
                    }
                    if (action === 'delete') {
                        if (!confirm(`Delete dataset "${item.name}"?`)) return;
                        await apiJson(API.datasets, 'POST', { action: 'delete', id });
                        notify('Dataset deleted', 'success');
                        await loadDatasets();
                    }
                } catch (err) {
                    notify(err.message || 'Action failed', 'error');
                }
            });
        });
    }

    function renderDatasetLocationBadge(filePath) {
        const isCentralized = isDatasetCentralizedPath(filePath);
        if (isCentralized) {
            return '<span class="status-badge success">Centralized</span>';
        }
        return '<span class="status-badge warning">Legacy Path</span>';
    }

    function isDatasetCentralizedPath(filePath) {
        const normalized = String(filePath || '').replaceAll('\\', '/').toLowerCase();
        return normalized.startsWith('datasets_import/');
    }

    function parseKeywords(raw) {
        return String(raw || '')
            .split(',')
            .map((x) => x.trim())
            .filter(Boolean);
    }

    function mergeKeywords(existing, incoming) {
        const base = parseKeywords(existing);
        const add = parseKeywords(incoming);
        const merged = [];
        const seen = new Set();
        [...base, ...add].forEach((k) => {
            const low = k.toLowerCase();
            if (seen.has(low)) return;
            seen.add(low);
            merged.push(k);
        });
        return merged.join(', ');
    }

    function renderKeywordsCell(raw) {
        const keywords = parseKeywords(raw);
        if (!keywords.length) {
            return '<span style="color:var(--dark-gray);font-size:.8rem;">None</span>';
        }
        const display = keywords.slice(0, 4).map((k) =>
            `<span style="display:inline-flex;align-items:center;padding:2px 8px;margin:2px;border-radius:12px;background:var(--light-green);font-size:.72rem;">${escapeHtml(k)}</span>`
        ).join('');
        const extra = keywords.length > 4 ? `<span style="font-size:.72rem;color:var(--dark-gray);">+${keywords.length - 4}</span>` : '';
        return `<div title="${escapeHtml(keywords.join(', '))}" style="max-width:220px;display:flex;flex-wrap:wrap;gap:2px;">${display}${extra}</div>`;
    }

    function renderProvidersTable() {
        const body = q('aiProvidersTableBody');
        if (!body) return;
        body.innerHTML = providersCache.map((p) => `
            <tr>
                <td>${escapeHtml(p.provider_name || '')}</td>
                <td>${escapeHtml(p.model_name || '')}</td>
                <td>${escapeHtml(p.api_key_masked || '')}</td>
                <td>${p.active ? 'Yes' : 'No'}</td>
            </tr>
        `).join('');
    }

    async function loadOverview() {
        try {
            const data = await apiJson(API.overview);
            const stats = data.stats || {};
            if (q('totalResponses')) q('totalResponses').textContent = Number(stats.totalResponses || 0).toLocaleString();
            if (q('activeUsers')) q('activeUsers').textContent = Number(stats.activeUsersToday || 0).toLocaleString();
            if (q('avgResponse')) q('avgResponse').textContent = `${Math.max(0, Number(stats.avgResponseMs || 0))}ms`;
            if (q('bannedUsers')) q('bannedUsers').textContent = Number(stats.bannedUsers || 0).toLocaleString();

            const logsBody = q('logsTableBody');
            if (logsBody) {
                const logs = Array.isArray(data.logs) ? data.logs : [];
                logsBody.innerHTML = logs.map((log) => `
                    <tr>
                        <td>${escapeHtml(log.time || '')}</td>
                        <td>${escapeHtml(log.user || '')}</td>
                        <td><span class="badge">${escapeHtml(log.type || '')}</span></td>
                        <td>${escapeHtml((log.query || '').slice(0, 90))}</td>
                        <td>${escapeHtml(log.status || '')}</td>
                        <td>${escapeHtml(log.responseTime || '')}</td>
                        <td>${escapeHtml(log.provider || (log.cache_hit ? 'cache' : ''))}</td>
                    </tr>
                `).join('');
            }
        } catch (err) {
            notify(err.message || 'Failed to load AI overview', 'error');
        }
    }

    async function loadDatasets() {
        const data = await apiJson(API.datasets);
        datasetsCache = Array.isArray(data.datasets) ? data.datasets : [];
        renderDatasetsTable();
    }

    async function loadProviders() {
        const data = await apiJson(API.providers);
        providersCache = Array.isArray(data.providers) ? data.providers : [];
        renderProvidersTable();
    }

    function bindDatasetActions() {
        updateDatasetPathHint();
        q('aiDatasetLocationFilter')?.addEventListener('change', renderDatasetsTable);
        q('aiDatasetKind')?.addEventListener('change', () => {
            updateDatasetPathHint();
            // Clear uploaded path for new records when category changes.
            if (!q('aiDatasetId')?.value) {
                q('aiDatasetPath').value = '';
                if (q('aiUploadedPath')) q('aiUploadedPath').textContent = '';
            }
        });

        q('aiAddSectionBtn')?.addEventListener('click', () => {
            q('aiDatasetSections').appendChild(sectionRowTemplate());
        });
        q('aiClearDatasetFormBtn')?.addEventListener('click', clearDatasetForm);

        q('aiSaveDatasetBtn')?.addEventListener('click', async () => {
            const payload = {
                action: 'save',
                id: Number(q('aiDatasetId').value || 0) || undefined,
                name: q('aiDatasetName').value.trim(),
                type: q('aiDatasetKind').value,
                storage_type: q('aiStorageType').value,
                file_path: q('aiDatasetPath').value.trim(),
                keywords: q('aiDatasetKeywords').value.trim(),
                description: q('aiDatasetDescription').value.trim(),
                active: q('aiDatasetActive').checked,
                sections: collectSections()
            };
            if (!payload.name || !payload.file_path) {
                notify('Dataset name and uploaded file are required', 'error');
                return;
            }
            try {
                await apiJson(API.datasets, 'POST', payload);
                notify('Dataset saved', 'success');
                clearDatasetForm();
                await loadDatasets();
            } catch (err) {
                notify(err.message || 'Failed to save dataset', 'error');
            }
        });

        q('aiUploadDatasetFileBtn')?.addEventListener('click', async () => {
            const file = q('aiDatasetUploadFile')?.files?.[0];
            const datasetType = (q('aiDatasetKind')?.value || '').trim().toLowerCase();
            if (!file) {
                notify('Select a JSON or TXT file to upload', 'error');
                return;
            }
            if (!datasetType) {
                notify('Select dataset type first', 'error');
                return;
            }
            try {
                const data = await apiUpload(file, datasetType);
                q('aiUploadedPath').textContent = `Uploaded path: ${data.file_path || ''}`;
                q('aiDatasetPath').value = data.file_path || '';
                q('aiStorageType').value = (data.storage_type || ((data.file_path || '').toLowerCase().endsWith('.txt') ? 'txt' : 'json'));
                notify('File uploaded successfully', 'success');
            } catch (err) {
                notify(err.message || 'Upload failed', 'error');
            }
        });
    }

    function bindProviderActions() {
        const providerSelect = q('aiProviderName');
        const providerModel = q('aiProviderModel');
        const providerActive = q('aiProviderActive');
        const providerKey = q('aiProviderKey');
        const saveProviderBtn = q('aiSaveProviderBtn');
        const deleteProviderBtn = q('aiDeleteProviderBtn');
        if (!providerSelect || !providerModel || !providerActive || !providerKey) return;

        const syncProviderForm = () => {
            const provider = providerSelect?.value || '';
            const row = providersCache.find((p) => p.provider_name === provider);
            if (!row) {
                providerModel.value = '';
                providerActive.checked = true;
                return;
            }
            providerModel.value = row.model_name || '';
            providerActive.checked = !!row.active;
        };

        providerSelect?.addEventListener('change', syncProviderForm);

        saveProviderBtn?.addEventListener('click', async () => {
            const payload = {
                action: 'save',
                provider_name: providerSelect.value,
                api_key: providerKey.value.trim(),
                model_name: providerModel.value.trim(),
                active: providerActive.checked
            };
            try {
                await apiJson(API.providers, 'POST', payload);
                providerKey.value = '';
                notify('Provider settings saved', 'success');
                await loadProviders();
            } catch (err) {
                notify(err.message || 'Failed to save provider', 'error');
            }
        });

        deleteProviderBtn?.addEventListener('click', async () => {
            const provider = providerSelect.value;
            if (!confirm(`Remove ${provider} provider key?`)) return;
            try {
                await apiJson(API.providers, 'POST', { action: 'delete', provider_name: provider });
                notify('Provider removed', 'success');
                await loadProviders();
            } catch (err) {
                notify(err.message || 'Failed to remove provider', 'error');
            }
        });

        setTimeout(syncProviderForm, 0);
    }

    function escapeHtml(value) {
        return String(value || '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }

    async function boot() {
        bindDatasetActions();
        bindProviderActions();
        try {
            await Promise.all([loadOverview(), loadDatasets(), loadProviders()]);
        } catch (err) {
            notify(err.message || 'Failed to load AI manager data', 'error');
        }
    }

    document.addEventListener('DOMContentLoaded', boot);
})();
