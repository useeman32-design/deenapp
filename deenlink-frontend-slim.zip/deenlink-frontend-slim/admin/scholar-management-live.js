﻿(function() {
    const pageLoader = document.getElementById('pageLoader');
    const body = document.body;
    const lightBtn = document.getElementById('lightThemeBtn');
    const darkBtn = document.getElementById('darkThemeBtn');
    const mobileThemeToggle = document.getElementById('mobileThemeToggle');
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('adminSidebar');
    const overlay = document.getElementById('sidebarOverlay');
    const desktopIcon = document.getElementById('desktopProfileIcon');
    const mobileIcon = document.getElementById('mobileProfileIcon');
    const profileModal = document.getElementById('profileModal');

    const scholarsGrid = document.getElementById('scholarsGrid');
    const searchInput = document.getElementById('searchInput');
    const statusFilter = document.getElementById('statusFilter');
    const sortFilter = document.getElementById('sortFilter');
    const countryFilter = document.getElementById('countryFilter');
    const aqeedahFilter = document.getElementById('aqeedahFilter');
    const clearFilters = document.getElementById('clearFilters');
    const scholarLevelGuide = document.getElementById('scholarLevelGuide');
    const scholarLevelsCountEl = document.getElementById('scholarLevelsCount');
    const newScholarLevelName = document.getElementById('newScholarLevelName');
    const newScholarLevelIcon = document.getElementById('newScholarLevelIcon');
    const addScholarLevelBtn = document.getElementById('addScholarLevelBtn');

    const scholarModal = document.getElementById('scholarModal');
    const scholarModalBody = document.getElementById('scholarModalBody');
    const closeScholarModal = document.getElementById('closeScholarModal');
    const modalScholarName = document.getElementById('modalScholarName');

    const confirmModal = document.getElementById('confirmModal');
    const confirmCancel = document.getElementById('confirmCancel');
    const confirmAction = document.getElementById('confirmAction');
    const confirmTitle = document.getElementById('confirmTitle');
    const confirmMessage = document.getElementById('confirmMessage');

    const reasonModal = document.getElementById('reasonModal');
    const reasonModalTitle = document.getElementById('reasonModalTitle');
    const reasonInput = document.getElementById('reasonInput');
    const closeReasonModal = document.getElementById('closeReasonModal');
    const cancelReasonBtn = document.getElementById('cancelReasonBtn');
    const submitReasonBtn = document.getElementById('submitReasonBtn');

    const resetModal = document.getElementById('resetModal');
    const closeResetModal = document.getElementById('closeResetModal');
    const cancelResetBtn = document.getElementById('cancelResetBtn');
    const saveResetBtn = document.getElementById('saveResetBtn');
    const newPassword = document.getElementById('newPassword');
    const confirmPassword = document.getElementById('confirmPassword');

    const pointsModal = document.getElementById('pointsModal');
    const closePointsModal = document.getElementById('closePointsModal');
    const cancelPointsModal = document.getElementById('cancelPointsModal');
    const savePointsAdjustment = document.getElementById('savePointsAdjustment');
    const currentPointsDisplay = document.getElementById('currentPointsDisplay');
    const pointsAdjustment = document.getElementById('pointsAdjustment');
    const pointsReason = document.getElementById('pointsReason');

    const messageModal = document.getElementById('messageModal');
    const closeMessageModal = document.getElementById('closeMessageModal');
    const cancelMessageModal = document.getElementById('cancelMessageModal');
    const sendMessageBtn = document.getElementById('sendMessageBtn');
    const messageSubject = document.getElementById('messageSubject');
    const messageBody = document.getElementById('messageBody');
    const messageType = document.getElementById('messageType');

    const activityModal = document.getElementById('activityModal');
    const activityModalTitle = document.getElementById('activityModalTitle');
    const activityModalBody = document.getElementById('activityModalBody');
    const closeActivityModal = document.getElementById('closeActivityModal');

    const postsModal = document.getElementById('postsModal');
    const postsModalTitle = document.getElementById('postsModalTitle');
    const postsModalBody = document.getElementById('postsModalBody');
    const closePostsModal = document.getElementById('closePostsModal');

    const imageViewerModal = document.getElementById('imageViewerModal');
    const viewerImage = document.getElementById('viewerImage');
    const closeImageViewer = document.getElementById('closeImageViewer');

    const approveModal = document.getElementById('approveModal');
    const closeApproveModal = document.getElementById('closeApproveModal');
    const cancelApproveBtn = document.getElementById('cancelApproveBtn');
    const submitApproveBtn = document.getElementById('submitApproveBtn');
    const approveCurrentAqeedah = document.getElementById('approveCurrentAqeedah');
    const approveAqeedahInput = document.getElementById('approveAqeedahInput');
    const approveLevelOptions = document.getElementById('approveLevelOptions');

    const totalScholarsEl = document.getElementById('totalScholars');
    const pendingScholarsEl = document.getElementById('pendingScholars');

    const usersApiBase = '../api/admin/users';
    const scholarsApiBase = '../api/admin/scholars';

    let csrfToken = '';
    let scholars = [];
    let currentUserId = 0;
    let pendingAction = null;
    let pendingReasonAction = null;
    let pendingApproveScholar = null;
    let selectedApproveLevel = '';
    let currentPostsModalUser = null;
    let currentPostsModalData = [];
    let postsSearchTerm = '';

    const BASE_LEVEL_CONFIG = [
        { value: 'student_of_knowledge', label: 'Student of Knowledge', icon: 'fa-user-graduate' },
        { value: 'sheikh', label: 'Sheikh', icon: 'fa-star-and-crescent' },
        { value: 'scholar', label: 'Scholar', icon: 'fa-book-open-reader' },
        { value: 'mufti', label: 'Mufti', icon: 'fa-scale-balanced' },
        { value: 'alim', label: 'Alim', icon: 'fa-mosque' }
    ];
    let levelConfig = [...BASE_LEVEL_CONFIG];

    const toastHost = document.createElement('div');
    toastHost.style.cssText = 'position:fixed;top:16px;right:16px;display:flex;flex-direction:column;gap:8px;z-index:120000;';
    document.body.appendChild(toastHost);

    function notify(message, kind = 'info') {
        const bg = kind === 'error' ? '#c0392b' : kind === 'success' ? '#1D6F42' : '#2c3e50';
        const item = document.createElement('div');
        item.style.cssText = `background:${bg};color:#fff;padding:10px 12px;border-radius:10px;font-size:13px;box-shadow:0 8px 20px rgba(0,0,0,.2);max-width:320px;`;
        item.textContent = String(message || 'Done');
        toastHost.appendChild(item);
        setTimeout(() => {
            item.style.opacity = '0';
            item.style.transition = 'opacity .2s ease';
            setTimeout(() => item.remove(), 220);
        }, 2200);
    }

    function setButtonBusy(button, busy, busyLabel) {
        if (!button) return;
        if (!button.dataset.originalLabel) button.dataset.originalLabel = button.innerHTML;
        button.disabled = !!busy;
        button.innerHTML = busy
            ? `<i class="fas fa-spinner fa-spin" style="margin-right:8px;"></i>${busyLabel || 'Saving...'}`
            : button.dataset.originalLabel;
    }

    function promptForEmailChange(title, currentEmail) {
        return new Promise((resolve) => {
            const overlay = document.createElement('div');
            overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.58);display:flex;align-items:center;justify-content:center;z-index:130000;padding:16px;';
            overlay.innerHTML = `
                <div style="background:#fff;width:100%;max-width:460px;border-radius:16px;box-shadow:0 18px 48px rgba(0,0,0,.28);overflow:hidden;">
                    <div style="padding:18px 20px;border-bottom:1px solid #eef2f7;display:flex;align-items:center;justify-content:space-between;">
                        <div style="font-weight:700;font-size:1rem;color:#123;">${escapeHtml(title || 'Change Email')}</div>
                        <button type="button" data-close style="background:none;border:none;font-size:20px;cursor:pointer;color:#6b7280;"><i class="fas fa-times"></i></button>
                    </div>
                    <div style="padding:20px;">
                        <label style="display:block;font-size:13px;font-weight:600;color:#4b5563;margin-bottom:8px;">New email address</label>
                        <input type="email" id="adminScholarEmailChangeInput" value="${escapeHtml(currentEmail || '')}" style="width:100%;border:1px solid #d7dde6;border-radius:12px;padding:12px 14px;font-size:14px;outline:none;">
                        <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px;">
                            <button type="button" data-cancel style="border:1px solid #d7dde6;background:#fff;color:#374151;border-radius:10px;padding:10px 16px;cursor:pointer;">Cancel</button>
                            <button type="button" data-save style="border:none;background:#1D6F42;color:#fff;border-radius:10px;padding:10px 16px;cursor:pointer;">Save Email</button>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(overlay);
            const input = overlay.querySelector('#adminScholarEmailChangeInput');
            const close = (value = null) => {
                overlay.remove();
                resolve(value);
            };
            overlay.querySelector('[data-close]')?.addEventListener('click', () => close(null));
            overlay.querySelector('[data-cancel]')?.addEventListener('click', () => close(null));
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) close(null);
            });
            overlay.querySelector('[data-save]')?.addEventListener('click', () => close(String(input?.value || '').trim()));
            setTimeout(() => input?.focus(), 30);
        });
    }

    // =========================
    // Login Activity (Scholars)
    // =========================
    let loginActivityTimer = null;

    function formatLoginEvent(type) {
        const t = String(type || '');
        if (t === 'login_success') return 'Login (success)';
        if (t === 'login_fail') return 'Login (failed)';
        if (t === 'logout') return 'Logout';
        return t || 'Event';
    }

    async function loadLoginActivity() {
        const bodyEl = document.getElementById('loginActivityBody');
        const loadingEl = document.getElementById('loginActivityLoading');
        const q = String(document.getElementById('loginActivitySearch')?.value || '').trim();
        if (!bodyEl) return;
        if (loadingEl) loadingEl.style.display = 'block';
        try {
            const qs = new URLSearchParams();
            qs.set('scope', 'scholars');
            qs.set('limit', '120');
            if (q) qs.set('q', q);
            const data = await apiRequest(usersApiBase, `/login_activity.php?${qs.toString()}`, { method: 'GET' });
            const items = Array.isArray(data.items) ? data.items : [];
            if (!items.length) {
                bodyEl.innerHTML = `<tr><td colspan="6" style="padding: 14px; color: var(--dark-gray);">No login activity found.</td></tr>`;
                return;
            }
            bodyEl.innerHTML = items.map((it) => {
                const name = it.full_name ? escapeHtml(it.full_name) : (it.username ? '@' + escapeHtml(it.username) : 'Unknown');
                const event = escapeHtml(formatLoginEvent(it.event_type));
                const ip = escapeHtml(it.ip || '');
                const ident = escapeHtml(it.identifier || '');
                const ua = escapeHtml(it.user_agent || '');
                const time = escapeHtml(it.time_ago || it.created_at || '');
                const badgeColor = it.event_type === 'login_success' ? 'var(--primary-green)' : (it.event_type === 'login_fail' ? 'var(--danger)' : '#2c3e50');
                return `
                    <tr style="border-top: 1px solid rgba(0,0,0,0.06);">
                        <td style="padding: 12px 14px; white-space: nowrap;">${time}</td>
                        <td style="padding: 12px 14px; font-weight: 600;">${name}</td>
                        <td style="padding: 12px 14px;">
                            <span style="display:inline-flex; align-items:center; gap:8px;">
                                <span style="width:8px;height:8px;border-radius:50%;background:${badgeColor};display:inline-block;"></span>
                                ${event}
                            </span>
                        </td>
                        <td style="padding: 12px 14px; font-family: monospace;">${ip}</td>
                        <td style="padding: 12px 14px; font-family: monospace;">${ident}</td>
                        <td style="padding: 12px 14px; color: var(--dark-gray);">${ua}</td>
                    </tr>
                `;
            }).join('');
        } catch (err) {
            bodyEl.innerHTML = `<tr><td colspan="6" style="padding: 14px; color: var(--danger);">Failed to load login activity.</td></tr>`;
        } finally {
            if (loadingEl) loadingEl.style.display = 'none';
        }
    }

    function showPageLoader() {
        if (!pageLoader) return;
        pageLoader.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function hidePageLoader() {
        if (!pageLoader) return;
        pageLoader.classList.remove('active');
        document.body.style.overflow = 'auto';
    }

    document.addEventListener('click', function(e) {
        const anchor = e.target.closest('a');
        if (!anchor) return;
        const href = anchor.getAttribute('href');
        if (!href || href.startsWith('#') || href.startsWith('javascript:')) return;
        e.preventDefault();
        showPageLoader();
        setTimeout(() => { window.location.href = href; }, 800);
    });
    window.addEventListener('load', hidePageLoader);
    setTimeout(() => { if (document.readyState === 'complete') hidePageLoader(); }, 100);

    if (menuToggle) {
        menuToggle.addEventListener('click', () => {
            sidebar.classList.add('open');
            overlay.classList.add('active');
        });
    }
    if (overlay) {
        overlay.addEventListener('click', () => {
            sidebar.classList.remove('open');
            overlay.classList.remove('active');
        });
    }

    function setTheme(theme) {
        if (theme === 'dark') {
            body.classList.add('dark-theme');
            if (lightBtn) lightBtn.classList.remove('active-theme');
            if (darkBtn) darkBtn.classList.add('active-theme');
            if (mobileThemeToggle) mobileThemeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        } else {
            body.classList.remove('dark-theme');
            if (lightBtn) lightBtn.classList.add('active-theme');
            if (darkBtn) darkBtn.classList.remove('active-theme');
            if (mobileThemeToggle) mobileThemeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        }
        localStorage.setItem('isDarkMode', theme === 'dark');
    }
    if (lightBtn) lightBtn.addEventListener('click', () => setTheme('light'));
    if (darkBtn) darkBtn.addEventListener('click', () => setTheme('dark'));
    if (mobileThemeToggle) {
        mobileThemeToggle.addEventListener('click', () => {
            body.classList.contains('dark-theme') ? setTheme('light') : setTheme('dark');
        });
    }
    setTheme(localStorage.getItem('isDarkMode') === 'true' ? 'dark' : 'light');

    function toggleProfileModal(e) {
        e.stopPropagation();
        profileModal.classList.toggle('show');
    }
    if (desktopIcon) desktopIcon.addEventListener('click', toggleProfileModal);
    if (mobileIcon) mobileIcon.addEventListener('click', toggleProfileModal);

    document.addEventListener('click', (e) => {
        if (!profileModal.contains(e.target) && !desktopIcon?.contains(e.target) && !mobileIcon?.contains(e.target)) {
            profileModal.classList.remove('show');
        }
    });

    document.getElementById('logoutBtn')?.addEventListener('click', () => {
        profileModal.classList.remove('show');
    });

    function escapeHtml(value) {
        return String(value ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }

    function avatarFor(scholar) {
        if (scholar.avatar) return scholar.avatar;
        const seed = encodeURIComponent(scholar.name || scholar.username || 'Scholar');
        return `https://ui-avatars.com/api/?name=${seed}&background=1D6F42&color=fff&size=56`;
    }

    function getCsrfToken() {
        if (csrfToken) return Promise.resolve(csrfToken);
        return fetch('../api/auth/csrf.php', { credentials: 'include' })
            .then((res) => res.json())
            .then((data) => {
                csrfToken = data.csrf_token || '';
                return csrfToken;
            });
    }

    async function apiRequest(base, path, options = {}) {
        const opts = {
            credentials: 'include',
            headers: {
                Accept: 'application/json',
                ...(options.headers || {})
            },
            ...options
        };
        const method = (opts.method || 'GET').toUpperCase();
        if (!['GET', 'HEAD', 'OPTIONS'].includes(method)) {
            const token = await getCsrfToken();
            opts.headers['X-CSRF-Token'] = token;
            if (!opts.headers['Content-Type']) {
                opts.headers['Content-Type'] = 'application/json';
            }
        }

        const res = await fetch(`${base}${path}`, opts);
        const data = await res.json().catch(() => ({ status: 'error', message: 'Invalid server response' }));
        if (!res.ok || data.status === 'error') {
            throw new Error(data.message || `Request failed (${res.status})`);
        }
        return data;
    }

    function findScholarByUserId(userId) {
        return scholars.find((s) => String(s.id) === String(userId)) || null;
    }

    function mapFieldLabel(field) {
        const labels = {
            fiqh: 'Fiqh',
            hadith: 'Hadith',
            tafsir: 'Tafsir',
            aqeedah: 'Aqeedah',
            quran: 'Quran',
            seerah: 'Seerah',
            tauhid: 'Tauhid',
            other: 'Other'
        };
        return labels[field] || field;
    }

    function normalizeLevelValue(level) {
        return String(level || '').trim().toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
    }

    function getLevelMeta(level) {
        const key = normalizeLevelValue(level);
        return levelConfig.find((x) => x.value === key) || null;
    }

    function formatLevel(level) {
        const meta = getLevelMeta(level);
        return meta ? meta.label : String(level || '').trim().replaceAll('_', ' ').replace(/\b\w/g, (c) => c.toUpperCase());
    }

    function renderLevelGuide() {
        if (!scholarLevelGuide) return;
        scholarLevelGuide.innerHTML = levelConfig.map((item) => `
            <span class="level-tag">
                <i class="fas ${item.icon}"></i>
                ${item.label}
            </span>
        `).join('');
        if (scholarLevelsCountEl) scholarLevelsCountEl.textContent = String(levelConfig.length);
    }

    function hydrateFilters() {
        const countries = Array.from(new Set(scholars.map((s) => s.country).filter(Boolean))).sort();
        const countryOptions = new Set(Array.from(countryFilter.options).map((o) => o.value));
        countries.forEach((country) => {
            if (!countryOptions.has(country) && country !== 'Unknown') {
                const opt = document.createElement('option');
                opt.value = country;
                opt.textContent = country;
                countryFilter.appendChild(opt);
            }
        });

        const aqeedahValues = Array.from(new Set(scholars.map((s) => (s.aqeedah || '').trim()).filter(Boolean))).sort();
        const aqOptions = new Set(Array.from(aqeedahFilter.options).map((o) => o.value.toLowerCase()));
        aqeedahValues.forEach((aq) => {
            if (!aqOptions.has(aq.toLowerCase())) {
                const opt = document.createElement('option');
                opt.value = aq;
                opt.textContent = aq;
                aqeedahFilter.appendChild(opt);
            }
        });
    }

    function updateStats() {
        if (totalScholarsEl) totalScholarsEl.textContent = String(scholars.length);
        if (pendingScholarsEl) pendingScholarsEl.textContent = String(scholars.filter((s) => s.status === 'pending').length);
        if (scholarLevelsCountEl) scholarLevelsCountEl.textContent = String(levelConfig.length);
    }

    function filterScholars() {
        const q = (searchInput.value || '').trim().toLowerCase();
        const status = statusFilter.value;
        const sort = String(sortFilter?.value || 'newest');
        const country = countryFilter.value;
        const aqeedah = aqeedahFilter.value;

        let filtered = scholars.filter((s) => {
            const matchesSearch =
                (s.name || '').toLowerCase().includes(q) ||
                (s.username || '').toLowerCase().includes(q) ||
                (s.display_name || '').toLowerCase().includes(q) ||
                (s.email || '').toLowerCase().includes(q) ||
                (s.institute || '').toLowerCase().includes(q) ||
                (s.title || '').toLowerCase().includes(q);
            const matchesStatus = status === 'all' || s.status === status;
            const matchesCountry = country === 'all' || s.country === country;
            const matchesAqeedah = aqeedah === 'all' || (s.aqeedah || '') === aqeedah;
            return matchesSearch && matchesStatus && matchesCountry && matchesAqeedah;
        });

        if (sort === 'top_donors') {
            filtered = filtered.slice().sort((a, b) => Number(b.donations_ngn || 0) - Number(a.donations_ngn || 0));
        } else {
            filtered = filtered.slice().sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')));
        }

        if (q || status !== 'all' || country !== 'all' || aqeedah !== 'all') {
            clearFilters.classList.add('visible');
        } else {
            clearFilters.classList.remove('visible');
        }
        return filtered;
    }

    function renderScholars(list) {
        if (!list.length) {
            scholarsGrid.innerHTML = '<div class="no-content-message" style="grid-column:1/-1;"><i class="fas fa-user-graduate" style="font-size:48px; color:var(--medium-gray); margin-bottom:15px;"></i><h3>No scholars found</h3><p>Try adjusting your filters</p></div>';
            return;
        }

        function formatMoney(currency, amount) {
            const cur = String(currency || '').toUpperCase() || 'USD';
            const n = Number(amount || 0);
            if (cur === 'NGN') return '\u20A6' + n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
            return cur + ' ' + n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        }

        function formatJoinedAt(value) {
            const raw = String(value || '').trim();
            if (!raw) return 'Unknown';
            const date = new Date(raw.replace(' ', 'T'));
            if (Number.isNaN(date.getTime())) return raw;
            const diffMs = Date.now() - date.getTime();
            if (diffMs < 0) return date.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
            const hour = 60 * 60 * 1000;
            const day = 24 * hour;
            if (diffMs < hour) {
                const mins = Math.max(1, Math.floor(diffMs / (60 * 1000)));
                return mins + ' min' + (mins === 1 ? '' : 's') + ' ago';
            }
            if (diffMs < day) {
                const hours = Math.floor(diffMs / hour);
                return hours + ' hr' + (hours === 1 ? '' : 's') + ' ago';
            }
            if (diffMs < 7 * day) {
                const days = Math.floor(diffMs / day);
                return days + ' day' + (days === 1 ? '' : 's') + ' ago';
            }
            return date.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
        }

        scholarsGrid.innerHTML = list.map((scholar) => {
            const fields = Array.isArray(scholar.fields) ? scholar.fields : [];
            const fieldsHtml = fields.map((f) => `<span class="field-tag ${f === 'other' ? 'other' : ''}">${escapeHtml(mapFieldLabel(f))}</span>`).join('');
            const handle = String(scholar.username || '').startsWith('@') ? scholar.username : `@${scholar.username || 'scholar'}`;
            const levelLabel = formatLevel(scholar.level || '');
            const levelMeta = getLevelMeta(scholar.level || '');
            const aqeedahLabel = escapeHtml(String(scholar.aqeedah || '').trim() || 'Unknown');
            const joinedLabel = escapeHtml(formatJoinedAt(scholar.created_at));
            const isEmailVerified = Number(scholar.is_email_verified || 0) === 1;
            const loginAccessGranted = Number(scholar.allow_unverified_login || 0) === 1;
            const canToggleLoginAccess = !isEmailVerified && scholar.account_status !== 'banned';
            const levelHtml = levelLabel
                ? `<span class="level-tag"><i class="fas ${levelMeta ? levelMeta.icon : 'fa-user-graduate'}"></i> ${escapeHtml(levelLabel)}</span>`
                : '';
            const emailBadge = !isEmailVerified
                ? '<span class="status-badge email_not_verified">Email not verified</span>'
                : '';

            const reviewActions = scholar.status === 'pending'
                ? `
                    <button class="action-btn approve" data-user-id="${scholar.id}" data-action="approve"><i class="fas fa-check"></i> Approve</button>
                    <button class="action-btn reject" data-user-id="${scholar.id}" data-action="reject"><i class="fas fa-times"></i> Reject</button>
                `
                : scholar.status === 'approved'
                    ? `<button class="action-btn reject" data-user-id="${scholar.id}" data-action="revoke"><i class="fas fa-user-minus"></i> Revoke</button>`
                    : `<button class="action-btn approve" data-user-id="${scholar.id}" data-action="approve"><i class="fas fa-check"></i> Approve</button>`;

            return `
                <div class="scholar-card" data-user-id="${scholar.id}">
                    <div class="scholar-header">
                        <img src="${avatarFor(scholar)}" alt="${escapeHtml(scholar.name)}" class="scholar-avatar">
                        <div class="scholar-info">
                            <div class="scholar-name">
                                ${escapeHtml(scholar.name)}
                                <span class="status-badge ${escapeHtml(scholar.status)}">${escapeHtml(scholar.status)}</span>
                                <span class="status-badge ${escapeHtml(scholar.account_status)}">${escapeHtml(scholar.account_status)}</span>
                                ${emailBadge}
                                ${levelHtml}
                            </div>
                            <div class="scholar-username">${escapeHtml(handle)} - ${escapeHtml(scholar.country || 'Unknown')}</div>
                            <div class="scholar-meta-row">
                                <span class="field-tag aqeedah-pill"><i class="fas fa-tag"></i> ${aqeedahLabel}</span>
                                <span class="field-tag joined-pill"><i class="fas fa-clock"></i> Joined ${joinedLabel}</span>
                            </div>
                        </div>
                    </div>
                    <div class="scholar-details">
                        <div class="detail-item"><span class="detail-label">Display Name:</span> <span class="detail-value">${escapeHtml(scholar.display_name || 'N/A')}</span></div>
                        <div class="detail-item"><span class="detail-label">Institute:</span> <span class="detail-value">${escapeHtml(scholar.institute || 'N/A')}</span></div>
                        <div class="detail-item"><span class="detail-label">Madhhab:</span> <span class="detail-value">${escapeHtml(scholar.madhhab || 'N/A')}</span></div>
                        <div class="detail-item"><span class="detail-label">Aqeedah:</span> <span class="detail-value">${escapeHtml(scholar.aqeedah || 'N/A')}</span></div>
                        <div class="detail-item"><span class="detail-label">Level:</span> <span class="detail-value">${escapeHtml(levelLabel || 'N/A')}</span></div>
                        <div class="detail-item"><span class="detail-label">Posts:</span> <span class="detail-value">${Number(scholar.posts || 0)}</span></div>
                        <div class="detail-item"><span class="detail-label">Donations:</span> <span class="detail-value">${formatMoney(scholar.donations_currency || 'NGN', scholar.donations_amount || scholar.donations_ngn || 0)}</span></div>
                        <div class="detail-item"><span class="detail-label">Phone:</span> <span class="detail-value">${escapeHtml(scholar.phone || 'N/A')}</span></div>
                    </div>
                    <div class="fields-section">
                        <div class="fields-title">Fields of Knowledge</div>
                        <div class="fields-tags">${fieldsHtml || '<span class="field-tag">N/A</span>'}</div>
                    </div>
                    <div class="deen-points">
                        <div class="deen-points-left">
                            <img src="../img/deenPoints.png" alt="Deen Points" onerror="this.style.display='none';">
                            <span class="deen-points-value">${Number(scholar.points || 0).toLocaleString()}</span>
                        </div>
                        <button class="adjust-points" data-user-id="${scholar.id}">Adjust</button>
                    </div>
                    <div class="scholar-actions">
                        ${reviewActions}
                        <button class="action-btn view" data-user-id="${scholar.id}" data-action="view"><i class="fas fa-eye"></i> View</button>
                        <button class="action-btn ban" data-user-id="${scholar.id}" data-action="ban"><i class="fas fa-ban"></i> Ban</button>
                        <button class="action-btn warning" data-user-id="${scholar.id}" data-action="toggle-status">
                            <i class="fas ${scholar.account_status === 'active' ? 'fa-pause' : 'fa-check'}"></i>
                            ${scholar.account_status === 'active' ? 'Suspend' : 'Reactivate'}
                        </button>
                        ${canToggleLoginAccess ? `<button class="action-btn ${loginAccessGranted ? 'warning' : 'primary'}" data-user-id="${scholar.id}" data-action="${loginAccessGranted ? 'revoke-access' : 'grant-access'}"><i class="fas ${loginAccessGranted ? 'fa-user-xmark' : 'fa-user-check'}"></i> ${loginAccessGranted ? 'Revoke Login Access' : 'Grant Login Access'}</button>` : ''}
                        <button class="action-btn delete" data-user-id="${scholar.id}" data-action="delete"><i class="fas fa-trash"></i> Delete</button>
                        <button class="action-btn info" data-user-id="${scholar.id}" data-action="reset-password"><i class="fas fa-key"></i> Reset</button>
                        <button class="action-btn info" data-user-id="${scholar.id}" data-action="change-email"><i class="fas fa-envelope"></i> Email</button>
                        <button class="action-btn post" data-user-id="${scholar.id}" data-action="posts"><i class="fas fa-newspaper"></i> Posts</button>
                        <button class="action-btn post" data-user-id="${scholar.id}" data-action="questions"><i class="fas fa-circle-question"></i> Questions</button>
                        <button class="action-btn info" data-user-id="${scholar.id}" data-action="notifications"><i class="fas fa-bell"></i> Notifications</button>
                        <button class="action-btn primary" data-user-id="${scholar.id}" data-action="message"><i class="fas fa-paper-plane"></i> Message</button>
                    </div>
                </div>
            `;
        }).join('');
    }

    function updateScholarsView() {
        renderScholars(filterScholars());
    }

    function formatLinks(list) {
        if (!Array.isArray(list) || !list.length) return '';
        return list.map((link) => {
            const safe = escapeHtml(link);
            return `
                <div class="doc-list-item">
                    <div class="doc-list-icon"><i class="fas fa-link"></i></div>
                    <div class="doc-list-info">
                        <div class="doc-list-name">Verification Link</div>
                        <div class="doc-list-meta">${safe}</div>
                    </div>
                    <a href="${safe}" target="_blank" class="doc-link">Visit <i class="fas fa-external-link-alt"></i></a>
                </div>
            `;
        }).join('');
    }

    function buildScholarModalActions(scholar) {
        const reviewActions = scholar.status === 'pending'
            ? `
                <button class="action-btn approve" style="flex:1;" data-user-id="${scholar.id}" data-action="approve"><i class="fas fa-check"></i> Approve</button>
                <button class="action-btn reject" style="flex:1;" data-user-id="${scholar.id}" data-action="reject"><i class="fas fa-times"></i> Reject</button>
            `
            : scholar.status === 'approved'
                ? `<button class="action-btn reject" style="flex:1;" data-user-id="${scholar.id}" data-action="revoke"><i class="fas fa-user-minus"></i> Revoke Scholar</button>`
                : `<button class="action-btn approve" style="flex:1;" data-user-id="${scholar.id}" data-action="approve"><i class="fas fa-check"></i> Approve</button>`;

        return `
            <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:18px;">
                ${reviewActions}
                <button class="action-btn post" style="flex:1;" data-user-id="${scholar.id}" data-action="posts"><i class="fas fa-newspaper"></i> Posts</button>
                <button class="action-btn post" style="flex:1;" data-user-id="${scholar.id}" data-action="questions"><i class="fas fa-circle-question"></i> Questions</button>
                <button class="action-btn info" style="flex:1;" data-user-id="${scholar.id}" data-action="notifications"><i class="fas fa-bell"></i> Notifications</button>
            </div>
        `;
    }

    function showScholarDetails(scholar) {
        if (!scholar) return;
        modalScholarName.textContent = `${scholar.name} Details`;
        const handle = String(scholar.username || '').startsWith('@') ? scholar.username : `@${scholar.username || 'scholar'}`;
        const fields = Array.isArray(scholar.fields) && scholar.fields.length
            ? scholar.fields.map((f) => `<span class="info-tag">${escapeHtml(mapFieldLabel(f))}</span>`).join('')
            : '<span class="info-tag">N/A</span>';
        const levelLabel = formatLevel(scholar.level || '');
        const levelMeta = getLevelMeta(scholar.level || '');

        scholarModalBody.innerHTML = `
            <div style="display:flex; align-items:center; gap:16px; margin-bottom:20px;">
                <img src="${avatarFor(scholar)}" alt="${escapeHtml(scholar.name)}" style="width:80px; height:80px; border-radius:50%; object-fit:cover;">
                <div>
                    <h3 style="margin-bottom:4px;">${escapeHtml(scholar.name || 'Scholar')}</h3>
                    <p style="color:var(--dark-gray);">${escapeHtml(handle)} - ${escapeHtml(scholar.email || '')}</p>
                    <p style="color:var(--dark-gray);">${escapeHtml(scholar.phone || 'No phone')} - ${escapeHtml(scholar.country || 'Unknown')}</p>
                    <div style="margin-top:6px;">
                        <span class="status-badge ${escapeHtml(scholar.status)}">${escapeHtml(scholar.status)}</span>
                        <span class="status-badge ${escapeHtml(scholar.account_status)}">${escapeHtml(scholar.account_status)}</span>
                        ${levelLabel ? `<span class="level-tag"><i class="fas ${levelMeta ? levelMeta.icon : 'fa-user-graduate'}"></i> ${escapeHtml(levelLabel)}</span>` : ''}
                    </div>
                </div>
            </div>

            <div class="profile-stats-row">
                <div class="profile-stat-item"><div class="profile-stat-value">${Number(scholar.posts || 0)}</div><div class="profile-stat-label">Posts</div></div>
                <div class="profile-stat-item"><div class="profile-stat-value">${Number(scholar.followers || 0)}</div><div class="profile-stat-label">Followers</div></div>
                <div class="profile-stat-item"><div class="profile-stat-value">${Number(scholar.following || 0)}</div><div class="profile-stat-label">Following</div></div>
                <div class="profile-stat-item"><div class="profile-stat-value">${Number(scholar.points || 0).toLocaleString()}</div><div class="profile-stat-label">DeenPoints</div></div>
            </div>

            <div class="info-card">
                <div class="info-section-title"><i class="fas fa-user-graduate"></i><span>Scholar Information</span></div>
                <div class="info-grid-2col">
                    <div class="info-field"><div class="info-field-label">Display Name</div><div class="info-field-value">${escapeHtml(scholar.display_name || 'N/A')}</div></div>
                    <div class="info-field"><div class="info-field-label">Institute</div><div class="info-field-value">${escapeHtml(scholar.institute || 'N/A')}</div></div>
                    <div class="info-field"><div class="info-field-label">Madhhab</div><div class="info-field-value">${escapeHtml(scholar.madhhab || 'N/A')}</div></div>
                    <div class="info-field"><div class="info-field-label">Aqeedah</div><div class="info-field-value">${escapeHtml(scholar.aqeedah || 'N/A')}</div></div>
                    <div class="info-field"><div class="info-field-label">Level</div><div class="info-field-value">${escapeHtml(levelLabel || 'N/A')}</div></div>
                    <div class="info-field"><div class="info-field-label">Years of Study</div><div class="info-field-value">${Number(scholar.years_of_study || 0)} years</div></div>
                    <div class="info-field"><div class="info-field-label">Teachers</div><div class="info-field-value">${escapeHtml(scholar.teachers || 'Not specified')}</div></div>
                </div>
                <div style="margin-top:14px;">
                    <div class="info-field-label" style="margin-bottom:6px;">Fields of Knowledge</div>
                    <div class="info-tags">${fields}${scholar.other_field ? `<span class="info-tag">${escapeHtml(scholar.other_field)}</span>` : ''}</div>
                </div>
            </div>

            <div class="info-card">
                <div class="info-section-title"><i class="fas fa-file-alt"></i><span>Verification Documents</span></div>
                <div class="doc-list">
                    ${scholar.certificate_url ? `
                        <div class="doc-list-item">
                            <div class="doc-list-icon"><i class="fas fa-file-certificate"></i></div>
                            <div class="doc-list-info">
                                <div class="doc-list-name">Certificate</div>
                                <div class="doc-list-meta">${escapeHtml(scholar.certificate || '')}</div>
                            </div>
                            <button type="button" class="doc-link" data-action="open-doc" data-doc-url="${escapeHtml(scholar.certificate_url)}">View <i class="fas fa-external-link-alt"></i></button>
                        </div>
                    ` : ''}
                    ${scholar.recommendation_url ? `
                        <div class="doc-list-item">
                            <div class="doc-list-icon"><i class="fas fa-file"></i></div>
                            <div class="doc-list-info">
                                <div class="doc-list-name">Recommendation</div>
                                <div class="doc-list-meta">${escapeHtml(scholar.recommendation || '')}</div>
                            </div>
                            <button type="button" class="doc-link" data-action="open-doc" data-doc-url="${escapeHtml(scholar.recommendation_url)}">View <i class="fas fa-external-link-alt"></i></button>
                        </div>
                    ` : ''}
                    ${formatLinks(scholar.verification_links)}
                    ${!scholar.certificate_url && !scholar.recommendation_url && (!scholar.verification_links || !scholar.verification_links.length) ? '<div class="no-content-message" style="padding:12px;">No verification document uploaded.</div>' : ''}
                </div>
            </div>
            ${buildScholarModalActions(scholar)}
        `;

        scholarModal.classList.add('active');
    }

    function renderNotifications(notifications) {
        if (!Array.isArray(notifications) || !notifications.length) {
            activityModalBody.innerHTML = '<div class="no-content-message"><i class="fas fa-bell-slash"></i><p>No notification history</p></div>';
            return;
        }
        const iconForType = (type, metaType) => {
            if (type === 'admin_message') {
                if (metaType === 'warning') return 'fa-triangle-exclamation';
                if (metaType === 'reward') return 'fa-gift';
                return 'fa-bell';
            }
            if (type.includes('ban') || type.includes('suspend')) return 'fa-ban';
            if (type.includes('reactivate')) return 'fa-check-circle';
            if (type.includes('password')) return 'fa-key';
            if (type.includes('scholar')) return 'fa-user-graduate';
            return 'fa-info-circle';
        };

        const html = notifications.map((n) => {
            const metaType = n?.metadata?.message_type ? String(n.metadata.message_type) : '';
            const icon = iconForType(String(n.type || ''), metaType);
            return `
                <div class="activity-item">
                    <div class="activity-icon"><i class="fas ${icon}"></i></div>
                    <div class="activity-detail">
                        <div class="activity-text"><strong>${escapeHtml(n.title || '')}</strong>${n.body ? ' - ' + escapeHtml(n.body) : ''}</div>
                        <div class="activity-meta">
                            <span>${escapeHtml(n.time_ago || '')}</span>
                            <span class="activity-dot"></span>
                            <span>${escapeHtml(n.type || '')}</span>
                            ${metaType ? `<span class="activity-dot"></span><span>${escapeHtml(metaType)}</span>` : ''}
                            ${n.is_read ? '<span class="activity-dot"></span><span>read</span>' : '<span class="activity-dot"></span><span>unread</span>'}
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        activityModalBody.innerHTML = `<div class="activity-timeline">${html}</div>`;
    }
    function renderPosts(user, posts) {
        currentPostsModalUser = user || null;
        currentPostsModalData = Array.isArray(posts) ? posts : [];
        if (!Array.isArray(posts) || !posts.length) {
            postsModalBody.innerHTML = '<div class="no-content-message"><i class="fas fa-feather-alt"></i><h3>No posts yet</h3><p>This scholar has not created any posts.</p></div>';
            return;
        }

        const avatar = avatarFor(user);
        const ownerId = Number(user?.id || 0);
        const commentPreviewCount = 2;
        const replyPreviewCount = 2;
        let replyScopeSeed = 0;

        const flattenReplies = (nodes) => {
            const out = [];
            const visit = (arr) => {
                (Array.isArray(arr) ? arr : []).forEach((node) => {
                    out.push(node);
                    if (Array.isArray(node.replies) && node.replies.length) visit(node.replies);
                });
            };
            visit(nodes);
            return out;
        };

        const q = String(postsSearchTerm || '').trim().toLowerCase();
        const filteredPosts = !q ? posts : posts.filter((post) => {
            if (String(post.content || '').toLowerCase().includes(q)) return true;
            const comments = Array.isArray(post.comments) ? post.comments : [];
            for (const comment of comments) {
                if (String(comment.text || '').toLowerCase().includes(q)) return true;
                if (String(comment.user || '').toLowerCase().includes(q)) return true;
                const replies = flattenReplies(comment.replies || []);
                for (const reply of replies) {
                    if (String(reply.text || '').toLowerCase().includes(q)) return true;
                    if (String(reply.user || '').toLowerCase().includes(q)) return true;
                    if (String(reply.reply_to_username || '').toLowerCase().includes(q)) return true;
                }
            }
            return false;
        });

        const buildReplyThread = (replies, postId, commentId) => {
            const flat = flattenReplies(replies);
            if (!flat.length) return '';
            const scopeId = `reply-scope-${postId}-${commentId}-${replyScopeSeed++}`;
            const htmlRows = flat.map((reply, idx) => {
                const hiddenClass = idx >= replyPreviewCount ? 'is-hidden extra-reply' : '';
                const isCreator = Number(reply.user_id || 0) === ownerId;
                const mention = reply.reply_to_username
                    ? `<span style="color:var(--primary-green);font-weight:600;">@${escapeHtml(reply.reply_to_username)}</span> `
                    : '';
                const replyAvatar = reply.profile_image_url
                    ? escapeHtml(reply.profile_image_url)
                    : `https://ui-avatars.com/api/?name=${encodeURIComponent(reply.user || 'User')}&background=1D6F42&color=fff&size=28`;
                return `
                    <div class="comment-item admin-reply-item ${hiddenClass}" style="margin-left:22px;">
                        <img src="${replyAvatar}" class="comment-avatar" alt="${escapeHtml(reply.user || 'User')}">
                        <div class="comment-content">
                            <div class="comment-header">
                                <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                                    <strong style="font-size:0.8rem;">${escapeHtml(reply.user || 'User')}</strong>
                                    ${isCreator ? '<span class="admin-creator-chip">Creator</span>' : ''}
                                </div>
                                <button class="delete-reply-btn" data-reply-id="${reply.id}" data-post-id="${postId}" data-user-id="${user.id}" title="Delete reply">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                            <div style="font-size:0.82rem;word-break:break-word;">${mention}${escapeHtml(reply.text || '')}</div>
                            <div class="comment-meta">${escapeHtml(reply.time || '')} · ${Number(reply.like_count || 0)} likes</div>
                        </div>
                    </div>
                `;
            }).join('');
            const hiddenCount = Math.max(0, flat.length - replyPreviewCount);
            const toggleBtn = hiddenCount > 0
                ? `<button type="button" class="thread-toggle-btn toggle-admin-replies" data-scope-id="${scopeId}" data-expanded="0" style="margin-left:22px;">Show ${hiddenCount} more replies</button>`
                : '';
            return `<div class="admin-reply-scope" data-scope-id="${scopeId}">${htmlRows}</div>${toggleBtn}`;
        };

        const cardsHtml = filteredPosts.map((post) => {
            const comments = Array.isArray(post.comments) ? post.comments : [];
            const commentsHtml = comments.map((comment, idx) => {
                const hiddenClass = idx >= commentPreviewCount ? 'is-hidden extra-comment' : '';
                const isCreator = Number(comment.user_id || 0) === ownerId;
                const commentAvatar = comment.profile_image_url
                    ? escapeHtml(comment.profile_image_url)
                    : `https://ui-avatars.com/api/?name=${encodeURIComponent(comment.user || 'User')}&background=1D6F42&color=fff&size=28`;
                return `
                    <div class="comment-item ${hiddenClass}">
                        <img src="${commentAvatar}" class="comment-avatar" alt="${escapeHtml(comment.user || 'User')}">
                        <div class="comment-content">
                            <div class="comment-header">
                                <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                                    <strong style="font-size:0.82rem;">${escapeHtml(comment.user || 'User')}</strong>
                                    ${isCreator ? '<span class="admin-creator-chip">Creator</span>' : ''}
                                </div>
                                <button class="delete-comment-btn" data-comment-id="${comment.id}" data-post-id="${post.id}" data-user-id="${user.id}" title="Delete comment">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                            <div style="font-size:0.82rem;word-break:break-word;">${escapeHtml(comment.text || '')}</div>
                            <div class="comment-meta">${escapeHtml(comment.time || '')} · ${Number(comment.likes || 0)} likes</div>
                            ${buildReplyThread(comment.replies || [], post.id, comment.id)}
                        </div>
                    </div>
                `;
            }).join('');

            const hiddenCommentsCount = Math.max(0, comments.length - commentPreviewCount);
            const commentListToggle = hiddenCommentsCount > 0
                ? `<button type="button" class="thread-toggle-btn toggle-admin-comments" data-post-id="${post.id}" data-expanded="0">Show ${hiddenCommentsCount} more comments</button>`
                : '';
            const displayName = escapeHtml(user.display_name || '');

            return `
                <div class="post-card" data-post-id="${post.id}">
                    <div class="post-header">
                        <div style="display:flex; align-items:flex-start; gap:10px;">
                            <img src="${avatar}" alt="${escapeHtml(user.name || 'Scholar')}" class="post-avatar">
                            <div class="post-user-info">
                                <div class="post-user-name">${escapeHtml(user.name || 'Scholar')}</div>
                                ${displayName ? `<div class="post-user-meta" style="font-weight:600;color:var(--primary-green);">${displayName}</div>` : ''}
                                <div class="post-user-meta">@${escapeHtml(user.username || 'scholar')} · ${escapeHtml(post.time || '')}</div>
                            </div>
                        </div>
                        <button class="delete-post-btn" data-post-id="${post.id}" data-user-id="${user.id}" title="Delete post"><i class="fas fa-trash"></i></button>
                    </div>
                    <div class="post-content">${escapeHtml(post.content || '')}</div>
                    ${post.image ? `<img src="${escapeHtml(post.image)}" alt="Post image" class="post-image" data-action="open-image" data-image-src="${escapeHtml(post.image)}">` : ''}
                    <div class="post-stats-row">
                        <span><i class="fas fa-heart"></i> ${Number(post.likes || 0)}</span>
                        <button type="button" class="post-comment-toggle" data-post-id="${post.id}"><i class="far fa-comment"></i> ${comments.length}</button>
                    </div>
                    <div class="comments-section" id="comments-${post.id}">
                        <div class="admin-comment-thread">
                            ${commentsHtml || '<div class="comment-meta" style="padding-top:8px;">No comments yet.</div>'}
                            ${commentListToggle}
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        const searchBoxHtml = `
            <div class="posts-modal-search">
                <i class="fas fa-search"></i>
                <input type="text" id="scholarPostModalSearch" placeholder="Search post/comment/reply text..." value="${escapeHtml(postsSearchTerm)}">
            </div>
        `;
        const emptyResultHtml = '<div class="no-content-message"><i class="fas fa-search"></i><h3>No results</h3><p>No post or comment matched your search.</p></div>';

        postsModalBody.innerHTML = searchBoxHtml + (cardsHtml || emptyResultHtml);
    }

    function closeAllModals() {
        scholarModal.classList.remove('active');
        activityModal.classList.remove('active');
        postsModal.classList.remove('active');
        confirmModal.classList.remove('active');
        reasonModal.classList.remove('active');
        resetModal.classList.remove('active');
        pointsModal.classList.remove('active');
        messageModal.classList.remove('active');
        approveModal.classList.remove('active');
        imageViewerModal.classList.remove('active');

        reasonInput.value = '';
        if (newPassword) newPassword.value = '';
        if (confirmPassword) confirmPassword.value = '';
        if (pointsAdjustment) pointsAdjustment.value = '';
        if (pointsReason) pointsReason.value = '';
        if (currentPointsDisplay) currentPointsDisplay.textContent = '0';
        if (messageSubject) messageSubject.value = '';
        if (messageBody) messageBody.value = '';
        if (messageType) messageType.value = 'alert';
        if (approveAqeedahInput) approveAqeedahInput.value = '';
        pendingApproveScholar = null;
        postsSearchTerm = '';
        currentPostsModalUser = null;
        currentPostsModalData = [];
        if (viewerImage) viewerImage.src = '';
    }

    [closeScholarModal, closeActivityModal, closePostsModal, closeReasonModal, closeResetModal, closePointsModal, closeMessageModal, closeApproveModal, closeImageViewer].forEach((btn) => {
        if (btn) btn.addEventListener('click', closeAllModals);
    });
    [confirmCancel, cancelReasonBtn, cancelResetBtn, cancelPointsModal, cancelMessageModal, cancelApproveBtn].forEach((btn) => {
        if (btn) btn.addEventListener('click', closeAllModals);
    });
    [scholarModal, activityModal, postsModal, confirmModal, reasonModal, resetModal, pointsModal, messageModal, approveModal, imageViewerModal].forEach((modal) => {
        if (!modal) return;
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeAllModals();
        });
    });

    function openImage(src) {
        if (!src) return;
        viewerImage.src = src;
        imageViewerModal.classList.add('active');
    }
    window.openImageViewer = openImage;

    async function loadScholars() {
        scholarsGrid.innerHTML = '<div class="no-content-message" style="grid-column:1/-1;"><i class="fas fa-spinner fa-spin"></i><p>Loading scholars...</p></div>';
        const data = await apiRequest(scholarsApiBase, '/list.php');
        scholars = Array.isArray(data.scholars) ? data.scholars : [];
        const existing = new Set(levelConfig.map((x) => x.value));
        scholars.forEach((s) => {
            const raw = String(s.level || '').trim();
            const value = normalizeLevelValue(raw);
            if (!value || existing.has(value)) return;
            levelConfig.push({
                value,
                label: raw.replaceAll('_', ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
                icon: 'fa-tag'
            });
            existing.add(value);
        });
        hydrateFilters();
        updateStats();
        renderLevelGuide();
        updateScholarsView();
        const searchParam = new URLSearchParams(window.location.search).get('search');
        if (searchParam) {
            searchInput.value = searchParam;
            updateScholarsView();
        }
        loadLoginActivity().catch(() => {});
    }

    async function performModerationAction(userId, action, reason = '') {
        await apiRequest(usersApiBase, '/moderate.php', {
            method: 'POST',
            body: JSON.stringify({ user_id: Number(userId), action, reason })
        });
        await loadScholars();
    }

    async function performScholarReview(userId, action, reason = '', extraData = {}) {
        await apiRequest(scholarsApiBase, '/review.php', {
            method: 'POST',
            body: JSON.stringify({ user_id: Number(userId), action, reason, ...extraData })
        });
        await loadScholars();
    }

    async function refreshPostsModalForUser(userId) {
        const scholar = findScholarByUserId(userId);
        if (!scholar) return;
        const data = await apiRequest(usersApiBase, `/posts.php?user_id=${userId}`);
        currentPostsModalUser = {
            id: scholar.id,
            name: scholar.name,
            display_name: scholar.display_name || '',
            username: scholar.username,
            avatar: scholar.avatar
        };
        currentPostsModalData = data.posts || [];
        renderPosts(currentPostsModalUser, currentPostsModalData);
        postsModalTitle.textContent = `${scholar.name}'s Posts`;
        postsModal.classList.add('active');
    }

    function askReason(title, handler) {
        reasonModalTitle.textContent = title;
        pendingReasonAction = handler;
        reasonInput.value = '';
        reasonModal.classList.add('active');
    }

    function askConfirm(title, message, confirmLabel, handler) {
        confirmTitle.textContent = title;
        confirmMessage.textContent = message;
        confirmAction.textContent = confirmLabel;
        pendingAction = handler;
        confirmModal.classList.add('active');
    }

    function setApproveAqeedahMode(mode) {
        const isChange = mode === 'change';
        if (approveAqeedahInput) {
            approveAqeedahInput.style.display = isChange ? 'block' : 'none';
            if (!isChange) approveAqeedahInput.value = '';
        }
    }

    function openApproveModal(scholar) {
        pendingApproveScholar = scholar;
        selectedApproveLevel = normalizeLevelValue(scholar.level || '');
        if (approveCurrentAqeedah) approveCurrentAqeedah.textContent = scholar.aqeedah || 'Not set';

        if (approveLevelOptions) {
            approveLevelOptions.innerHTML = levelConfig.map((item) => `
                <button type="button" class="approval-level-btn ${selectedApproveLevel === item.value ? 'active' : ''}" data-level="${item.value}">
                    <i class="fas ${item.icon}"></i> ${item.label}
                </button>
            `).join('');
        }

        document.querySelectorAll('input[name="approveAqeedahMode"]').forEach((el) => {
            el.checked = el.value === 'confirm';
        });
        setApproveAqeedahMode('confirm');
        approveModal.classList.add('active');
    }

    submitReasonBtn.addEventListener('click', async () => {
        const reason = reasonInput.value.trim();
        if (!reason) {
            notify('Please provide a reason.', 'error');
            return;
        }
        if (!pendingReasonAction) return;
        try {
            await pendingReasonAction(reason);
            pendingReasonAction = null;
            closeAllModals();
        } catch (err) {
            notify(err.message || 'Action failed', 'error');
        }
    });

    confirmAction.addEventListener('click', async () => {
        if (!pendingAction) return;
        try {
            setButtonBusy(confirmAction, true, 'Processing...');
            await pendingAction();
            pendingAction = null;
            confirmModal.classList.remove('active');
        } catch (err) {
            notify(err.message || 'Action failed', 'error');
        } finally {
            setButtonBusy(confirmAction, false);
        }
    });

    saveResetBtn.addEventListener('click', async () => {
        const p1 = (newPassword.value || '').trim();
        const p2 = (confirmPassword.value || '').trim();
        if (p1.length < 8) {
            notify('Password must be at least 8 characters.', 'error');
            return;
        }
        if (p1 !== p2) {
            notify('Passwords do not match.', 'error');
            return;
        }
        if (!currentUserId) return;
        try {
            setButtonBusy(saveResetBtn, true, 'Saving...');
            await apiRequest(usersApiBase, '/reset_password.php', {
                method: 'POST',
                body: JSON.stringify({ user_id: Number(currentUserId), new_password: p1 })
            });
            closeAllModals();
            notify('Password reset successful.', 'success');
        } catch (err) {
            notify(err.message || 'Failed to reset password', 'error');
        } finally {
            setButtonBusy(saveResetBtn, false);
        }
    });

    savePointsAdjustment?.addEventListener('click', async () => {
        const adjustment = parseInt(pointsAdjustment?.value || '', 10);
        if (!Number.isInteger(adjustment) || adjustment === 0) {
            notify('Enter a valid adjustment amount.', 'error');
            return;
        }
        if (!currentUserId) return;
        try {
            setButtonBusy(savePointsAdjustment, true, 'Saving...');
            await apiRequest(usersApiBase, '/adjust_points.php', {
                method: 'POST',
                body: JSON.stringify({ user_id: Number(currentUserId), adjustment })
            });
            await loadScholars();
            closeAllModals();
            notify('DeenPoints adjusted.', 'success');
        } catch (err) {
            notify(err.message || 'Failed to adjust points', 'error');
        } finally {
            setButtonBusy(savePointsAdjustment, false);
        }
    });

    sendMessageBtn.addEventListener('click', async () => {
        const subject = (messageSubject.value || '').trim();
        const bodyText = (messageBody.value || '').trim();
        const type = (messageType?.value || 'alert').trim().toLowerCase();
        if (!subject && !bodyText) {
            notify('Write a subject or message.', 'error');
            return;
        }
        if (!currentUserId) return;
        try {
            setButtonBusy(sendMessageBtn, true, 'Sending...');
            await apiRequest(usersApiBase, '/message.php', {
                method: 'POST',
                body: JSON.stringify({
                    user_id: Number(currentUserId),
                    message: [subject, bodyText].filter(Boolean).join(' - '),
                    message_type: type
                })
            });
            closeAllModals();
            notify('Message sent.', 'success');
        } catch (err) {
            notify(err.message || 'Failed to send message', 'error');
        } finally {
            setButtonBusy(sendMessageBtn, false);
        }
    });

    document.querySelectorAll('input[name="approveAqeedahMode"]').forEach((el) => {
        el.addEventListener('change', () => setApproveAqeedahMode(el.value));
    });

    approveLevelOptions?.addEventListener('click', (e) => {
        const btn = e.target.closest('.approval-level-btn');
        if (!btn) return;
        selectedApproveLevel = normalizeLevelValue(btn.dataset.level || '');
        approveLevelOptions.querySelectorAll('.approval-level-btn').forEach((x) => x.classList.remove('active'));
        btn.classList.add('active');
    });

    addScholarLevelBtn?.addEventListener('click', () => {
        const rawName = String(newScholarLevelName?.value || '').trim();
        const rawIcon = String(newScholarLevelIcon?.value || '').trim();
        if (!rawName) {
            notify('Enter a level name first.', 'error');
            return;
        }

        const value = normalizeLevelValue(rawName);
        if (!value) {
            notify('Invalid level name.', 'error');
            return;
        }
        if (levelConfig.some((x) => x.value === value)) {
            notify('This level already exists.', 'error');
            return;
        }

        let icon = rawIcon ? rawIcon.replace(/^fa[srldb]?\s+/i, '').trim() : 'fa-tag';
        if (icon && !icon.startsWith('fa-')) icon = `fa-${icon}`;
        if (!icon) icon = 'fa-tag';
        levelConfig.push({ value, label: rawName, icon });
        renderLevelGuide();
        if (newScholarLevelName) newScholarLevelName.value = '';
        if (newScholarLevelIcon) newScholarLevelIcon.value = '';
        notify('Scholar level added.', 'success');
    });

    submitApproveBtn?.addEventListener('click', async () => {
        if (!pendingApproveScholar) return;
        if (!selectedApproveLevel) {
            notify('Please select scholar level.', 'error');
            return;
        }

        const mode = document.querySelector('input[name="approveAqeedahMode"]:checked')?.value || 'confirm';
        const confirmAqeedah = mode !== 'change';
        const aqeedahValue = confirmAqeedah ? '' : (approveAqeedahInput?.value || '').trim();
        if (!confirmAqeedah && !aqeedahValue) {
            notify('Please enter Aqeedah.', 'error');
            return;
        }

        try {
            await performScholarReview(pendingApproveScholar.id, 'approve', '', {
                confirm_aqeedah: confirmAqeedah,
                aqeedah: aqeedahValue,
                level: selectedApproveLevel
            });
            closeAllModals();
        } catch (err) {
            notify(err.message || 'Failed to approve scholar', 'error');
        }
    });

    document.addEventListener('input', (e) => {
        const target = e.target;
        if (!(target instanceof HTMLInputElement)) return;
        if (target.id !== 'scholarPostModalSearch') return;
        postsSearchTerm = target.value || '';
        if (!currentPostsModalUser) return;
        renderPosts(currentPostsModalUser, currentPostsModalData);
    });

    document.addEventListener('click', async (e) => {
        const btn = e.target.closest('button');
        if (btn) {
            if (btn.classList.contains('post-comment-toggle')) {
                const postId = btn.dataset.postId || '';
                const section = postsModalBody.querySelector(`#comments-${postId}`);
                if (!section) return;
                section.classList.toggle('active');
                return;
            }

            if (btn.classList.contains('toggle-admin-comments')) {
                const postId = btn.dataset.postId || '';
                const postCard = postsModalBody.querySelector(`.post-card[data-post-id="${postId}"]`);
                if (!postCard) return;
                const hiddenItems = Array.from(postCard.querySelectorAll('.extra-comment'));
                const expanded = btn.dataset.expanded === '1';
                hiddenItems.forEach((item) => item.classList.toggle('is-hidden', expanded));
                btn.dataset.expanded = expanded ? '0' : '1';
                btn.textContent = expanded ? `Show ${hiddenItems.length} more comments` : 'Show less comments';
                return;
            }

            if (btn.classList.contains('toggle-admin-replies')) {
                const scopeId = btn.dataset.scopeId || '';
                const scope = postsModalBody.querySelector(`.admin-reply-scope[data-scope-id="${scopeId}"]`);
                if (!scope) return;
                const hiddenItems = Array.from(scope.querySelectorAll('.extra-reply'));
                const expanded = btn.dataset.expanded === '1';
                hiddenItems.forEach((item) => item.classList.toggle('is-hidden', expanded));
                btn.dataset.expanded = expanded ? '0' : '1';
                btn.textContent = expanded ? `Show ${hiddenItems.length} more replies` : 'Show less replies';
                return;
            }

            const action = btn.dataset.action;
            const userId = Number(btn.dataset.userId || btn.dataset.id || 0);
            const scholar = userId > 0 ? findScholarByUserId(userId) : null;

            if (action === 'view' && scholar) {
                showScholarDetails(scholar);
                return;
            }

            if (action === 'open-doc') {
                const docUrl = btn.dataset.docUrl || '';
                if (!docUrl) return;
                if (/\.(png|jpg|jpeg|gif|webp)$/i.test(docUrl)) {
                    openImage(docUrl);
                } else {
                    window.open(docUrl, '_blank');
                }
                return;
            }

            if (action === 'approve' && scholar) {
                openApproveModal(scholar);
                return;
            }

            if (action === 'reject' && scholar) {
                askReason(`Reject ${scholar.name} - Provide reason`, async (reason) => {
                    await performScholarReview(scholar.id, 'reject', reason);
                });
                return;
            }

            if (action === 'revoke' && scholar) {
                askReason(`Revoke ${scholar.name} - Provide reason`, async (reason) => {
                    await performScholarReview(scholar.id, 'revoke', reason);
                });
                return;
            }

            if (action === 'ban' && scholar) {
                askReason(`Ban ${scholar.name} - Provide reason`, async (reason) => {
                    await performModerationAction(scholar.id, 'ban', reason);
                });
                return;
            }

            if (action === 'toggle-status' && scholar) {
                if (scholar.account_status === 'active') {
                    askReason(`Suspend ${scholar.name} - Provide reason`, async (reason) => {
                        await performModerationAction(scholar.id, 'suspend', reason);
                    });
                } else {
                    askConfirm('Reactivate account?', `Reactivate ${scholar.name}?`, 'Reactivate', async () => {
                        await performModerationAction(scholar.id, 'reactivate', '');
                    });
                }
                return;
            }

            if ((action === 'grant-access' || action === 'revoke-access') && scholar) {
                const granting = action === 'grant-access';
                askConfirm(
                    granting ? 'Grant login access?' : 'Revoke login access?',
                    granting
                        ? `Allow ${scholar.name} to login even though their email is not verified?`
                        : `Remove ${scholar.name}'s temporary login access while their email is still unverified?`,
                    granting ? 'Grant Access' : 'Revoke Access',
                    async () => {
                        await performModerationAction(scholar.id, granting ? 'grant-access' : 'revoke-access', '');
                    }
                );
                return;
            }

            if (action === 'delete' && scholar) {
                askConfirm('Delete user?', `Permanently delete ${scholar.name}? This cannot be undone.`, 'Delete', async () => {
                    await apiRequest(usersApiBase, '/delete.php', {
                        method: 'POST',
                        body: JSON.stringify({ user_id: Number(scholar.id) })
                    });
                    await loadScholars();
                });
                return;
            }

            if (action === 'reset-password' && scholar) {
                currentUserId = scholar.id;
                resetModal.classList.add('active');
                return;
            }

            if (action === 'change-email' && scholar) {
                const nextEmail = await promptForEmailChange(`Change email for ${scholar.name}`, scholar.email || '');
                if (!nextEmail || nextEmail === scholar.email) return;
                await apiRequest(scholarsApiBase, '/update_email.php', {
                    method: 'POST',
                    body: JSON.stringify({ user_id: Number(scholar.id), email: nextEmail.trim() })
                });
                await loadScholars();
                notify('Scholar email updated.', 'success');
                return;
            }

            if (btn.classList.contains('adjust-points') && scholar) {
                currentUserId = scholar.id;
                if (currentPointsDisplay) currentPointsDisplay.textContent = Number(scholar.points || 0).toLocaleString();
                pointsModal.classList.add('active');
                return;
            }

            if (action === 'message' && scholar) {
                currentUserId = scholar.id;
                messageModal.classList.add('active');
                return;
            }

            if (action === 'notifications' && scholar) {
                try {
                    const data = await apiRequest(usersApiBase, `/notifications.php?user_id=${scholar.id}`);
                    activityModalTitle.textContent = `${scholar.name} Notifications`;
                    renderNotifications(data.notifications || []);
                    activityModal.classList.add('active');
                } catch (err) {
                    notify(err.message || 'Failed to load notifications', 'error');
                }
                return;
            }

            if (action === 'posts' && scholar) {
                try {
                    postsSearchTerm = '';
                    await refreshPostsModalForUser(scholar.id);
                } catch (err) {
                    notify(err.message || 'Failed to load posts', 'error');
                }
                return;
            }

            if (action === 'questions' && scholar) {
                try {
                    currentUserId = scholar.id;
                    const data = await apiRequest(scholarsApiBase, `/questions.php?user_id=${scholar.id}`);
                    const items = Array.isArray(data.questions) ? data.questions : [];
                    activityModalTitle.textContent = `${scholar.name} Questions & Answers`;
                    if (!items.length) {
                        activityModalBody.innerHTML = '<div class="no-content-message"><i class="fas fa-circle-question"></i><p>No question/answer activity yet.</p></div>';
                    } else {
                        activityModalBody.innerHTML = `
                          <div style="display:flex;flex-direction:column;gap:12px;">
                            ${items.map((q) => {
                              const askerU = escapeHtml((q.asker && q.asker.username) || '');
                              const askerN = escapeHtml((q.asker && q.asker.name) || '');
                              const privacy = escapeHtml(q.privacy || 'public');
                              const answeredAgo = escapeHtml(q.answered_time_ago || '');
                              const title = escapeHtml(q.title || '');
                              const qText = escapeHtml((q.question || '').slice(0, 360));
                              const aText = escapeHtml((q.answer || '').slice(0, 520));
                              return `
                                <div class="activity-item" style="align-items:flex-start;">
                                  <div class="activity-icon"><i class="fas fa-circle-question"></i></div>
                                  <div class="activity-detail" style="flex:1;">
                                    <div style="display:flex;gap:10px;align-items:flex-start;justify-content:space-between;">
                                      <div class="activity-text" style="font-weight:800;">${title || 'Answered Question'}</div>
                                      <button class="btn danger delete-scholar-question-btn" style="padding:7px 10px;" data-question-id="${Number(q.id||0)}" title="Delete Q/A">
                                        <i class="fas fa-trash"></i>
                                      </button>
                                    </div>
                                    <div class="activity-meta" style="margin-top:6px;">
                                      <span>${answeredAgo}</span>
                                      <span class="activity-dot"></span>
                                      <span>${privacy}</span>
                                      ${askerU ? `<span class="activity-dot"></span><span>@${askerU}${askerN ? ` (${askerN})` : ''}</span>` : ''}
                                    </div>
                                    ${qText ? `<div style="margin-top:10px;color:var(--dark-gray);"><strong>Q:</strong> ${qText}${(q.question||'').length>360?'...':''}</div>` : ''}
                                    ${aText ? `<div style="margin-top:8px;"><strong>A:</strong> ${aText}${(q.answer||'').length>520?'...':''}</div>` : ''}
                                  </div>
                                </div>
                              `;
                            }).join('')}
                          </div>
                        `;
                    }
                    activityModal.classList.add('active');
                } catch (err) {
                    notify(err.message || 'Failed to load question activities', 'error');
                }
                return;
            }
        }

        const imageBtn = e.target.closest('[data-action="open-image"]');
        if (imageBtn) {
            openImage(imageBtn.dataset.imageSrc || '');
            return;
        }

        const delPostBtn = e.target.closest('.delete-post-btn');
        if (delPostBtn) {
            const userId = Number(delPostBtn.dataset.userId || 0);
            const postId = Number(delPostBtn.dataset.postId || 0);
            if (!userId || !postId) return;
            askConfirm('Delete post?', 'This action cannot be undone.', 'Delete', async () => {
                await apiRequest(usersApiBase, '/delete_post.php', {
                    method: 'POST',
                    body: JSON.stringify({ post_id: postId })
                });
                await refreshPostsModalForUser(userId);
            });
            return;
        }

        const delCommentBtn = e.target.closest('.delete-comment-btn');
        if (delCommentBtn) {
            const userId = Number(delCommentBtn.dataset.userId || 0);
            const commentId = Number(delCommentBtn.dataset.commentId || 0);
            if (!userId || !commentId) return;
            askConfirm('Delete comment?', 'This action cannot be undone.', 'Delete', async () => {
                await apiRequest(usersApiBase, '/delete_comment.php', {
                    method: 'POST',
                    body: JSON.stringify({ comment_id: commentId })
                });
                await refreshPostsModalForUser(userId);
            });
            return;
        }

        const delReplyBtn = e.target.closest('.delete-reply-btn');
        if (delReplyBtn) {
            const userId = Number(delReplyBtn.dataset.userId || 0);
            const replyId = Number(delReplyBtn.dataset.replyId || 0);
            if (!userId || !replyId) return;
            askConfirm('Delete reply?', 'This action cannot be undone.', 'Delete', async () => {
                await apiRequest(usersApiBase, '/delete_reply.php', {
                    method: 'POST',
                    body: JSON.stringify({ reply_id: replyId })
                });
                await refreshPostsModalForUser(userId);
            });
        }

        const delQaBtn = e.target.closest('.delete-scholar-question-btn');
        if (delQaBtn) {
            const qid = Number(delQaBtn.dataset.questionId || 0);
            if (!qid) return;
            askConfirm('Delete Q/A?', 'This will remove the question and answer (and hide any feed post for it).', 'Delete', async () => {
                await apiRequest(scholarsApiBase, '/delete_question.php', {
                    method: 'POST',
                    body: JSON.stringify({ question_id: qid })
                });
                // Refresh modal contents immediately (no full page reload).
                try {
                    const data = await apiRequest(scholarsApiBase, `/questions.php?user_id=${currentUserId || 0}`);
                    const items = Array.isArray(data.questions) ? data.questions : [];
                    if (!items.length) {
                        activityModalBody.innerHTML = '<div class="no-content-message"><i class="fas fa-circle-question"></i><p>No answered questions yet.</p></div>';
                    } else {
                        activityModalBody.innerHTML = `
                          <div style="display:flex;flex-direction:column;gap:12px;">
                            ${items.map((q) => {
                              const askerU = escapeHtml((q.asker && q.asker.username) || '');
                              const askerN = escapeHtml((q.asker && q.asker.name) || '');
                              const privacy = escapeHtml(q.privacy || 'public');
                              const answeredAgo = escapeHtml(q.answered_time_ago || '');
                              const title = escapeHtml(q.title || '');
                              const qText = escapeHtml((q.question || '').slice(0, 360));
                              const aText = escapeHtml((q.answer || '').slice(0, 520));
                              return `
                                <div class="activity-item" style="align-items:flex-start;">
                                  <div class="activity-icon"><i class="fas fa-circle-question"></i></div>
                                  <div class="activity-detail" style="flex:1;">
                                    <div style="display:flex;gap:10px;align-items:flex-start;justify-content:space-between;">
                                      <div class="activity-text" style="font-weight:800;">${title || 'Answered Question'}</div>
                                      <button class="btn danger delete-scholar-question-btn" style="padding:7px 10px;" data-question-id="${Number(q.id||0)}" title="Delete Q/A">
                                        <i class="fas fa-trash"></i>
                                      </button>
                                    </div>
                                    <div class="activity-meta" style="margin-top:6px;">
                                      <span>${answeredAgo}</span>
                                      <span class="activity-dot"></span>
                                      <span>${privacy}</span>
                                      ${askerU ? `<span class="activity-dot"></span><span>@${askerU}${askerN ? ` (${askerN})` : ''}</span>` : ''}
                                    </div>
                                    ${qText ? `<div style="margin-top:10px;color:var(--dark-gray);"><strong>Q:</strong> ${qText}${(q.question||'').length>360?'...':''}</div>` : ''}
                                    ${aText ? `<div style="margin-top:8px;"><strong>A:</strong> ${aText}${(q.answer||'').length>520?'...':''}</div>` : ''}
                                  </div>
                                </div>
                              `;
                            }).join('')}
                          </div>
                        `;
                    }
                    notify('Question deleted', 'success');
                } catch (_) {
                    notify('Question deleted', 'success');
                }
            });
            return;
        }
    });

    searchInput.addEventListener('input', updateScholarsView);
    statusFilter.addEventListener('change', updateScholarsView);
    sortFilter?.addEventListener('change', updateScholarsView);
    countryFilter.addEventListener('change', updateScholarsView);
    aqeedahFilter.addEventListener('change', updateScholarsView);
    clearFilters.addEventListener('click', () => {
        searchInput.value = '';
        statusFilter.value = 'all';
        countryFilter.value = 'all';
        aqeedahFilter.value = 'all';
        updateScholarsView();
    });

    renderLevelGuide();
    loadScholars().catch((err) => {
        scholarsGrid.innerHTML = `<div class="no-content-message" style="grid-column:1/-1;"><i class="fas fa-triangle-exclamation"></i><h3>Failed to load scholars</h3><p>${escapeHtml(err.message || 'Server error')}</p></div>`;
    });

    document.getElementById('refreshLoginActivity')?.addEventListener('click', () => loadLoginActivity());
    document.getElementById('loginActivitySearch')?.addEventListener('input', function() {
        if (loginActivityTimer) clearTimeout(loginActivityTimer);
        loginActivityTimer = setTimeout(() => loadLoginActivity(), 250);
    });
})();


