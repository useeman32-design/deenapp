<?php
// test_db.php
require_once 'config.php';

header('Content-Type: application/json');

$result = [
    'status' => 'checking',
    'db_connection' => 'unknown',
    'tables' => [],
    'errors' => []
];

try {
    $pdo = getDBConnection();
    
    if ($pdo) {
        $result['db_connection'] = '✅ OK';
        
        // Check if tables exist
        $tables = ['prayer_times_cache', 'prayer_location_requests', 'prayer_api_stats'];
        
        foreach ($tables as $table) {
            try {
                $stmt = $pdo->query("SELECT 1 FROM $table LIMIT 1");
                $result['tables'][$table] = '✅ Exists';
            } catch (Exception $e) {
                $result['tables'][$table] = '❌ Not accessible: ' . $e->getMessage();
            }
        }
        
    } else {
        $result['db_connection'] = '❌ Failed';
    }
    
} catch (Exception $e) {
    $result['errors'][] = $e->getMessage();
}

echo json_encode($result, JSON_PRETTY_PRINT);
?>