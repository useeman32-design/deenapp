window.BASE_PATH = window.location.pathname.split('/')[1] === 'deenLink' ? '/deenLink' : '';
window.API_BASE = window.BASE_PATH + '/api';
window.UPLOADS_BASE = window.BASE_PATH + '/uploads';
window.DEENLINK_BUILD = '20260619_2';
window.DEENLINK_VERSION_URL = window.API_BASE + '/app/version.php';
window.DEENLINK_SW_URL = window.BASE_PATH + '/sw.js?v=' + encodeURIComponent(window.DEENLINK_BUILD);

// GIPHY API key for comments GIF search.
window.GIPHY_API_KEY = window.GIPHY_API_KEY || 'NwU8MfrUrHO3fG9qchxRRaAFkaUcBmnc';
